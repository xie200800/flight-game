#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  空战飞行模拟器  Air Combat Flight Simulator
================================================================================
  一个用 Python + pygame 写的 3D 空战飞行模拟游戏。

  特性：
    · 无限程序化地形（值噪声生成，含机场跑道）
    · 半拟真飞行物理（推力/阻力/升力/失速/重力下坠）
    · 第三人称与座舱双视角
    · 敌机 AI（追击 / 规避 / 开火 / 释放干扰弹）
    · 机炮 + 红外追踪导弹 + 热焰弹干扰
    · 完整 HUD（姿态梯、空速、高度、航向、雷达、锁定框）
    · 起降玩法：可从跑道滑跑起飞，也可返场着陆

  运行：  python3 空战飞行模拟器.py
  依赖：  pip install pygame numpy
================================================================================
"""

import math
import random
import sys
import os
import time
import io
import json
import base64
import ctypes
from operator import itemgetter

import pygame

try:
    import numpy as np
    HAVE_NUMPY = True
except Exception:
    HAVE_NUMPY = False


# ==============================================================================
#  1. 常量
# ==============================================================================

SCREEN_W = 1280
SCREEN_H = 720

FOV_V = 58.0                     # 垂直视场角（度）
NEAR = 0.6                       # 近裁剪面

# 老版本 pygame 没有 SCALED（Pydroid 较老版本可能缺失）
if not hasattr(pygame, 'SCALED'):
    pygame.SCALED = 0
FAR = 14000.0                    # 远裁剪 / 雾的完全距离
TERRAIN_CELL = 400.0             # 地形网格尺寸
TERRAIN_RINGS = 17               # 以玩家为中心的网格半径（格）→ (2*17)^2 ≈ 1156 块

WORLD_UP = (0.0, 1.0, 0.0)
GRAV = 9.8

# 飞行参数
PITCH_RATE = 1.15                # rad/s
ROLL_RATE = 2.70
YAW_RATE = 0.55
THROTTLE_RATE = 0.55             # 每秒油门变化
MIN_SPEED = 95.0                 # 最小巡航速度
MAX_SPEED = 380.0                # 满油门巡航速度
CLIMB_SPEED = 60.0               # 低于此速度开始掉高度
MAX_ALT = 7000.0                 # 实用升限

# 武器
GUN_ROF = 0.085                  # 机炮射击间隔（秒）
GUN_SPEED = 1500.0               # 炮口初速（m/s）
GUN_DAMAGE = 7
GUN_LIFE = 1.6
MISSILE_SPEED = 420.0
MISSILE_ACC = 260.0              # 导弹加速度
MISSILE_TURN = 1.9               # rad/s 最大转向率
MISSILE_LIFE = 9.0
MISSILE_DAMAGE = 60
LOCK_ANGLE = 14.0                # 可锁定锥角（度）
LOCK_RANGE = 3500.0
LOCK_TIME = 1.2                  # 持续对准多久完成锁定

AIRPORT_R = 1500.0               # 机场平地半径
RUNWAY_HALF_W = 32.0
RUNWAY_HALF_L = 850.0

# 颜色
FOG_COLOR = (188, 202, 214)
SKY_TOP = (48, 96, 172)
SKY_HORIZON = (168, 196, 220)
SUN_COLOR = (255, 246, 214)

FPS = 60
SKY_STRIPS = 14              # 天空渐变条带数（手机会降到 9）
AA_ON = False                # 抗锯齿（设置里可开，明显更耗性能）

# 手机渲染：内部缓冲的长边目标像素，会按实测帧率上下浮动
RENDER_LONG_MOBILE = 960.0
QUAL_MIN = 0.60
QUAL_MAX = 1.15

PARTICLE_MAX = 260              # 同时存活的粒子上限（手机会再降）
CLOUD_COUNT = 46                # 云朵数量（手机会再降）
LOD_DIST = 1800.0               # 超过此距离的敌机用简模（更远就更省）


# ==============================================================================
#  任务目标 / 敌机行为 / 失败条件 —— 游戏内文案
# ==============================================================================

# 注意：此处在 HUD_* 颜色常量之前定义，颜色一律写字面量
_AMBER = (255, 196, 64)
_RED = (255, 82, 72)
_TEXT = (205, 228, 215)

MISSION_BRIEF = [
    ('任 务 简 报', _AMBER),
    ('驾驶战机拦截一波又一波来犯敌机', _TEXT),
    ('清空当前波次即可进入下一波，难度递增', _TEXT),
    ('活得越久、击落越多，得分越高', _TEXT),
    ('', (0, 0, 0)),
    ('计分规则', _AMBER),
    ('击落敌机  +120      王牌机  +220', _TEXT),
    ('机炮每次命中  +12   清空一波  +250 × 波次', _TEXT),
]

# 敌机 AI 状态 → 玩家看得懂的行为描述
ENEMY_STATE_INFO = {
    'pursue': ('咬尾追击', (255, 150, 90)),      # 正在追赶你
    'break': ('脱离缠斗', (255, 210, 90)),       # 太近了，拉开距离
    'evade': ('规避导弹', (120, 210, 255)),      # 被你的导弹追，在逃
}
DEFAULT_STATE_INFO = ('巡航巡逻', (200, 220, 210))

# 失败条件：每一条都会导致坠毁，触屏/键盘提示都写全
FAIL_RULES = [
    ('触地下降率 > 13 m/s', '下降太猛，砸向地面'),
    ('触地坡度 > 22° 或俯仰 > 16°', '姿势不正，机翼/机腹先着地'),
    ('触地空速 > 200 m/s', '着陆速度过快，刹不住'),
    ('血量归零', '被敌机机炮或导弹击毁'),
]

# 致命状态的提前预警（还没死，但再不改就死）
DANGER_RULES = [
    ('失速', '空速 < 105 m/s，升力不足持续掉高度'),
    ('接近升限', '高度 > 6600 m，空气稀薄会失速下坠'),
    ('低空', '离地 < 90 m，随时可能撞地'),
    ('被咬尾', '敌机正从后方锁定你'),
    ('导弹来袭', '已被导弹锁定，立即释放干扰弹'),
]

SURVIVE_TIPS = [
    '生 存 要 诀',
    '速度低于 105 会失速掉高度 —— 宁可俯冲换速度，也别把机头拉太高',
    '高度别超过 6600 m，到顶会失速下坠',
    '着陆要慢：下降率 < 13、坡度 < 22°、速度 < 200',
    '被咬尾时急转 + 放干扰弹，直线飞必被击中',
    '导弹要先锁定：把敌机套进准星，保持 1 秒左右',
]


# ==============================================================================
#  2. 向量数学
# ==============================================================================

def vadd(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def vsub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def vmul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def vdot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def vcross(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def vlen(a):
    return math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])


def vlen2(a):
    return a[0] * a[0] + a[1] * a[1] + a[2] * a[2]


def vnorm(a):
    l = vlen(a)
    if l < 1e-9:
        return (0.0, 0.0, 1.0)
    return (a[0] / l, a[1] / l, a[2] / l)


def vlerp(a, b, t):
    return (a[0] + (b[0] - a[0]) * t,
            a[1] + (b[1] - a[1]) * t,
            a[2] + (b[2] - a[2]) * t)


def rot_axis(v, k, ang):
    """罗德里格斯公式：向量 v 绕单位轴 k 旋转 ang 弧度"""
    c = math.cos(ang)
    s = math.sin(ang)
    kv = vcross(k, v)
    d = vdot(k, v) * (1.0 - c)
    return (v[0] * c + kv[0] * s + k[0] * d,
            v[1] * c + kv[1] * s + k[1] * d,
            v[2] * c + kv[2] * s + k[2] * d)


def rotate_towards(a, b, max_ang):
    """把方向 a 朝 b 旋转，最多 max_ang 弧度"""
    d = max(-1.0, min(1.0, vdot(a, b)))
    ang = math.acos(d)
    if ang < 1e-5:
        return b
    if ang <= max_ang:
        return b
    axis = vcross(a, b)
    if vlen2(axis) < 1e-12:
        axis = (0.0, 1.0, 0.0)
    return vnorm(rot_axis(a, vnorm(axis), max_ang))


def clamp(x, lo, hi):
    return lo if x < lo else (hi if x > hi else x)


def lerp(a, b, t):
    return a + (b - a) * t


def smooth(t):
    t = clamp(t, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def col_lerp(c1, c2, t):
    return (int(c1[0] + (c2[0] - c1[0]) * t),
            int(c1[1] + (c2[1] - c1[1]) * t),
            int(c1[2] + (c2[2] - c1[2]) * t))


# ==============================================================================
#  3. 地形（值噪声高度场）
# ==============================================================================

def _hash2(ix, iy):
    n = (ix * 374761393 + iy * 668265263) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177
    n &= 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0x7FFFFFFF) / 0x7FFFFFFF


def _value_noise(x, y):
    ix = int(math.floor(x))
    iy = int(math.floor(y))
    fx = smooth(x - ix)
    fy = smooth(y - iy)
    a = _hash2(ix, iy)
    b = _hash2(ix + 1, iy)
    c = _hash2(ix, iy + 1)
    d = _hash2(ix + 1, iy + 1)
    return lerp(lerp(a, b, fx), lerp(c, d, fx), fy)


_hcache = {}


def terrain_raw(x, z):
    h = 0.0
    h += _value_noise(x / 2600.0, z / 2600.0) * 1150.0
    h += _value_noise(x / 900.0, z / 900.0) * 300.0
    h += _value_noise(x / 300.0, z / 300.0) * 85.0
    h += _value_noise(x / 110.0, z / 110.0) * 22.0
    return h - 560.0


def terrain_h(x, z):
    """地形高度（机场区域被压平）"""
    key = (int(x * 0.05), int(z * 0.05))
    v = _hcache.get(key)
    if v is None:
        v = terrain_raw(x, z)
        # 机场平地：中心为 1，AIRPORT_R 外为 0
        d = math.sqrt(x * x + z * z)
        flat = 1.0 - smooth((d - AIRPORT_R * 0.55) / (AIRPORT_R * 0.55))
        v = v * (1.0 - flat)
        if len(_hcache) < 400000:
            _hcache[key] = v
    return v


def terrain_normal(x, z):
    e = 12.0
    hl = terrain_h(x - e, z)
    hr = terrain_h(x + e, z)
    hd = terrain_h(x, z - e)
    hu = terrain_h(x, z + e)
    return vnorm((hl - hr, 2.0 * e, hd - hu))


def terrain_color(h, slope, shade):
    """地形配色：按高度分七层，并叠加陡坡露岩、高空冷调。

    分层：浅滩 → 沙滩 → 草地 → 林带 → 灌木 → 裸土岩石 → 雪线
    """
    if h < 8.0:
        c = (78, 112, 98)                     # 水边浅滩
    elif h < 28.0:
        c = col_lerp((150, 142, 100), (98, 130, 74), (h - 8.0) / 20.0)
    elif h < 180.0:
        c = col_lerp((98, 130, 74), (70, 108, 60), (h - 28.0) / 152.0)
    elif h < 430.0:
        c = col_lerp((70, 108, 60), (98, 106, 66), (h - 180.0) / 250.0)
    elif h < 780.0:
        c = col_lerp((98, 106, 66), (126, 114, 84), (h - 430.0) / 350.0)
    elif h < 1200.0:
        c = col_lerp((126, 114, 84), (142, 132, 122), (h - 780.0) / 420.0)
    else:
        c = col_lerp((142, 132, 122), (210, 212, 218),
                     clamp((h - 1200.0) / 420.0, 0.0, 1.0))
    # 陡坡露岩
    c = col_lerp(c, (104, 98, 92), clamp(slope * 1.85, 0.0, 0.78))
    # 高处偏冷
    c = col_lerp(c, (150, 160, 172), clamp((h - 900.0) / 2600.0, 0.0, 0.22))
    return (clamp(int(c[0] * shade), 0, 255),
            clamp(int(c[1] * shade), 0, 255),
            clamp(int(c[2] * shade), 0, 255))


def apply_fog(color, dist):
    t = clamp((dist / FAR) ** 1.35, 0.0, 1.0)
    return col_lerp(color, FOG_COLOR, t)


# ------------------------------------------------------------------------------
#  向量化版本的地形着色（GPU 后端批量打包用）
#  逻辑与 terrain_color / apply_fog 严格一致，避免两条后端地形外观不同
# ------------------------------------------------------------------------------
def _terrain_stops():
    """地形配色分段表，与标量 terrain_color 严格一一对应。

    每项 = (下界, 上界, 起点色, 终点色, 是否到顶段)
    注意两点：
      * h=8 处是**跳变**而非常数段延续，所以必须显式列区间，
        不能用「上段终点 = 下段起点」的连续模型。
      * 最后一段上界写成 1200+420，是为让插值分母正好等于标量的 420，
        实际筛选条件是 h >= 1200（t 会被 clamp 到 1）。
    """
    return ((None, 8.0, (78, 112, 98), (78, 112, 98), False),
            (8.0, 28.0, (150, 142, 100), (98, 130, 74), False),
            (28.0, 180.0, (98, 130, 74), (70, 108, 60), False),
            (180.0, 430.0, (70, 108, 60), (98, 106, 66), False),
            (430.0, 780.0, (98, 106, 66), (126, 114, 84), False),
            (780.0, 1200.0, (126, 114, 84), (142, 132, 122), False),
            (1200.0, 1620.0, (142, 132, 122), (210, 212, 218), True))


def np_terrain_color(h, slope, shade=0.94):
    """向量化地形配色：输入两个 (N,) 数组，返回 (N,3) float32（0..1）"""
    h = np.asarray(h, dtype=np.float32)
    slope = np.asarray(slope, dtype=np.float32)
    c = np.empty((h.size, 3), dtype=np.float32)
    for lo, hi, c0, c1, last in _terrain_stops():
        a = np.array(c0, dtype=np.float32)
        b = np.array(c1, dtype=np.float32)
        if lo is None:
            seg = h < hi
        elif last:
            seg = h >= lo
        else:
            seg = (h >= lo) & (h < hi)
        if np.array_equal(a, b):
            c[seg] = a                      # 常数段（浅滩）
        else:
            t = np.clip((h[seg] - lo) / (hi - lo), 0.0, 1.0).reshape(-1, 1)
            c[seg] = a + (b - a) * t
    # 陡坡露岩
    s = np.clip(slope * 1.85, 0.0, 0.78).reshape(-1, 1)
    c = c + (np.array((104, 98, 92), np.float32) - c) * s
    # 高处偏冷
    k = np.clip((h - 900.0) / 2600.0, 0.0, 0.22).reshape(-1, 1)
    c = c + (np.array((150, 160, 172), np.float32) - c) * k
    return c * shade * (1.0 / 255.0)


def np_apply_fog(col, dist):
    """向量化雾：col 为 (N,3) 的 0..1 浮点色"""
    t = np.clip((np.asarray(dist, dtype=np.float32) / FAR) ** 1.35,
                0.0, 1.0).reshape(-1, 1)
    fog = np.array(FOG_COLOR, dtype=np.float32) * (1.0 / 255.0)
    return col + (fog - col) * t


# 光照方向（世界坐标，指向光源）
LIGHT = vnorm((-0.42, 0.80, 0.36))


# ==============================================================================
#  4. 3D 模型（由环截面生成棱柱，自动计算外法线）
# ==============================================================================

def _prism(rings, color):
    """rings: [(z, [(x, y), ...]), ...]  相邻环之间生成侧面，末环封口"""
    faces = []
    n = len(rings[0][1])
    for i in range(len(rings) - 1):
        z0, r0 = rings[i]
        z1, r1 = rings[i + 1]
        for j in range(n):
            j2 = (j + 1) % n
            quad = [(r0[j][0], r0[j][1], z0),
                    (r0[j2][0], r0[j2][1], z0),
                    (r1[j2][0], r1[j2][1], z1),
                    (r1[j][0], r1[j][1], z1)]
            faces.append((quad, color))
    zc, rc = rings[-1]
    faces.append(([(p[0], p[1], zc) for p in rc], color))
    return faces


def _flat(rings, color):
    """扁平薄板：前后各一环，不封口（用于机翼）"""
    return _prism(rings, color)


def _shade(c, k):
    """把颜色整体压暗/提亮，用于雷达罩、进气道、喷口等细节件"""
    return (clamp(int(c[0] * k), 0, 255),
            clamp(int(c[1] * k), 0, 255),
            clamp(int(c[2] * k), 0, 255))


def _tube(cx, cy, z0, z1, r, col, seg=4):
    """沿 z 轴的锥柱体（导弹 / 副油箱）"""
    def ring(z, rr):
        pts = []
        for i in range(seg):
            a = i * 2.0 * math.pi / seg + math.pi / seg
            pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
        return (z, pts)
    span = z0 - z1
    return _prism([
        ring(z0, 0.0),                       # 弹头尖
        ring(z0 - span * 0.12, r * 0.55),
        ring(z0 - span * 0.30, r),           # 弹体
        ring(z1 + span * 0.22, r),
        ring(z1, r * 0.70),                  # 尾部
    ], col)


def build_jet(body_color, accent, detail=2):
    """构造一架战斗机的面列表：局部坐标 x=右, y=上, z=前

    细节件：机头雷达罩、两侧进气道、座舱盖、背鳍、后掠主翼 +
            翼尖小翼、翼下挂架与导弹、平尾端板、外倾双垂尾（带厚度）、
            尾喷口与内壁。

    detail：2 = 全细节（近距）/ 1 = 中等 / 0 = 简模（远距 LOD）
    """
    dark = _shade(body_color, 0.60)
    darker = _shade(body_color, 0.38)
    nozzle = _shade(body_color, 0.24)
    mis_col = (196, 196, 202)
    faces = []

    # ---- 机头雷达罩 ----
    faces += _prism([
        (12.2, [(0.0, -0.25)] * 4),
        (10.6, [(-0.40, -0.70), (0.40, -0.70), (0.36, 0.06), (-0.36, 0.06)]),
        (8.9, [(-0.82, -0.90), (0.82, -0.90), (0.70, 0.26), (-0.70, 0.26)]),
    ], darker)

    # ---- 机身（分段更密，过渡更顺）----
    faces += _prism([
        (8.9, [(-0.82, -0.90), (0.82, -0.90), (0.70, 0.26), (-0.70, 0.26)]),
        (6.4, [(-1.16, -0.96), (1.16, -0.96), (1.06, 0.54), (-1.06, 0.54)]),
        (1.0, [(-1.78, -1.00), (1.78, -1.00), (1.55, 1.04), (-1.55, 1.04)]),
        (-3.0, [(-1.80, -0.95), (1.80, -0.95), (1.50, 1.00), (-1.50, 1.00)]),
        (-6.5, [(-1.62, -0.80), (1.62, -0.80), (1.30, 0.90), (-1.30, 0.90)]),
        (-9.2, [(-1.10, -0.55), (1.10, -0.55), (0.95, 0.62), (-0.95, 0.62)]),
    ], body_color)

    # ---- 座舱盖 ----
    faces += _prism([
        (6.6, [(0.0, 0.54)] * 4),
        (5.0, [(-0.80, 0.62), (0.80, 0.62), (0.66, 1.52), (-0.66, 1.52)]),
        (1.6, [(-1.05, 1.00), (1.05, 1.00), (0.82, 1.92), (-0.82, 1.92)]),
        (-0.4, [(-0.92, 1.06), (0.92, 1.06), (0.0, 1.62), (0.0, 1.62)]),
    ], accent)

    if detail >= 1:
        # ---- 背鳍（座舱后方）----
        faces += _flat([
            (-0.5, [(0.0, 1.04)] * 2 + [(0.0, 1.62)] * 2),
            (-2.4, [(0.0, 1.08)] * 2 + [(0.0, 2.10)] * 2),
            (-4.8, [(0.0, 0.92)] * 2 + [(0.0, 1.60)] * 2),
        ], body_color)

    if detail >= 2:
        # ---- 两侧进气道 ----
        for sx in (-1, 1):
            faces += _prism([
                (5.8, [(sx * 0.86, -0.74), (sx * 1.56, -0.74),
                       (sx * 1.46, -0.20), (sx * 0.82, -0.20)]),
                (2.8, [(sx * 0.96, -0.90), (sx * 1.64, -0.90),
                       (sx * 1.52, -0.26), (sx * 0.90, -0.26)]),
                (0.7, [(sx * 0.90, -0.76), (sx * 1.46, -0.76),
                       (sx * 1.36, -0.22), (sx * 0.86, -0.22)]),
            ], dark)

    # ---- 主翼（后掠薄板）----
    faces += _flat([
        (-1.2, [(-1.78, -0.30), (-1.78, 0.12), (1.78, 0.12), (1.78, -0.30)]),
        (-5.2, [(-4.72, -0.36), (-4.72, 0.08), (4.72, 0.08), (4.72, -0.36)]),
        (-8.4, [(-7.58, -0.40), (-7.58, 0.04), (7.58, 0.04), (7.58, -0.40)]),
    ], body_color)

    if detail >= 2:
        # ---- 翼尖小翼 + 翼下挂架与导弹 ----
        for sx in (-1, 1):
            faces += _flat([
                (-7.4, [(sx * 7.52, -0.40)] * 2 + [(sx * 7.52, 0.04)] * 2),
                (-8.7, [(sx * 7.66, -0.28)] * 2 + [(sx * 7.66, 1.10)] * 2),
            ], body_color)
            px = sx * 4.30
            # 挂架
            faces += _prism([
                (-2.5, [(px - 0.17, -0.52), (px + 0.17, -0.52),
                        (px + 0.17, -0.18), (px - 0.17, -0.18)]),
                (-3.7, [(px - 0.17, -0.54), (px + 0.17, -0.54),
                        (px + 0.17, -0.18), (px - 0.17, -0.18)]),
            ], dark)
            # 导弹
            faces += _tube(px, -0.80, -1.8, -5.5, 0.20, mis_col)
            # 弹翼
            faces += _flat([
                (-4.5, [(px - 0.40, -0.80)] * 2 + [(px + 0.40, -0.80)] * 2),
                (-5.4, [(px - 0.44, -0.62), (px + 0.44, -0.62),
                        (px + 0.44, -1.08), (px - 0.44, -1.08)]),
            ], mis_col)

    # ---- 平尾 ----
    faces += _flat([
        (-6.4, [(-1.50, 0.02), (-1.50, 0.30), (1.50, 0.30), (1.50, 0.02)]),
        (-9.8, [(-3.72, 0.02), (-3.72, 0.28), (3.72, 0.28), (3.72, 0.02)]),
    ], body_color)

    if detail >= 1:
        # ---- 平尾端板 ----
        for sx in (-1, 1):
            faces += _flat([
                (-8.3, [(sx * 3.28, 0.06)] * 4),
                (-9.9, [(sx * 3.62, 0.06)] * 2 + [(sx * 3.62, 1.02)] * 2),
            ], body_color)

    if detail >= 1:
        # ---- 外倾双垂尾（带厚度）----
        for sx in (-1, 1):
            faces += _prism([
                (-5.2, [(sx * 1.00, 0.88), (sx * 1.62, 0.92),
                        (sx * 1.62, 1.10), (sx * 1.00, 1.06)]),
                (-7.6, [(sx * 1.86, 1.90), (sx * 2.44, 1.96),
                        (sx * 2.44, 2.20), (sx * 1.86, 2.14)]),
                (-9.9, [(sx * 2.56, 3.08), (sx * 3.06, 3.14),
                        (sx * 3.06, 3.42), (sx * 2.56, 3.36)]),
            ], body_color)
    else:
        # 简模：薄板垂尾
        for sx in (-1, 1):
            faces += _flat([
                (-5.2, [(sx * 1.10, 0.90)] * 2 + [(sx * 1.10, 1.08)] * 2),
                (-9.9, [(sx * 2.80, 3.20)] * 2 + [(sx * 2.80, 3.40)] * 2),
            ], body_color)

    # ---- 尾喷口 + 内壁 ----
    faces += _prism([
        (-9.2, [(-1.06, -0.52), (1.06, -0.52), (0.90, 0.58), (-0.90, 0.58)]),
        (-10.7, [(-0.86, -0.42), (0.86, -0.42), (0.74, 0.48), (-0.74, 0.48)]),
    ], darker)
    faces += _prism([
        (-10.7, [(-0.70, -0.34), (0.70, -0.34), (0.60, 0.40), (-0.60, 0.40)]),
        (-11.5, [(-0.62, -0.30), (0.62, -0.30), (0.52, 0.34), (-0.52, 0.34)]),
    ], nozzle)

    # 把退化面（共线顶点）剔除，并保证法线朝外
    center = (0.0, 0.4, -1.0)
    out = []
    for verts, col in faces:
        if len(verts) < 3:
            continue
        nrm = _poly_normal(verts)
        if vlen2(nrm) < 1e-8:
            continue
        cen = _poly_center(verts)
        if vdot(nrm, vsub(cen, center)) < 0:
            verts = verts[::-1]
            nrm = vmul(nrm, -1.0)
        out.append((verts, col, vnorm(nrm)))
    return out


def _poly_center(verts):
    x = y = z = 0.0
    for v in verts:
        x += v[0]
        y += v[1]
        z += v[2]
    n = len(verts)
    return (x / n, y / n, z / n)


def _poly_normal(verts):
    if len(verts) < 3:
        return (0.0, 0.0, 0.0)
    n = (0.0, 0.0, 0.0)
    for i in range(1, len(verts) - 1):
        e1 = vsub(verts[i], verts[0])
        e2 = vsub(verts[i + 1], verts[0])
        n = vadd(n, vcross(e1, e2))
    return n


MODEL_PLAYER = build_jet((74, 84, 98), (42, 52, 66), 2)
MODEL_ENEMY = build_jet((112, 62, 52), (58, 42, 38), 2)
MODEL_ACE = build_jet((92, 88, 56), (48, 46, 32), 2)
# 远距简模（LOD）：省掉进气道、挂架导弹、翼尖小翼、端板等细节
MODEL_ENEMY_LO = build_jet((112, 62, 52), (58, 42, 38), 0)
MODEL_ACE_LO = build_jet((92, 88, 56), (48, 46, 32), 0)



# ==============================================================================
#  5. 相机与渲染
# ==============================================================================

class Camera(object):
    __slots__ = ('pos', 'fwd', 'up', 'right', 'f', 'cx', 'cy', 'w', 'h')

    def __init__(self, w, h):
        self.pos = (0.0, 0.0, 0.0)
        self.fwd = (0.0, 0.0, -1.0)
        self.up = (0.0, 1.0, 0.0)
        self.right = (1.0, 0.0, 0.0)
        self.w = w
        self.h = h
        self.cx = w * 0.5
        self.cy = h * 0.5
        self.f = (h * 0.5) / math.tan(math.radians(FOV_V) * 0.5)

    def set_surface(self, w, h):
        self.w = w
        self.h = h
        self.cx = w * 0.5
        self.cy = h * 0.5
        self.f = (h * 0.5) / math.tan(math.radians(FOV_V) * 0.5)

    def set_basis(self, pos, fwd, up):
        self.pos = pos
        self.fwd = fwd
        self.up = up
        self.right = vcross(fwd, up)

    def to_cam(self, p):
        d = vsub(p, self.pos)
        return (vdot(d, self.right), vdot(d, self.up), vdot(d, self.fwd))

    def project(self, p):
        """世界点 → 屏幕 (x, y, depth)；不可见返回 None"""
        d = vsub(p, self.pos)
        zc = vdot(d, self.fwd)
        if zc < NEAR:
            return None
        inv = self.f / zc
        return (self.cx + vdot(d, self.right) * inv,
                self.cy - vdot(d, self.up) * inv,
                zc)

    def project_cam(self, c):
        """相机空间点 → 屏幕整数坐标（调用前须保证 c[2] >= NEAR）"""
        inv = self.f / c[2]
        return (int(self.cx + c[0] * inv), int(self.cy - c[1] * inv))

    def project_dir(self, d):
        """只投影一个方向（用于 HUD 姿态梯）"""
        zc = vdot(d, self.fwd)
        if zc < 0.05:
            return None
        inv = self.f / zc
        return (self.cx + vdot(d, self.right) * inv,
                self.cy - vdot(d, self.up) * inv)


def clip_near(poly):
    """对相机空间多边形做近平面裁剪（保留 z >= NEAR）"""
    out = []
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        ain = a[2] >= NEAR
        bin_ = b[2] >= NEAR
        if ain:
            out.append(a)
        if ain != bin_:
            t = (NEAR - a[2]) / (b[2] - a[2])
            out.append((a[0] + (b[0] - a[0]) * t,
                        a[1] + (b[1] - a[1]) * t,
                        NEAR))
    return out


def project_poly(cam, poly):
    """相机空间多边形 → 屏幕点列表（已裁剪）"""
    cl = clip_near(poly)
    if len(cl) < 3:
        return None
    f = cam.f
    cx = cam.cx
    cy = cam.cy
    pts = []
    for p in cl:
        inv = f / p[2]
        pts.append((int(cx + p[0] * inv), int(cy - p[1] * inv)))
    if len(pts) < 3:
        return None
    return pts


_SKY = {'key': None, 'surf': None}


# ------------------------------------------------------------------------------
#  云：原来每朵云要画 3 个超大实心圆，填充量是整屏的几十倍，是最大性能瓶颈。
#  改为预渲染成贴图，按「雾档位 + 尺寸」缓存，每朵云每帧只剩一次 blit。
# ------------------------------------------------------------------------------

_CLOUD_BASE = {}
_CLOUD_CACHE = {}
CLOUD_TEX_SIZE = 96
CLOUD_TIERS = 6


def _cloud_base(tier):
    """生成第 tier 档（雾浓度）的云贴图"""
    s = _CLOUD_BASE.get(tier)
    if s is not None:
        return s
    S = CLOUD_TEX_SIZE
    s = pygame.Surface((S, S), pygame.SRCALPHA)
    t = tier / float(CLOUD_TIERS - 1)
    col = col_lerp((246, 249, 253), FOG_COLOR, t)          # 越远越接近雾色
    alpha = int(lerp(238, 120, t))                          # 越远越淡
    # 几个重叠圆团堆出蓬松轮廓
    blobs = ((0.50, 0.56, 0.40), (0.32, 0.62, 0.28), (0.68, 0.62, 0.29),
             (0.44, 0.40, 0.26), (0.60, 0.42, 0.24))
    for bx, by, br in blobs:
        cx, cy, rr = bx * S, by * S, br * S
        for i in range(5):
            k = rr * (1.0 - i * 0.14)
            a = max(0, min(255, int(alpha * (0.42 + i * 0.16))))
            pygame.draw.circle(s, (col[0], col[1], col[2], a),
                               (int(cx), int(cy)), int(k))
    _CLOUD_BASE[tier] = s
    return s


def cloud_sprite(r, tier):
    """按半径取（并缓存）一张缩放好的云贴图"""
    rq = max(1, r >> 4) << 4                 # 半径量化到 16px 一档
    key = (tier, rq)
    s = _CLOUD_CACHE.get(key)
    if s is None:
        d = max(8, rq * 2)
        s = pygame.transform.scale(_cloud_base(tier), (d, d))
        if len(_CLOUD_CACHE) > 140:
            _CLOUD_CACHE.clear()
        _CLOUD_CACHE[key] = s
    return s


def _paint_sky(surf, p0, d, w, h, strips):
    """把天空渐变真正画到 surf 上（缓存未命中时才调用）"""
    t = (-d[1], d[0])
    gd = (-d[0], -d[1])
    BIG = 6000.0
    gp = [(p0[0] + t[0] * BIG + gd[0] * BIG, p0[1] + t[1] * BIG + gd[1] * BIG),
          (p0[0] - t[0] * BIG + gd[0] * BIG, p0[1] - t[1] * BIG + gd[1] * BIG),
          (p0[0] - t[0] * BIG, p0[1] - t[1] * BIG),
          (p0[0] + t[0] * BIG, p0[1] + t[1] * BIG)]
    pygame.draw.polygon(surf, FOG_COLOR, [(int(x), int(y)) for x, y in gp])

    span = max(w, h) * 2.2
    step = span / strips
    prev_a = (p0[0] + t[0] * BIG, p0[1] + t[1] * BIG)
    prev_b = (p0[0] - t[0] * BIG, p0[1] - t[1] * BIG)
    for i in range(strips):
        na = (prev_a[0] + d[0] * step, prev_a[1] + d[1] * step)
        nb = (prev_b[0] + d[0] * step, prev_b[1] + d[1] * step)
        tt = i / float(strips - 1)
        col = col_lerp(SKY_HORIZON, SKY_TOP, tt ** 0.72)
        pygame.draw.polygon(surf, col,
                            [(int(prev_a[0]), int(prev_a[1])),
                             (int(prev_b[0]), int(prev_b[1])),
                             (int(nb[0]), int(nb[1])),
                             (int(na[0]), int(na[1]))])
        prev_a, prev_b = na, nb


def draw_quad(cam, surf, a, b, c, d, col):
    """地形四边形专用绘制：内联变换 + 近裁剪 + 投影 + 填充。

    地形每帧几百个格子，走通用 to_cam/project_poly 会多出数千次
    函数调用，这里全部展开，是渲染热路径上最值得手写的一段。
    """
    px, py, pz = cam.pos
    rx, ry, rz = cam.right
    ux, uy, uz = cam.up
    fx, fy, fz = cam.fwd
    CF, CX, CY = cam.f, cam.cx, cam.cy

    # --- 世界 → 相机 ---
    ex = a[0] - px; ey = a[1] - py; ez = a[2] - pz
    q0 = (ex * rx + ey * ry + ez * rz, ex * ux + ey * uy + ez * uz,
          ex * fx + ey * fy + ez * fz)
    ex = b[0] - px; ey = b[1] - py; ez = b[2] - pz
    q1 = (ex * rx + ey * ry + ez * rz, ex * ux + ey * uy + ez * uz,
          ex * fx + ey * fy + ez * fz)
    ex = c[0] - px; ey = c[1] - py; ez = c[2] - pz
    q2 = (ex * rx + ey * ry + ez * rz, ex * ux + ey * uy + ez * uz,
          ex * fx + ey * fy + ez * fz)
    ex = d[0] - px; ey = d[1] - py; ez = d[2] - pz
    q3 = (ex * rx + ey * ry + ez * rz, ex * ux + ey * uy + ez * uz,
          ex * fx + ey * fy + ez * fz)

    # --- 近平面裁剪（四边形专用展开）---
    poly = []
    prev = q3
    for cur in (q0, q1, q2, q3):
        pin = prev[2] >= NEAR
        cin = cur[2] >= NEAR
        if cin:
            if not pin:
                t = (NEAR - prev[2]) / (cur[2] - prev[2])
                poly.append((prev[0] + (cur[0] - prev[0]) * t,
                             prev[1] + (cur[1] - prev[1]) * t, NEAR))
            poly.append(cur)
        elif pin:
            t = (NEAR - prev[2]) / (cur[2] - prev[2])
            poly.append((prev[0] + (cur[0] - prev[0]) * t,
                         prev[1] + (cur[1] - prev[1]) * t, NEAR))
        prev = cur
    n = len(poly)
    if n < 3:
        return

    # --- 投影 ---
    pts = []
    for i in range(n):
        p = poly[i]
        inv = CF / p[2]
        pts.append((int(CX + p[0] * inv), int(CY - p[1] * inv)))
    pygame.draw.polygon(surf, col, pts)


def draw_sky(surf, cam, scale=1.0):
    """解析法绘制天空。

    天空只由「地平线在屏幕上的直线」决定，与相机位置无关。
    对该直线做量化后缓存整屏位图——飞行中相机变化平缓，
    绝大多数帧只需一次 blit，比每帧画十几个全屏多边形快得多。

    scale：输出到一张 scale 倍尺寸的画布上（GL 后端用它渲染低分辨率
    天空纹理再拉伸，天空是平滑渐变，降采样肉眼看不出差别）。
    """
    w, h = cam.w * scale, cam.h * scale
    cx, cy, cf = cam.cx * scale, cam.cy * scale, cam.f * scale
    nx = vdot(WORLD_UP, cam.right)
    ny = vdot(WORLD_UP, cam.up)
    nz = vdot(WORLD_UP, cam.fwd)
    C = cx * nx - cy * ny - cf * nz
    nn = nx * nx + ny * ny
    if nn < 1e-6:
        surf.fill(SKY_HORIZON if nz > 0 else FOG_COLOR)
        return

    p0 = (C * nx / nn, -C * ny / nn)
    d = (nx / math.sqrt(nn), -ny / math.sqrt(nn))

    # 判断法线哪一侧朝天
    test = (p0[0] + d[0] * 12.0, p0[1] + d[1] * 12.0)
    dc = ((test[0] - cx) / cf, -(test[1] - cy) / cf, 1.0)
    dw = vadd(vadd(vmul(cam.right, dc[0]), vmul(cam.up, dc[1])), vmul(cam.fwd, dc[2]))
    if vdot(dw, WORLD_UP) < 0:
        d = (-d[0], -d[1])

    ang = round(math.degrees(math.atan2(d[1], d[0])) * 2.0)
    off = round((p0[0] * d[0] + p0[1] * d[1]) / 5.0)
    key = (ang, off, int(w), int(h))

    img = _SKY.get('surf')
    if _SKY.get('key') == key and img is not None:
        surf.blit(img, (0, 0))
        return False            # 命中缓存：内容没变，GPU 端无需重传
    if img is None or img.get_size() != (int(w), int(h)):
        img = pygame.Surface((int(w), int(h)))
        _SKY['surf'] = img
    _paint_sky(img, p0, d, w, h, SKY_STRIPS)
    _SKY['key'] = key
    surf.blit(img, (0, 0))
    return True                 # 重画了：需要重新上传纹理


def draw_sun(surf, cam, scale=1.0):
    """画太阳。scale 与 draw_sky 配套（输出到缩放画布）"""
    d = vnorm((0.45, 0.42, -0.79))
    x, y = _sun_screen_pos(cam)
    if x is None:
        return
    x *= scale
    y *= scale
    W, H = cam.w * scale, cam.h * scale
    if -60 * scale < x < W + 60 * scale and -60 * scale < y < H + 60 * scale:
        for i in range(4):
            r = (46 - i * 9) * scale
            if r < 1:
                continue
            a = 26 + i * 14
            s = pygame.Surface((int(r * 2), int(r * 2)), pygame.SRCALPHA)
            pygame.draw.circle(s, (255, 240, 200, a), (int(r), int(r)), int(r))
            surf.blit(s, (int(x - r), int(y - r)))
        r0 = 17 * scale
        if r0 >= 1:
            pygame.draw.circle(surf, SUN_COLOR, (int(x), int(y)), int(r0))


def _sun_screen_pos(cam):
    """太阳在屏幕上的位置（相机空间足够远，直接用方向投影）"""
    d = vnorm((0.45, 0.42, -0.79))
    p = cam.project_dir(vmul(d, 12000.0))
    return (p[0], p[1]) if p is not None else (None, None)


# ==============================================================================
#  6. 音效（程序化合成，无需外部资源）
# ==============================================================================

class Sfx(object):
    def __init__(self):
        self.ok = False
        self.sounds = {}
        try:
            if HAVE_NUMPY and pygame.mixer.get_init() is None:
                pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
            if pygame.mixer.get_init() is not None and HAVE_NUMPY:
                self.ok = True
                self._build()
        except Exception:
            self.ok = False

    def _buf(self, wave, vol=0.35):
        data = np.clip(wave * vol * 32767.0, -32767, 32767).astype(np.int16)
        return pygame.sndarray.make_sound(np.repeat(data.reshape(-1, 1), 2, axis=1))

    def _build(self):
        sr = 22050
        # 机炮：短噪声爆
        t = np.linspace(0, 0.12, int(sr * 0.12), endpoint=False)
        env = np.exp(-34.0 * t)
        w = (np.random.uniform(-1, 1, len(t)) * 0.7 +
             np.sin(2 * np.pi * 165 * t) * 0.5) * env
        self.sounds['gun'] = self._buf(w, 0.30)
        # 爆炸：低频噪声，长衰减
        t = np.linspace(0, 1.1, int(sr * 1.1), endpoint=False)
        env = np.exp(-3.4 * t) * (1.0 - np.exp(-90 * t))
        w = (np.random.uniform(-1, 1, len(t)) * 0.8 +
             np.sin(2 * np.pi * 62 * t) * 0.55) * env
        self.sounds['boom'] = self._buf(w, 0.55)
        # 导弹发射
        t = np.linspace(0, 0.9, int(sr * 0.9), endpoint=False)
        env = np.exp(-2.6 * t) * (1.0 - np.exp(-60 * t))
        w = (np.random.uniform(-1, 1, len(t)) * 0.9) * env
        self.sounds['missile'] = self._buf(w, 0.42)
        # 锁定提示音
        t = np.linspace(0, 0.14, int(sr * 0.14), endpoint=False)
        w = np.sin(2 * np.pi * 1180 * t) * np.exp(-16 * t)
        self.sounds['lock'] = self._buf(w, 0.20)
        # 命中
        t = np.linspace(0, 0.09, int(sr * 0.09), endpoint=False)
        w = (np.random.uniform(-1, 1, len(t)) * np.exp(-40 * t) +
             np.sin(2 * np.pi * 900 * t) * np.exp(-30 * t) * 0.5)
        self.sounds['hit'] = self._buf(w, 0.28)
        # 警报（被锁定 / 低空）
        t = np.linspace(0, 0.35, int(sr * 0.35), endpoint=False)
        f = 620 + 240 * np.sin(2 * np.pi * 7 * t)
        w = np.sin(2 * np.pi * f * t) * np.exp(-4.5 * t)
        self.sounds['alert'] = self._buf(w, 0.22)

    def play(self, name):
        if self.ok and name in self.sounds:
            try:
                self.sounds[name].play()
            except Exception:
                pass


# ==============================================================================
#  7. 实体
# ==============================================================================

def orthonormalize(fwd, up):
    fwd = vnorm(fwd)
    up = vsub(up, vmul(fwd, vdot(up, fwd)))
    if vlen2(up) < 1e-8:
        up = vsub(WORLD_UP, vmul(fwd, vdot(WORLD_UP, fwd)))
        if vlen2(up) < 1e-8:
            up = (0.0, 0.0, 1.0)
    up = vnorm(up)
    right = vcross(fwd, up)
    return fwd, up, vnorm(right)


class Aircraft(object):
    def __init__(self, pos, fwd, is_player=False, model=None):
        self.pos = pos
        self.fwd, self.up, self.right = orthonormalize(fwd, WORLD_UP)
        self.vel = (0.0, 0.0, 0.0)
        self.speed = 0.0
        self.throttle = 0.0 if is_player else 0.75
        self.is_player = is_player
        self.model = model or MODEL_PLAYER
        # 远距简模（LOD）：远处看不清细节，用少一半面的模型换帧率
        if self.model is MODEL_ENEMY:
            self.model_lod = MODEL_ENEMY_LO
        elif self.model is MODEL_ACE:
            self.model_lod = MODEL_ACE_LO
        else:
            self.model_lod = self.model
        self.hp = 100.0
        self.max_hp = 100.0
        self.airborne = False
        self.dead = False
        self.radius = 11.0
        self.gun_cd = 0.0
        self.fire_burst = 0.0
        self.smoke_t = 0.0
        self.missiles = 4 if is_player else 0
        self.flares = 6 if is_player else 3
        self.flare_cd = 0.0
        self.evade_t = 0.0
        self.state = 'pursue'
        self.ai_timer = 0.0
        self.fire_t = 0.0
        self.bank_vis = 0.0
        self.name = 'PLAYER'
        self.g_force = 1.0

    # ---------- 姿态 ----------
    def rotate_body(self, dp, dr, dy):
        if dp:
            self.fwd = rot_axis(self.fwd, self.right, dp)
            self.up = rot_axis(self.up, self.right, dp)
        if dy:
            self.fwd = rot_axis(self.fwd, self.up, -dy)   # dy>0 机头右偏
            self.right = rot_axis(self.right, self.up, -dy)
        if dr:
            self.up = rot_axis(self.up, self.fwd, dr)     # dr>0 右滚
            self.right = rot_axis(self.right, self.fwd, dr)
        self.fwd, self.up, self.right = orthonormalize(self.fwd, self.up)

    def pitch_deg(self):
        return math.degrees(math.asin(clamp(self.fwd[1], -1, 1)))

    def bank_deg(self):
        return math.degrees(math.atan2(vdot(self.right, WORLD_UP),
                                       vdot(self.up, WORLD_UP)))

    def heading_deg(self):
        # 0=北(-Z), 90=东(+X)
        h = math.degrees(math.atan2(self.fwd[0], -self.fwd[2]))
        return h % 360.0

    def alt(self):
        return self.pos[1]

    def agl(self):
        return self.pos[1] - terrain_h(self.pos[0], self.pos[2])

    # ---------- 物理 ----------
    def update(self, dt, ctl, world):
        gh = terrain_h(self.pos[0], self.pos[2])
        agl = self.pos[1] - gh

        # --- 油门 ---
        self.throttle = clamp(self.throttle + ctl['throttle'] * THROTTLE_RATE * dt, 0.0, 1.0)
        if ctl.get('brake'):
            self.throttle = max(0.0, self.throttle - 1.6 * dt)

        # --- 姿态控制 ---
        if not self.airborne:
            # 地面滑跑：只能偏航转向，不能滚转/俯仰
            yaw = ctl['yaw'] * 0.55 * dt * clamp(self.speed / 40.0, 0.0, 1.0)
            if yaw:
                self.fwd = rot_axis(self.fwd, WORLD_UP, -yaw)
                self.fwd, self.up, self.right = orthonormalize(self.fwd, WORLD_UP)
            # 抬前轮起飞
            if self.speed > 78.0 and ctl['pitch'] > 0.25:
                self.airborne = True
                self.fwd, self.up, self.right = orthonormalize(
                    vlerp(self.fwd, vadd(self.fwd, vmul(WORLD_UP, 0.16)), 1.0), WORLD_UP)
            elif self.speed > 130.0:
                self.airborne = True
        else:
            spd_factor = clamp(self.speed / 140.0, 0.35, 1.0)
            self.rotate_body(ctl['pitch'] * PITCH_RATE * dt * lerp(0.55, 1.0, spd_factor),
                             ctl['roll'] * ROLL_RATE * dt,
                             ctl['yaw'] * YAW_RATE * dt)

        # --- 速度 ---
        fwd_spd = vdot(self.vel, self.fwd)
        if self.airborne:
            target = MIN_SPEED + (MAX_SPEED - MIN_SPEED) * self.throttle
            climb_pen = -GRAV * self.fwd[1] * 1.9          # 爬升减速 / 俯冲加速
            accel = (target - fwd_spd) * 0.85 + climb_pen
            fwd_spd += accel * dt
            fwd_spd = max(28.0, fwd_spd)
            lift = clamp(fwd_spd / CLIMB_SPEED, 0.0, 1.0)
            sink = GRAV * (1.0 - lift) * 3.2                # 失速下坠
            self.vel = vadd(vmul(self.fwd, fwd_spd), vmul(WORLD_UP, -sink * dt))
            # 侧滑（速度矢量向机头靠拢）
            lat = vsub(self.vel, vmul(self.fwd, vdot(self.vel, self.fwd)))
            self.vel = vadd(vmul(self.fwd, fwd_spd), vmul(lat, math.exp(-2.4 * dt)))
            # 升限
            if self.pos[1] > MAX_ALT:
                self.vel = vadd(self.vel, vmul(WORLD_UP, -(self.pos[1] - MAX_ALT) * 0.9 * dt))
        else:
            brk = -34.0 if ctl.get('brake') else -1.6
            acc = self.throttle * 42.0 + brk
            fwd_spd = max(0.0, fwd_spd + acc * dt)
            flat_fwd = vnorm((self.fwd[0], 0.0, self.fwd[2]))
            self.vel = vmul(flat_fwd, fwd_spd)
            # 地面吸附
            self.pos = (self.pos[0], gh + 2.2, self.pos[2])
            self.fwd, self.up, self.right = orthonormalize(flat_fwd, WORLD_UP)

        self.speed = vlen(self.vel)
        self.pos = vadd(self.pos, vmul(self.vel, dt))

        # --- 地面 / 坠毁 ---
        gh2 = terrain_h(self.pos[0], self.pos[2])
        agl2 = self.pos[1] - gh2
        hit = False
        if agl2 <= 5.0:
            if self.airborne:
                vs = -self.vel[1]              # 下降率：正=下沉，负=爬升
                slope_ok = abs(self.bank_deg()) < 22.0 and abs(self.pitch_deg()) < 16.0
                if vs < -1.0:
                    # 正在爬升（刚离地或复飞）：绝不能判成着陆，
                    # 否则一起飞就被按回地面并算坠毁
                    if agl2 < 1.0:
                        self.pos = (self.pos[0], gh2 + 5.0, self.pos[2])
                elif vs < 13.0 and slope_ok and self.speed < 200.0:
                    # 成功着陆
                    self.airborne = False
                    self.pos = (self.pos[0], gh2 + 2.2, self.pos[2])
                    self.vel = vmul(vnorm((self.fwd[0], 0.0, self.fwd[2])), self.speed)
                else:
                    hit = True
            else:
                self.pos = (self.pos[0], gh2 + 2.2, self.pos[2])
        elif agl2 > 12.0:
            self.airborne = True

        # 过载（用于视觉与黑视）
        if self.airborne and dt > 0:
            turn = math.acos(clamp(vdot(vnorm(self.vel), self.fwd), -1, 1))
            self.g_force = clamp(1.0 + self.speed * turn / (GRAV * 12.0), 0.0, 9.0)

        return hit

    # ---------- 渲染 ----------
    def collect(self, cam, dlist):
        if self.dead:
            return
        dist = vlen(vsub(self.pos, cam.pos))
        if dist > FAR or dist < 1.0:
            return
        scale = 1.0
        mo = self.model if dist < LOD_DIST else self.model_lod
        for verts, base, nrm in mo:
            wv = []
            for v in verts:
                p = (self.pos[0] + self.right[0] * v[0] * scale + self.up[0] * v[1] * scale + self.fwd[0] * v[2] * scale,
                     self.pos[1] + self.right[1] * v[0] * scale + self.up[1] * v[1] * scale + self.fwd[1] * v[2] * scale,
                     self.pos[2] + self.right[2] * v[0] * scale + self.up[2] * v[1] * scale + self.fwd[2] * v[2] * scale)
                wv.append(p)
            wn = (self.right[0] * nrm[0] + self.up[0] * nrm[1] + self.fwd[0] * nrm[2],
                  self.right[1] * nrm[0] + self.up[1] * nrm[1] + self.fwd[1] * nrm[2],
                  self.right[2] * nrm[0] + self.up[2] * nrm[1] + self.fwd[2] * nrm[2])
            cen = _poly_center(wv)
            if vdot(wn, vsub(cam.pos, cen)) <= 0:
                continue                                  # 背面剔除
            lam = clamp(vdot(wn, LIGHT), 0.0, 1.0)
            shade = 0.42 + 0.58 * lam
            col = (clamp(int(base[0] * shade), 0, 255),
                   clamp(int(base[1] * shade), 0, 255),
                   clamp(int(base[2] * shade), 0, 255))
            d = vlen(vsub(cen, cam.pos))
            col = apply_fog(col, d)
            dlist.append((d, 2, wv, col))


class Bullet(object):
    __slots__ = ('pos', 'prev', 'vel', 'life', 'owner', 'dmg')

    def __init__(self, pos, vel, owner, dmg=GUN_DAMAGE, life=GUN_LIFE):
        self.pos = pos
        self.prev = pos
        self.vel = vel
        self.life = life
        self.owner = owner      # 'p' 玩家  'e' 敌机
        self.dmg = dmg

    def update(self, dt):
        self.prev = self.pos
        self.pos = vadd(self.pos, vmul(self.vel, dt))
        self.life -= dt
        return self.life > 0


class Missile(object):
    def __init__(self, pos, fwd, owner, target, speed0):
        self.pos = pos
        self.prev = pos
        self.vel = vmul(fwd, speed0)
        self.fwd = fwd
        self.owner = owner
        self.target = target
        self.decoy = None          # 被热焰弹诱骗后的伪目标点
        self.life = MISSILE_LIFE
        self.smoke_t = 0.0
        self.armed = 0.35

    def update(self, dt, world):
        self.prev = self.pos
        self.armed -= dt
        sp = min(vlen(self.vel) + MISSILE_ACC * dt, 980.0)
        aim = None
        if self.decoy is not None:
            aim = vnorm(vsub(self.decoy, self.pos))
        else:
            tgt = self.target
            if tgt is not None and not getattr(tgt, 'dead', True):
                lead = vmul(tgt.vel, clamp(vlen(vsub(tgt.pos, self.pos)) / sp, 0.0, 1.6))
                aim = vnorm(vsub(vadd(tgt.pos, lead), self.pos))
        if aim is not None:
            self.fwd = rotate_towards(self.fwd, aim, MISSILE_TURN * dt)
        self.vel = vmul(self.fwd, sp)
        self.pos = vadd(self.pos, vmul(self.vel, dt))
        self.life -= dt
        self.smoke_t -= dt
        if self.smoke_t <= 0:
            self.smoke_t = 0.05
            world.spawn_smoke(self.pos, 2.2, (215, 215, 218), 1.6, 0.9)
        return self.life > 0


class Particle(object):
    __slots__ = ('pos', 'vel', 'life', 'max_life', 'r0', 'r1', 'col')

    def __init__(self, pos, vel, life, r0, r1, col):
        self.pos = pos
        self.vel = vel
        self.life = life
        self.max_life = life
        self.r0 = r0
        self.r1 = r1
        self.col = col

    def update(self, dt):
        self.pos = vadd(self.pos, vmul(self.vel, dt))
        self.vel = vmul(self.vel, math.exp(-1.1 * dt))
        self.vel = vadd(self.vel, vmul(WORLD_UP, -6.0 * dt))
        self.life -= dt
        return self.life > 0


# ==============================================================================
#  8. 字体
# ==============================================================================

# ----8<---- 内嵌字体开始（游戏用到的 717 个字形，文泉驿微米黑子集，约 130 KB）----
_EMBED_FONT_B64 = (
    'AAEAAAAQAQAABAAAR0RFRgcKBwYAAfsAAAAALkdQT1MAGQAMAAH7MAAAABBHU1VCbIx0hQAB+0AAAAAaT1MvMoIRg9UAAeaM'
    'AAAAYGNtYXBKHITrAAHm7AAAEdRnYXNwAAQABwAB+vQAAAAMZ2x5ZhZN4FMAAAEMAAHO0mhlYWTyswu6AAHatAAAADZoaGVh'
    'DGQBJwAB5mgAAAAkaG10eGzQ6qcAAdrsAAALemxvY2FU/+HvAAHQAAAACrJtYXhwBZ0ByQABz+AAAAAgbmFtZS+JQ3MAAfjA'
    'AAACFHBvc3T/AwBmAAH61AAAACB2aGVhC6YPFwACBhAAAAAkdm10eDRwUkMAAftcAAAKsgACAJP/4wGRBbYAAwAXAAABIwMz'
    'AzQ+AjMyHgIVFA4CIyIuAgFQeTPf8BQiLhsaLyIUFCIvGhsuIhQBngQY+rkmNSEPDyE1JiU1IhAQIjUAAAIAhQOmArIFtgAD'
    'AAcAAAEDIwMhAyMDAUopcykCLSlyKQW2/fACEP3wAhAAAgAzAAAE+AW2ABsAHwAAAQMhFSEDIxMhAyMTITUhEyE1IRMzAyET'
    'MwMhFQEhEyED1z8BGP7NUpNU/t1SkE7+/gEdQf7uAStSk1IBJVSQVAEG/OsBI0D+3QN9/riJ/lQBrP5UAayJAUiJAbD+UAGw'
    '/lCJ/rgBSAAAAwB7/4kD2QYSAC0ANgA/AAABFA4CBxUjNSIuAic1HgMzES4DNTQ+Ajc1MxUeARcHLgEnER4DBzQuAicRPgEB'
    'FB4CFxEOAQPZMl2FVIoyZmBUICFXYGUvWYNWKjFbgU+KZKlDQjiMSliHWy6wFCtGM11b/hIRKEIxWVMBvkZyVDcM5t0JEhoR'
    'rBAhGhEBsh5CVW5KQ29TNQm0sAUqH5EZKQb+Wh9CU2tIITctJhL+iw5iAqMkOS8mEQFxEFkAAAUAZv/sBjMFywAJAB0AJwA7'
    'AD8AABMUFjMyERAjIgYFFA4CIyIuAjU0PgIzMh4CARQWMzIRECMiBgUUDgIjIi4CNTQ+AjMyHgIJASMB+kdQnJxQRwHHJEpz'
    'T0lwTCYjSXFOS3FNJwGsR1CcnFBHAcYjSnNPSnBLJiNJcU5LcUwn/wD81Z4DLAQCpaUBSgFIo6VsrHY/P3asbGyqdT4+dar9'
    'SqWkAUkBSKOlbKt2Pz92q2xsqnU+PnWqA5L6SgW2AAMAbf/sBX0FzQARACEAUwAAARQeAhc+AzU0LgIjIgYTMj4CNwEOAxUU'
    'HgIlND4CNy4DNTQ+AjMyHgIVFA4CBwE+AzczDgMHASMnDgMjIi4CAaYQITQkO1Y4HBkvQipWZIc6YlRIIP59NFA3HCNCYP59'
    'KE1vRx88LRwyXopYU4NbMDJUbTwBYBsrIhsKuA8pNUEnARXhqDFgbHxOaadzPQSNIkFBQyUjPkBGKSQ9LBlZ+68XKDYfAZch'
    'P0hVODZbQSTwTnpkViokTVdjOUt3UysrU3dLQG1dTyT+jB08RE4vQm9iVSn+26wtRzEbNWeVAAEAhQOmAUoFtgADAAABAyMD'
    'AUopcykFtv3wAhAAAAEAUv68AisFtgATAAATND4CNzMGAhUUHgIXIy4DUiRKcU6sjJElR2pFqk5xSiQCMX3z5dNdwf4y9Hfs'
    '4tReWs7h8AAAAQA9/rwCFwW2ABMAAAEUDgIHIz4DNTQCJzMeAwIXJEtxTqpFakgkkI2sTnFLJAIxfPDhzlpe1OLsd/QBzsFd'
    '0+XzAAABAFICdwQUBhQADgAAAQMlFwUTBwsBJxMlNwUDApgrAY0a/ob1srCeuPL+iR0BhysGFP53b8Ec/rpgAWb+mmABRhzB'
    'bwGJAAABAGYBBgQCBKIACwAAASE1IREzESEVIREjAen+fQGDlgGD/n2WAoeWAYX+e5b+fwABAD/++AF5AO4ADAAAJRcOAwcj'
    'PgM3AWoPDicvMxmKDx0bFgjuFzZ6fHs4PYSDfTUAAAEAUgHRAkICeQADAAATNSEVUgHwAdGoqAAAAQCT/+MBkQD6ABMAADc0'
    'PgIzMh4CFRQOAiMiLgKTFCIuGxovIhQUIi8aGy4iFG8mNSEPDyE1JiU1IhAQIjUAAAEAFAAAAucFtgADAAAJASMBAuf94LMC'
    'IQW2+koFtgAAAgBi/+wECAXNABMAJwAAARQCDgEjIi4BAjU0Ej4BMzIeARIFFB4CMzI+AjU0LgIjIg4CBAgzcbJ/dq9zOTNv'
    'sX53sHQ6/RMeQmtNTWxFHx9FbE1Na0IeAt2x/ujCZmbCARixsQEYwWZlwf7ospbglUtKlOGXluCUSkqU4AAAAQCyAAACxwW2'
    'ABAAACEjETQ+AjcOAw8BJwEzAsewAQMDAREaGx4VlGABf5YDkStiYVkiEhoYGxJ5ewErAAABAGAAAAPwBcsAIwAAKQE1AT4D'
    'NTQuAiMiBgcnPgMzMh4CFRQOAgcBFSED8PxwAV5LdlMsIj9WNV+ZRWYoXGp2QWCbbDs1XYFL/ucCsZwBfVGGgIFMO1o/IE08'
    'dyQ/Lhs2ZZFbVZqVllH+1QgAAAEAUv/sA+4FywA5AAABFA4CBxUeARUUDgIjIiYnNR4BMzI+AjU0LgIrATUzMj4CNTQuAiMi'
    'BgcnPgMzMh4CA8EuU3RHsbhBhMqKbcFVV8tdXIZXKTVijVmFhVF+VSwkQlw4a6NKXCZdbn1GbKNuOARgSXhYOQwGFrWRYKB0'
    'QCItqi4yKEpsQ0RhPx6XKEpmPTRSOR5DNn0fNikYNmGFAAACABcAAAQ/Bb4ACgAYAAABIxEjESE1ATMRMyERND4CNyMOAwcB'
    'BD/VsP1dApe81f57AwQFAQkHFRkaC/5lAUj+uAFInwPX/DABZDh7dWYiFDExLhD9oAAAAQCD/+wD9gW2ACoAAAEyHgIVFA4C'
    'IyIuAic1HgMzMj4CNTQmIyIOAgcnEyEVIQM+AQIhY6t/SESGxYAzY1tSISFZYmMqT3xWLrCoGz8/ORVaNwKy/ewnIGkDgTds'
    'oGlytn5DChMeFKwXJBgNJU52UY+XBQgJBDkCsKb+XQYOAAACAHH/7AQKBcsAKwA/AAATND4EMzIeAhcVLgEjIg4EBzM+AzMy'
    'HgIVFA4CIyIuAgEyPgI1NC4CIyIOAhUUHgJxFTVcjsaFEy4vKxEjWCtaiWRDKhQDDBQ5TF87X5psOz50pGZkr4BKAds8Y0gn'
    'IUJjQkNvTislSW4CcWnQv6R5RQIFBwWbDAwrTmyDlFAkPy0aO3KlanK2f0ROoPL+uSlTf1dGb04qL0tgMEOFakMAAAEAWgAA'
    'BAYFtgAGAAAhASE1IRUBARkCM/0OA6z91QUQppH62wAAAwBq/+wEAAXNACcAOgBKAAABMh4CFRQOAgceAxUUDgIjIi4CNTQ+'
    'AjcuAzU0PgIDFB4CMzI+AjU0LgIvAQ4BASIGFRQeAhc+AzU0JgI1VJVxQihGYDg6b1c1Q3mpZm6rdT0tTGg6MVY/JUNylccg'
    'RGhIRmtIJCdJZj8efoABFmp9Iz5XMzBVPyR+Bc0sWIRYQ2xXRRwfTF92SVyVaDg2ZZJcS3hgShwfSVptQleDWCz7pjVZPyMj'
    'QVw4NFRIQB8OPJsDVGplOVJAMxgWNEJUNmVqAAACAGr/7AQEBcsAKQA9AAABFA4EIyIuAic1HgEzMj4CNyMOAyMiLgI1ND4C'
    'MzIeAgEiDgIVFB4CMzI+AjU0LgIEBBU1XI7GhRMuLiwRI1grh65mKwUNFDhMYDtfmmw7P3OlZmWugEr+JTxjSCchQmNCRG5O'
    'KyVJbgNGadG+pXhFAgUGBZwNDF6h1nckPi4aO3KlanK3f0ROoPMBRyhUf1dGb04qL0tgMEOFa0IAAgCT/+MBkQRmABMAJwAA'
    'NzQ+AjMyHgIVFA4CIyIuAhE0PgIzMh4CFRQOAiMiLgKTFCIuGxovIhQUIi8aGy4iFBQiLhsaLyIUFCIvGhsuIhRvJjUhDw8h'
    'NSYlNSIQECI1A5EnNSEODiE1JyU0IhAQIjQAAgA//vgBkQRmAAwAIAAAJRcOAwcjPgM3AzQ+AjMyHgIVFA4CIyIuAgFqDw4n'
    'LzMZig8dGxYIERQiLhsaLyIUFCIvGhsuIhTuFzZ6fHs4PYSDfTUC7Sc1IQ4OITUnJTQiEBAiNAAAAQBmAO4EAgTdAAYAACUB'
    'NQEVCQEEAvxkA5z9IQLf7gGoZgHhoP6U/r4AAgBmAboEAgPpAAMABwAAEzUhFQE1IRVmA5z8ZAOcA1SVlf5mlpYAAAEAZgDu'
    'BAIE3QAGAAATCQE1ARUBZgLg/SADnPxkAY8BQgFsoP4fZv5YAAIAJf/jAyUFywAnADsAAAE1ND4CNz4DNTQuAiMiBgcnPgEz'
    'Mh4CFRQOAgcOAx0BAzQ+AjMyHgIVFA4CIyIuAgEZDydCMjBEKxUeOVU4U5ZGP1G8YV2VaDgbNlA2NEImDrsUIi4bGi8iFBQi'
    'LxobLiIUAZ4lOVxQTSopQ0VPNTBPOR80IpEqOzNgi1dDaVpULy1DP0IsEv7RJjUhDw8hNSYlNSIQECI1AAIAbf9KBoEFtgBX'
    'AGgAAAEUDgQjIi4CJyMOAyMiLgI1ND4CMzIeAhcDDgEcARUUHgIzMj4CNTQuAiMiBAYCFRQeAjMyPgI3FQ4BIyIkJgI1NBI2'
    'JDMyBBYSARQWMzI+Aj8BLgEjIg4CBoETJTlMYTotSTQhBgQSNkdZNU13Uis7b55iLVpSRRcXAQEVIisXLkYvGFaY0Xup/v6v'
    'Wk+Z45M9d29kK1bYgrP+58NmdtsBN8GcAQa/avwVZVU3TjIaBA4cTSpKZT8cAts+fXFhSCkeMkEjJUIxHDhljlZlqHpECA4R'
    'CP5gFhsQCAM1RCgPPWiMTo7dmE9vx/7vopfqoFIOGB8RjSYsZsMBGbO8AUXuiGW9/vH+1YV3LVNzRf0IDTpeeAACAAAAAATd'
    'BbwABwAUAAAhAyEDIwEzCQEDLgMnDgMHAwQfoP3forwCGaoCGv5nlAYREhIIBxISEQaRAcX+OwW8+kQCagGoEjQ8QR8fQj0z'
    'Ef5YAAADAMcAAASHBbYAFwAiAC8AABMhMh4CFRQOAgcVHgMVFA4CIyETMzI+AjU0JisBGQEhMj4CNTQuAiPHAY+Aw4NCJ0pt'
    'RUV5WjRBe7Bv/hu69FRyRh+apt8BClh3SSAhS3xcBbYnV41nPmxSNwkKDC1PeFZknW06A0oeO1k7eGj9l/3wKEhlPTheQyUA'
    'AAEAff/sBJgFywAjAAABIg4CFRQeAjMyNjcVDgMjIi4BAjU0Ej4BMzIWFwcuAQMZa657Qzt2sHZZoE4nTlVhO6TwnUxXqfqi'
    'bMRPTj+UBSdRmNqJjduWTiMXog8XDgdsxgEWqaYBFMZuLCqcIC4AAgDHAAAE/AW2AAwAFwAAARQCBgQjIREhMh4BEgc0LgIr'
    'AREzIAAE/GC2/veo/pIBl5n4rl/FQn64dcmiAQgBDALpuf7pu14Ftly1/vS2ktWKQ/uJASQAAAEAxwAAA74FtgALAAApAREh'
    'FSERIRUhESEDvv0JAvf9wwIX/ekCPQW2pP48ov34AAEAxwAAA74FtgAJAAAhIxEhFSERIRUhAYG6Avf9wwIX/ekFtqT9/KQA'
    'AAEAff/sBPIFywArAAABIREOAyMiLgECNTQSNiQzMhYXBy4DIyIOAhUUHgIzMj4CNxEhAw4B5DdwdoJLnfKmVl+2AQurb8xY'
    'SCRTWF0uerx/Qjd4voYsST43Gv7VAwT9MxIcEwppwwEXrqwBFsNpLCqiER4XDlGY2omC2JxWBQgLBQG0AAEAxwAABNUFtgAL'
    'AAAhIxEhESMRMxEhETME1br9Zrq6Apq6Aqr9VgW2/ZgCaAABAFIAAAJkBbYACwAAKQE1NxEnNSEVBxEXAmT97qysAhKsrGYp'
    'BJgpZmYp+2gpAAAB/0j+ewFzBbYAEwAAAyImJzUeATMyPgI1ETMRFA4CHTNMHCJOLSVLPSa7O2mT/nsNC6AJCxMyWEQFtvpe'
    'aZplMQABAMcAAASiBbYADAAAISMBBxEjETMRNwEzAQSi0/49i7q6eQHE0f34Arpy/bgFtv0lqAIz/YMAAAEAxwAAA74FtgAF'
    'AAAzETMRIRXHugI9Bbb68KYAAAEAxwAABi8FtgAZAAAhASMWFx4BFREjESEBMwEhESMRNDY3NjcjAQMj/kUIBgQEBawBFAGc'
    'BgGeARS6BAMEAwj+QQUASkk/izn8lgW2+1gEqPpKA3c0hj1HSfsCAAABAMcAAAUOBbYAGAAAISMBIxYXHgEVESMRMwEzJicm'
    'LwEuATURMwUO1/0xCAYEBAWs1QLMBwMEAQEEAQGuBLpNTEGOOfznBbb7TExKICJCIj4aAyAAAAIAff/sBXEFzQATACcAAAEU'
    'Ag4BIyIuAQI1NBI+ATMyHgESBRQeAjMyPgI1NC4CIyIOAgVxUaDtm6PvnUxMnvCjm+ugUfvRNGulcnKlazIyaqRycqZsNALd'
    'qf7qxmxsxgEXqqoBFcRra8X+66uJ25lRUZnbiYral1FRl9oAAAIAxwAABDMFtgAOABkAAAEUDgIrAREjESEyHgIBMzI+AjU0'
    'JisBBDM3fs+YlroBaobCfjz9ToFdi1supK6gBApbqIFN/ccFtjltoP5nIEdxUY6JAAIAff5iBXEFzQAdADEAAAEUDgIHHgEX'
    'By4BJw4BIyIuAQI1NBI+ATMyHgESBRQeAjMyPgI1NC4CIyIOAgVxMV+OXSuJWnlnrTMRKRKj751MTJ7wo5vroFH70TRrpXJy'
    'pWsyMmqkcnKmbDQC3YPitYQmXo88jknGfwICbMYBF6qqARXEa2vF/uuriduZUVGZ24mK2pdRUZfaAAACAMcAAASgBbYADwAc'
    'AAABESMRISAWFRQOAgcBIwEnMzI+AjU0LgIrAQGBugFkAQr+MVFoNwGO2/6h5aRaflElKVN/V6ACXP2kBbbO0VeCXT4U/XEC'
    'XJ4jRWdFSGRAHQABAGj/7APJBcsAMwAAARQOAiMiJic1HgMzMjY1NC4CJy4DNTQ+AjMyFhcHLgEjIgYVFB4CFx4DA8lFgLhz'
    'b8FBIldgZjKgmR1Jel1Zg1UpQHShYXe+SkNBpVh6hh5Gc1RbiVwvAYdhmWo3IyKyEB8YD3hwNlBDPyUjU2iEVFiKXzItI5wd'
    'K3FgOVNDOyEkTGB+AAEAFAAABBIFtgAHAAAhIxEhNSEVIQJxu/5eA/7+XwUSpKQAAAEAuP/sBN0FuAAXAAABERQOAiMiLgI1'
    'ETMRFBYzMj4CNxEE3UKFyYiAxIVEu62vWYBSKAEFuPxMcsSQUk2Ox3oDrvxIr8A2YohRA7gAAAEAAAAABIsFtgAMAAABMwEj'
    'ATMBHgEXPgE3A8XG/he7/hnFAScdKhEPLh8FtvpKBbb8YVupSkqpYQABABQAAAb+BbYAKgAAATMTHgMXPgM3EzMBIwMuAScm'
    'JwYHDgEHAyMBMxMeAxc+AzcDKcXlDx0ZEwYEDBATC8jH/pG8/g4aCwwLCwsKGQ7yvP5+xd8MFBEOBQUPFBcNBbb8qDhwaV4m'
    'JlpjZzEDcvpKA6ozbC83NDM3L3A2/FwFtvyHLmNiWyYlYmxvMQAAAQAAAAAEYAW2AAsAACEjCQEjCQEzCQEzAQRg0/6e/pG8'
    'AcX+WsYBTAFOvv5bAnv9hQL8Arr90QIv/UwAAQAAAAAENwW2AAgAAAkBMwERIxEBMwIbAVTI/kK7/kLLAtMC4/yD/ccCLwOH'
    'AAEAUgAAA/4FtgAJAAApATUBITUhFQEhA/78VALH/U0Dg/06AtuRBH+mkfuBAAABAKT+vAI5BbYABwAAASERIRUjETMCOf5r'
    'AZXf3/68BvqV+jEAAAEAFwAAAukFtgADAAATASMByQIgsv3gBbb6SgW2AAEAM/68AckFtgAHAAAXMxEjNSERITPf3wGW/mqu'
    'Bc+V+QYAAAEAKQIlBBkFwQAGAAATATMBIwkBKQHLZgG/of6v/qMCJQOc/GQC3/0hAAH//P68A07/SAADAAABITUhA078rgNS'
    '/ryMAAACAF7/7AOcBF4AIwAyAAAhJyMOAyMiLgI1NDY/ATU0LgIjIgYHJz4BMzIeAhURJTI+Aj0BBw4DFRQWAxklCCFCTmA/'
    'RXRVMOfsuB03UTRTj0JASrZkZpVhMP4vPWhMK49aekkgYZgtQSoUJ1F7VKSwCAdFQ1o3GDAiiSg4KVmKYv0QfyZNdU9jBwQg'
    'OVEzXFYAAAIArv/sBD8GFAAfAC8AAAEyHgIVFA4CIyIuAicjByMRMxEUBgcGBzM+AxciDgIVFB4CMzI2NTQmAp5emm08PG2a'
    'XjtgTTsXDCWFtgICAgIIFzpNYBlQa0EbG0FsUYd/fwReSI/UjI3VkEkaKzogiwYU/ogjTyIoJiM8LBmXM2icaWWdazfazNDO'
    'AAEAcf/sA28EXgAfAAAFIi4CNTQ+AjMyFhcHLgMjIgYVFBYzMjY3FQ4BAlJlsIJKTIWyZk6VMjYXODw6Gp2QkZRRgzY2exQ/'
    'idWWnduJPiIZmgoTDwnJ1NPDJRmiHR4AAAIAcf/sBAIGFAAfADAAACUjDgMjIi4CNTQ+AjMyHgIXMyYnLgE1ETMRIyUyPgI3'
    'NTQuAiMiBhUUFgNUCBY7TWA8XZpuPDxuml07YE08FgwDAwIEtpP+xkxpQR8CG0FsUYd/f5MiPS4aSI/UjI3VkEkaLDogIh8a'
    'NxABtPnsgy5ejV4pZZ1rN9rM0c0AAgBx/+wD4QReAB4AJwAABSIuAjU0PgIzMh4CHQEhHgEzMj4CNxUOAwMiBgchNC4CAmBu'
    'toNIQninZWOebjv9TAWZlzNXUUwnKE1RV2ByhQsB7Bs5WBRKjtKHiNaVTkeBtW5xwbYKEx0SohMcEggD25yVRHFQLAAAAQAd'
    'AAAC8AYfABsAAAEjESMRIzU3NTQ+AjMyFhcHLgEjIg4CHQEzAov1t8LCLVV8TjtjJy8fSSgoOiYT9QPB/D8DwUtEYGuNVCMX'
    'Do0LERMwU0FoAAADACX+FAP8BF4APwBSAF4AAAEVBx4BFRQOAiMiJicOAxUUHgI7ATIeAhUUDgIjIi4CNTQ+AjcuATU0Njcu'
    'AzU0PgIzMhYXARQeAjMyNjU0LgIrASIOAhMUFjMyNjU0JiMiBgP8xRwmL1+MXRYsDhEhGxEYKTgfsF2AUSRBhs2La6BqNSdC'
    'Vy8qNkBFK0cxGzJikmElTxv+QBo7YUi6uRg3WkGwI0w/KVxsY2RnaWRjagRKcRsjbUVMgV41AQMKGSAoGBshEgYvUG09WIxh'
    'NCpQcUc8W0IqCxNSNT1ZKhI/UWAzWYxiNAsJ+wIlQC4bc2wuOiEMECxNA2BzcG93e3R4AAABAK4AAAQSBhQAGQAAIRE0JiMi'
    'DgIVESMRMxEHMz4DMzIWFREDXGlwUW5DHba2CAoZRVJcMLe5AsOCgjRmlGD9xwYU/jKQKz8qFL/S/TMAAAIAoAAAAXUF5QAD'
    'ABEAACEjETMDNDYzMh4CFRQGIyImAWS2tsQ9LRYnHRE/LC09BEoBKTw2DRwrHjo5OAAAAv+8/hQBdQXlABMAIQAAEyImJzUe'
    'ATMyPgI1ETMRFA4CEzQ2MzIeAhUUBiMiJkIwPxcaNiMbLiMTtiJIbRM9LRYnHRE/LC09/hQOC5QKCw8nQTME9PsYTXtXLwdf'
    'PDYNHCseOjk4AAABAK4AAAPwBhQADgAAATcBMwkBIwEHESMRMxEDAVaHASXT/m8BrNH+sG20tBACN6oBaf4l/ZEB+FL+WgYU'
    '/Tb+7QABAK4AAAFkBhQAAwAAISMRMwFktrYGFAABAK4AAAaHBF4ALAAAIRE0JiMiDgIVESMRNCYjIg4CFREjETMXMz4DMzIW'
    'FzM+AzMyFhURBdFkaUlmQR63Y2lNaD8btpQaChhCT1kueJ8mCBpJV2Ayr7ECw4KCL1uHWP2iAsOCgjRmlGD9xwRKlCs/KhRY'
    'Xi9ELRa/0v0zAAABAK4AAAQSBF4AGAAAIRE0JiMiDgIVESMRMxczPgMzMhYVEQNcaXBRbkMdtpQaChlFUlwwt7kCw4KCNGaU'
    'YP3HBEqUKz8qFL/S/TMAAgBx/+wELQReABMAHwAAARQOAiMiLgI1ND4CMzIeAgUUFjMyNjU0JiMiBgQtQ32yb2euf0dDfLNv'
    'Z65/R/0AiZqah4mamocCJ4nVkUxMkdWJiNORS0uR04jR09PR0c/PAAACAK7+FAQ/BF4AHwAwAAAFIi4CJyMWFx4BFREjETMX'
    'Mz4DMzIeAhUUDgIDIg4CBxUUHgIzMjY1NCYCnjtgTTsXDAMDAgS2lBoIFzpNYDxemm08PG2agUxpQR8CG0FsUYd/fxQaKzog'
    'Ih8aNxD+KwY2lCM9LRtIj9SMjdWQSQPbLl6MXyllnWs32szQzgAAAgBx/hQEAgReABAAMAAAJTI+Ajc1NC4CIyIGFRQWFyIu'
    'AjU0PgIzMh4CFzM3MxEjETQ2NzY3Iw4DAjVMaUEfAhtBbFGHf39mXZpuPDxuml07YEw8Fwgbk7YEAgMDDBY7TWCDLl6NXill'
    'nWs32szRzZdIj9SMjdWQSRstPSOU+coB1RM6GyAiIj0uGgABAK4AAAMIBF4AFgAAATIWFwcuASMiDgIVESMRMxczPgMCiR1I'
    'GhgcOxo/aEsptpQWCBk5R1gEXgUFqAUHM1+FUf2wBErJK1A9JQAAAQBa/+wDPwReADUAAAEUDgIjIiYnNR4DMzI+AjU0LgIn'
    'LgM1ND4CMzIWFwcuASMiBhUUHgIXHgMDPzptmmBtnDsfTFRZLEFbORoUNVxISHNQKzdkjFZhoUg/QYlHZmIXOF5GSHFQKgEt'
    'UHhRKCMiphAfGA8WKTskHzIxMh8fPEphQ0ZtSiYqIpMdK0M+IzQuLx0ePEtgAAABACH/7AKPBUYAHQAAJTI+AjcVDgMjIi4C'
    'NREjNT8BMxUhFSERFBYB+hItKiMJDSgwNBk+ak0sm5tOaQEU/uw/gQQGCAOKBgwJBSBOhWUCfVFO5vyJ/YNhYgABAKT/7AQI'
    'BEoAGgAAIScjDgMjIi4CNREzERQWMzI+AjURMxEDdRsKGUVSXDBbilwvtmpvUW5DHbaTKz8pFC5imGkCzf09goI0ZZRgAjr7'
    'tgAAAQAAAAAD1QRKABEAACEBMxMeAxczPgM3EzMBAXf+ibzHCx4eGQQHBRgeHgvHvP6JBEr9nSFobGAZGWBsaCECY/u2AAAB'
    'ABQAAAXjBEoALwAAIQMuAycmJyMGBw4BBwMjATMTHgMXMz4DNxMzEx4DFzM+AzcTMwED8KgEDAwNBg4PBg4NCxkLrNP+57+D'
    'ChQSDgQGBREVFgqzxKwJFxYSBAYDDRIVC4m6/uQCaBItMjQZOj4/OjJqJf2cBEr9uC1pZ1sdGldhXyECa/2VIlxfWB0aV2ht'
    'LwJI+7YAAAEAIwAAA9sESgALAAAJATMbATMJASMJASMBmP6fz/r6z/6dAXXP/vT+8s8CMwIX/mYBmv3p/c0BtP5MAAEACv4U'
    'A98ESgAiAAATMxMeAxczPgM3EzMBDgMjIiYnNR4BMzI+Aj8BCr3XDh0ZEgQGBRYbHQvHvP5OHEFWdFA0TBsVQCMwRjQlDzkE'
    'Sv2bKFhYUiMZVmFeIQJj+ydRgVoxCwaRBQcXLEApoAAAAQBSAAADNQRKAAkAACkBNQEhNSEVASEDNf0dAhj+CQKw/fQCHn0D'
    'RImS/NEAAAEAPf68AqIFtgAnAAAFFB4CFxUuAzURNCYjNTI2NRE0PgI3FQ4DFREUBgcVHgEVAfQYLUEoTYNfNoN9fYM2X4NN'
    'KEEtGHdzc3cQMD0jDQGWASFHbk4BTmdWm1ZnAU1ObkchAZUBDSM9MP60aXsUDBR6agAAAQHp/hQCfwYUAAMAAAEzESMB6ZaW'
    'BhT4AAABADP+vAKYBbYAKQAAEzQ2NzUuATURNC4CJzUeAxURFB4CMxUiBhURFA4CBzU+AzXhd3NzdxgtQShNg182IUFgPn2D'
    'Nl+DTShBLRgBO2p6FAwUe2kBTDA9Iw0BlQEhR25O/rM0SC0Um1Zn/rJObkchAZYBDSM9MAABAGYCSgQCA1oAIwAAAS4DIyIO'
    'Agc1NjMyHgIXHgMzMj4CNxUGIyIuAgISJTctKRYcPDs4GWSUHTI3Qy8lNy8oFhw8OzgYY5UdMjdDAosQFg0FEyEsGaJsBQ0Z'
    'FBAWDQUTISwZomwFDRkAAgB7A1YC8gXLABMAJwAAEzQ+AjMyHgIVFA4CIyIuAjcUHgIzMj4CNTQuAiMiDgJ7MlVzQUFzVjIy'
    'VnNBQXNVMnseNEYoKEY1Hh41RigoRjQeBI9Bc1YyMlZzQUFyVTExVXJBJ0U0Hh40RScoRzUfHzVHAAABAI0BLQPdBHsACwAA'
    'CQE3CQEXCQEHCQEnAcv+wmkBPQFCaP6/AT9m/r7+w2cC0wE/af7CAT5n/r/+wGYBPf7FZwADAGYA+AQCBKwAAwAXACsAABM1'
    'IRUBND4CMzIeAhUUDgIjIi4CETQ+AjMyHgIVFA4CIyIuAmYDnP2/Eh8pGBcqIBISICoXGCkfEhIfKRgXKiASEiAqFxgpHxIC'
    'h5aW/u4jLx4NDR4vIyEvHw4OHy8C2yMvHg0NHi8jIS8fDg4fLwAAAQA//+wESgXLADkAAAEiDgIHIRUhFAcGFBUcARchFSEe'
    'ATMyNjcVDgEjIi4CJyM1MyY0NTQ2NSM1Mz4DMzIWFwcuAQMIRXZeQxIBsP5BAQECAYH+kiK5lUuHOzuFW3O2h1gVpJQCApSg'
    'EliHuHJhoE9QM3cFJzRjj1uJDw4MGgkTKRaJr7ggGqIcH0mHwXmJFx4dFi4IiX3KkE4rMZIfKwAAAgBmAXsEAgQlACMARwAA'
    'AS4DIyIOAgc1NjMyHgIXHgMzMj4CNxUGIyIuAgMuAyMiDgIHNTYzMh4CFx4DMzI+AjcVBiMiLgICEiU3LSkWHDw7OBlklB0y'
    'N0MvJTcvKBYcPDs4GGOVHTI3Qy8lNy0pFhw8OzgZZJQdMjdDLyU3LygWHDw7OBhhlx0yN0MBvBAWDQUTISwZomwFDRkUEBYN'
    'BRMhLBmibAUNGQGuEBUNBRMgLBqibQUOGRQQFQ0FEyAtGaJsBQ0ZAAABADD/EAJIATAABQAABQcCJTcEAkh4oP8AeAEgiGgB'
    'AMBg6AACADD/GAJYATgACwAXAAA3NDYzMhYVFAYjIiY3FBYzMjY1NCYjIgYwoHhwoKBweKCAWEA4WFg4QFgocKCgcHCgoHBA'
    'WFhAQFBQAAEEAALgBiAGYAAFAAABIREjESEGIP6YuAIgBcj9GAOAAAABAeD/aAQAAuAABQAABSE1IREzBAD94AFouJiQAugA'
    'AAEAqALoB1ADgAADAAATIRUhqAao+VgDgJgAAwCg/9gHYAXgAAMABwALAAABIRUhEyEVIQMhFSEBAAYA+gBYBVD6sLgGwPlA'
    'BeCY/eiY/diYAAABAKD/oAdwBlgACwAAATMRIRUhESEVITUhA1ioAxD88ANw+TACuAZY/dCg/LigoAABAJD/SAd4BggADQAA'
    'ASE1IRUhEQQFByQlESMDcP0gBuj8mAGIARBw/vj+4KAFcJiY/kDo4JjwuPxQAAACAFj/SAeoBhgADgAUAAATIRUhBgcRIxEA'
    'AScAASEBAAEHAAGYBsj9WDhQsP7Q/oB4AhgBkPyYBIABUAFAgP7o/ogGGKBoePqwBGj+gP7weAFwAnD+qP7w/oiAAVgBWAAC'
    'AKD/WAdQBngAFAAYAAABESEKASMiLwEEMzI3NhMhETMRIRUBIRUhAkAEuBiQuHDwIAEIaGggKCD7SKAFEPlQBND7MAS4/oj9'
    'OP7gIJggWIgB2APQ/tiY/OiYAAEAkP9QB2AGeAAjAAATITchNSE3FwchFSEHIRUhByEVBgcWFwckJTcEFzY3ISc2NyGQAmA4'
    '/gACKCCwKALQ/RA4A8D8GEgDULDogHBo/pj9+EgBGOjAoP0AQDgo/cgEGOCY6BDYmOCY4KDoqEhIkOi4kFhoiMCYYIAAAgB4'
    '/8AHiAaAABkAHQAAEyERMxEhETMRIREzESEVIREhESERIRUhESEBESEReAEImAE4kAGImAGI/nj9UP7IBVj6EP74BPD+eASQ'
    'AZD+cAHw/hAB8P4QmP1QArD8YJgEOP3oAhj96AADAIj/UAegBngAIgAoAC4AAAEzESEVIREUBiMiLwEWMzI1ESEnNhMhNSE2'
    'NxcHIRUhAgchAQQTBwInJRcCBSckA/igAqD9YFBwaGAgaGg4/Tgo0Jj+KAIoQDCoYAPo+9CQuAIQAdABANhw2Pj8+Iig/rBo'
    'AUAEWP6QmP3QeFgQmBBYAhCY0AEgmICIIOiY/uDQ/wDA/viIARjQYFD+6OCA0AACAGD/SAewBngADAAQAAABFwcABQckAQAB'
    'JyQAEzMRIwPwqCgBGAIoYP3o/tj+wP4AcAFoAYBooKAGeChI/hDAsOgB4P44/uCA2AGA/nD7eAAAAwDg/zgHKAaAAA8AEwAX'
    'AAABESM1IREjESEVIxEhETMRASERKQERIREHKKD9wKD92KACyKD9OAIo/dgCyAJABUj8KID9SAK4kAPoATj+yP1AAij92AIo'
    'AAMAsP9IByAGeAAbACEAJwAAASE2ETMQByEQAgYjIi8BFjMyNhIRIQIBJwATIRMWFwcmJwEWFwcmJwEQAkAQqAgDIDiYsGho'
    'KIB4aFAo/XBA/VhYAlBI/cj4gFCoSHgDKIBQsEhwBFjoATj+yOj9OP5YkBigGFAByAGw/PD+mJgBMAKwAnCYsECwkP0AsMhQ'
    '0KgAAQB4/5AHiAZwABkAAAEWFyEVIREhFSERIRUhNSERITUhESE1ISYnA9hQMAL4/PgCoP1gA0D48AMw/WgCmP0IAvAwQAZw'
    'mLCY/lCY/eCYmAIgmAGwmJCAAAEAeP9AB6gGiAAXAAABFwYHIRUUAgcABQckAQAFJwATIQIFJwADAKAoQAKYmFgBIAGoWP5I'
    '/uj+sP2QSAPA6P3AuP8AgAGYBoggkIigGP5okP5AwLDYAcj+KMiwARADsP640IABYAAAAQBw/0AHoAZ4AB4AAAEWFyEVAAEW'
    'BCkBByAsASMiBgcnPgE7AQABITUhJicDuGg4Aqj+GP24iAFgAXABeDD90P34/uggGEiwgNCAOCACiAFg+uACwDhYBniw0JD9'
    '+P5oWFC4ULhI6ID4aAHIAXCguJAAAQB4/3AHkAZ4ACwAAAEzESURMxElEAYjIi8BFjMyNzYRBREjEQURFBYhIDc2NxcCBiEg'
    'JyY1EQcnJQGIoAGgoAJ4cLhIWBhgWEgQIP44oP5gcAHAAdhoQCCYKMj9uP3gSGjQQAEQBbD+OHgCGP4QqP0g8AigGFCAAaCA'
    '/UACmHj9EDAQKBj4SP7oeCAgeALwOJhIAAEA2P9ABxgGEAATAAATIRUEBREUBiMiLwEWMzI1ESQlIdgGQP7Q/ohwaJCQGHiY'
    'YAFYAQj6qAYQqPjQ/EBQUCCgICAD8MjAAAUAaP9AB5gGeAAzADcAOwA/AEMAABMhNTMVIRUhFSERIRUhETMVIxEjNSEVFAYj'
    'Ii8BFjMyNj0BITUhNSE1ITUhNSE1IREhNSEBITUpARUhNQEVITUBFSE1gAMYoAMw/NACkP1wAqi4uKD9+GB4oIggmJgwIP0o'
    'Atj80AMw/SgC2P14Aoj86AEwAej+GAKIAfD+EAII/fgCCAYYYGCYWP5oYP74mP6wQHBwYBCYECg4SJh4mHCYYAGYWP6oaGho'
    '/ghwcP74eHgAAQCA/0gHgAYAABkAAAEhFSERIRUhERQGIyIvARYzMjY1ESE1IREhAQgF6P14Axj86FiQiIAgiIgwMPy4A0j9'
    'QAYAmP34mP1QcGAYmBggQAKImAIIAAACAHj/SAeABfAAAwAYAAABIRUhAyEVIQIHJCUmJzcSEwcnBAUnABMhASgFqPpYsAcI'
    '/Gjw6AGwAghYaJjIiKhA/bD9sEgBULj9UAXwmP5wmP3g4BBgyLBA/sD+eEjAeAigAUgBwP//AGj/iAegBngSJgNYAAAQBgNX'
    'AAAABABg/zgHqAaAAAkADwAVACkAABMhJic3FhchFSEFFwIFJyQlBBcHJicTFwYHBAUHJCUEBSckJSYnNxYXNpADEChAqEgw'
    'AxD5KAH4gND+uGABGAPIAQjYeOD4WJiA0AF4AZBg/gD+0P6A/hhQAfABMOiwiKjwyAVweGA4gJCYOGj/AKCYgOCg0JDoqP7o'
    'QPi42FiomND4eKBo0LDYaOCoqAAAAQBY/0gHqAZQAA0AAAEzERQAAQcAAwIBJwARA6CoAXAB8Fj9mOC4/WBYA0gGUP5IyP0g'
    '/wCoAUACiP2w/oiYAfACyP//AFj/OAeoBoASJgRjAAAQBgMdAAD//wBQ/0gHkAZ4EiYFSAAAEAYFEwAAAAMBCP9IB5gGeAAP'
    'ABgAHgAAATMQAgcSEwcCJwIFJyQAEwEzESQ3FwQFJwESEwcCAwWgoCAw8LiIoMjA/khoAXABCGD7aKABCPBI/uj+oGgB8NCA'
    'mHjIBnj9gP7AoP7w/tiIASD4/pjAiKABsAIYAfD7EHiYiLCocATg/vj+4FgBIAEI//8AUP9AB6gGeBImAz8AABAGBUYAAP//'
    'AFD/SAdYBngSJgTDAAAQJgVHAAAQBgMcAAD//wBQ/0gHoAZ4EiYFSAAAEAYDoQAA//8AUP9IB4gGeBImBUYAABAGBAYAAP//'
    'AFD/QAegBngSJgRAAAAQBgVJAAAAAwBo/0gHoAaIAAwAEAAmAAABFwYHAAUHJAEABScAAyEVIRMhNSEVIQIHJCUmJzcWEwcm'
    'JwQFJzYEAKggKAGQAbBg/mD+YP6g/hhQAoCIA0j8uJD9yAaQ/HCwsAGQAahYWIjg2IBIWP3Y/Zgw+AaIODAo/pjAoMABoP6Q'
    '8JABUP7omP6ImJj+yIgYUFhgYMj+6IBoYHAgkKgA//8AUP9IB1gGeBImA50AABAGBUkAAP//AFD/SAeYBoASJgVJAAAQBgSi'
    'AAD//wBQ/0AHoAZ4EiYFRgAAEAYEfwAA//8AUP9IB5gGeBImBU8AABAGBUYAAP//AFD/QAeoBngSJgVGAAAQBgR9AAAABABo'
    '/0gHoAaAAAsAJAAqADAAAAEXBwAFByQBAAUnAAEhNSE1IRUhFSEVIREUBiMiLwEWMzI1ESEFFhcHJiclFwIFJzYD4KAoAYAB'
    'yGD+SP5o/qD+KFACaP4gAtD+mANw/pgCuP1IUIhgUCBoaDj9MATIyNCIqOj9AHi4/vho8AaAMDj+uLigwAFw/ojwmAFI/YjY'
    'mJjYmP4AcFgQoBhIAeiAqNiA2NBYYP8AqJCIAP//AFD/SAeYBngSJgVGAAAQBgVNAAD//wBQ/0gHqAZ4EiYFSAAAEAYFKgAA'
    '//8AUP9IB5gGgBImBUgAABAGBBAAAP//AFD/SAegBngSJgQAAAAQBgVIAAD//wBQ/0gHWAZ4EiYFHAAAECYEtQAAEAYDnAAA'
    '//8AUP9AB7gGeBImBMYAABAGA7UAAP//AFD/SAewBngSJgVGAAAQBgOaAAD//wBQ/0gHmAZ4EiYFRgAAEAYDmQAA//8AUP9I'
    'B5gGgBImBUcAABAGA8gAAP//AFD/SAeQBoASJgVIAAAQBgNiAAD//wBQ/0gHkAZ4EiYFRgAAEAYFBgAA//8AUP9AB3AGgBIm'
    'BUgAABAGAycAAP//AFD/SAegBngSJgVIAAAQJgSNAAAQBgTYAAD//wBQ/0gHeAaIEiYFRwAAEAYDugAA//8AUP9IB6AGgBIm'
    'BUYAABAGA5IAAP//AHD/SAeQBoASJgTJAAAQBgMbAAAAAQCQ/1AHkAZ4AC0AAAEXBgchETMRIRUhESEVIREUFjMyPgE3FwIG'
    'ISImNREhAgUnJBMhNSERIQYHJxICGKAoOAFooAKQ/XADEP24OHCoSCAIqBCA/tDIiP7IIP3QaAHoKP34Ayj+UFBgkOgGYDCI'
    'gAFQ/rCY/qiY/aggICBo0DD+yJBAaAKQ/VCgmIgCMJgBWKh4cAEoAAADAGj/SAeIBngAHQAjACkAAAEzESEVIREUFjMyNjcX'
    'DgEjICY1ESECASckEyE1IQEXAgcnNiUWFwcmJwOoqAMI/bhQuIg4CKgQaPj+8KD++Fj90HACAFD98AMAAqiYmKhwsPvgkJCQ'
    'gKgGeP0YmP1AICA4wDjwaEhYAvj9WP74iOgCQJgCWFj/AJhouMCg4HDIwAAAAwBw/0gHqAaAACsAMAA1AAABFwchFQYHIREh'
    'ERQWMzI2NxcCBwYhIiY1ESMGBwYFJyQTIREhNjchBgcnJBMhNjchASERIQYCkKhYAtBIUAHQ/gBIkOhQCKgQSEj+uOiQMEjg'
    'uP7YaAHwwP4oAtBgQP1wyJiQAXBAAXgoEP5QAigCAP4oCAaAOHiIgGj9gP5QICBIyDD/AEA4SFgB6ODIqEiYgAGAAoBoeMBg'
    'aOD9EJDA/rABULgAAAEAaP9IB7AGeAATAAABJic3EggBFwcuAQInAwIABSckAAO4WGiY2AEoAUDggIDYwFCoqP5o/uBYATAB'
    'gATgqJBg/tj8uP5IeIhA4AEg0AGo/ij94Mig4AIwAAIAWP+YB7AGiAAeACMAAAEVIREhFSERIRUhNSERITUhESE1BgcnAAEX'
    'BwAFByYBAgUhJAZo/fACOP3IAtj5mALo/cgCOP3YaHhQAngBEKgoAZABwGB4/Sjo/uAEEP7YA5hQ/sCY/sCYmAFAmAFASEBA'
    'oAFYAYAwOP5w2KhAAlj/AMjYAAMAkP9IB6AGKAAFAAsAHAAAARIBBwABJRcCAScAAQATBycEBScAExcAByQlJicFeNgBUGj+'
    'mP8A/dCg2P64kAFoA1gBCKCYUP3A/chIAXjQoP74+AGYAfBwiAYo/hj+6LgBYAIoMDj9wP64cAF4/gD+wP6QWLhgEKgBiAJA'
    'QP1w+BBIwLAABACI/0gHcAZwABMAFwAdACMAABMhETMRIREzESEVIREhFSE1IREhASERIQMXAAUnJCUEBQcmJdgBaKACMKAB'
    'cP6QAcD5GAG4/pgCCAIw/dAwmP8A/vCQAUADaAEIAQCg2P7gBPgBeP6IAXj+iJj9+JiYAgj9+AII/RhY/tCogMjouPiA8OAA'
    'AAIAeP9AB6AGgAAfACUAAAECBSckEyE1ITU2ESE1ITY3FwYHIRUhEAchFSESBQckARYXByYnBBB4/Vh4AqhY/UgC0Aj9iAOA'
    'gECwSHABoP1ACAMQ/UDQAlBo/dD9cHBAiEBoAeD+MNCYwAGwmDgQASiYyNBAuKCY/pgImP5QmMC4BniIkFCQiAAGAGj/QAeQ'
    'BnAAEwAXABsAHwAlACsAABMhNTMVITUzFSEVIREhFSE1IREhBSE1IREhNSERITUhExcGBSckJQQFByQl4AEIoAMQoAEA/wAB'
    'WPjYAYD++AGoAxD88AMQ/PADEPzwUHDY/mBIAWgDMAFQAQhw/uj+wAWQ4ODg4KD8qJCQA1jAwP3o0P3wuP6AeKB4oFCgcJiI'
    'qHAABgBo/0gHmAaIADQAOAA8AEAARABIAAABFhchNjcXBgchFSEVIREzFSMRIRIFByQDESMRIREjEQIFJyQTITUhNSE1ITUh'
    'NSE1ITUhJwE1IR0CITUzFSE1ARUhNTMVITUCkGhoAThwQLA4aAIQ/aAB2Li4/oDoAVBQ/rDwmP7omMD+0GgBOND+iAHI/agC'
    'WP5IAbj90AIIgAJY/ugBGJgBSP0IARiYAUgGiGiIeHg4WGCIqP7YiP7Y/vh4oJgBIP4gAkj9uAHY/viokJABAIigiKCIqIig'
    '/jCoqIigoKCg/tigoKCgAAABAPD/SAcYBoAAIQAAATMRIREUBiMiLwEWMzI1ESEGBwQTBwInAgUnABMhESMRIQOooALQeHB4'
    'qCjYaFD9yAgYASj4cOD4kP64UAGwKP3ooAK4BoD+mPsYcGggqCBYBChoYPD+yIgBOOD+qPCYAUAB0PrIBdAABQBg/0gHoAYg'
    'ACAAJAAoACwAMAAAEyEVIRUhETMVIxEUBiMiLwEWMzI1ESERIxEjNTMRITUhASE1KQEVITUBITUhBSE1IagGsPz4AoDQ0IB4'
    'cJAowGBg+5igyMgCgP0AASAB4P4gAogB4PuYAeD+IAKIAeD+IAYgmMj9EJj+0GBgIJggUAEI/hAB8JgC8Mj9uOjo6P2o4ODg'
    '//8AiP9YB2gGMBImBMUAABAGAxoAAP//AGj/SAdYBngSJgTEAAAQBgTvAAD//wBo/0gHsAZ4EiYExAAAEAYDkQAA//8AaP9I'
    'B6AGgBImBMQAABAGBHwAAP//AHj/SAeoBoASJgVDAAAQBgPAAAAAAQBo/1AHmAYQABoAAAERFBYzMjY3FwIHBiMiJjURIREQ'
    'AgcnNhIZAQWYMGB4SAioEEhA6MhY/ZjQ6HDAyAYQ+jgoIGj4MP7gYFBIeAVY/cD+oP4wuIiQAbgBaAKIAAEA2P9IBxgGeAAb'
    'AAATMxEhESERMxEhETMRIREzESM1IREhETMRIzUh2KACMP2AoAHgoAHYoKD+KAIwoKD6YAKY/aADGAKI/hACkP1wAfD9QDj8'
    '6AJg/LBYAAEAgP9QB4AGeAAdAAATIREhNSERMxEhFSERIRUhESERMxEjNSERMxEhESGAAzj9cAKQoAKw/VADKPzYAeigoPsQ'
    'oAHI/MgDeAFAmAEo/tiY/sCY/XgB+P0AcAKQ/ggCiAD//wCY/1AHaAYoEiYEMgAAEAYDGQAAAAMAcP9IB6AGcAAFAAsAIQAA'
    'AQAFBwABJRcAAScAAyEQAiMiLwEWMzI2EyECAAUnJAATIQUoASgBUGj+sP7I/jB4/vj+kHABWBgEoHCwYIAgiGBAOBD+EBj+'
    '4P6ogAFAAQAo/qgGcP4w8LABAAHweGD+KP7AmAEI/tD9GP7gEKgQoAIo/rD+cKCIkAFQARgA//8AaP84B1gGeBImA5MAABAG'
    'BGEAAP//AHj/SAcwBngSJgQNAAAQBgUjAAD//wBg/0AHMAZ4EiYFIwAAEAYDkAAA//8AsP9IB1gGcBImA48AABAGBPcAAP//'
    'AEj/QAdABnASJgRdAAAQBgTCAAD//wCQ/0AHWAZ4EiYDjAAAEAYE9wAA//8AYP9IBzAGeBImAyUAABAGAyQAAP//AGj/SAdY'
    'BngSJgO8AAAQBgT3AAD//wA4/0gHWAZwEiYDuwAAEAYE9wAAAAcAiP9IB4AGkAAFAA8AHAAtADEANQA5AAABFhcHJiclFwYH'
    'IRUhNSE2ATMRFAYjIi8BFjMyNQERFAYjIi8BFjMyPQEhESMREyE1IREhNSEBMxEjAphYOJg4UANouFhYAgj5CAQwaAFYmEhw'
    'eHAgeHg4/WBgaEhYIHhAQP5AkJABwP5AAcD+QANYmJgGkGiAQHhoMDiIaJCQkP6A+8h4WBigIGAD0Pv4YGAQmBBQuP5QBNj+'
    'sMD9+MABsPygAP//AFj/SAdYBnASJgT3AAAQBgRKAAD//wBw/0gHYAZ4EiYDrAAAEAYFGAAA//8AeP9IB4gGgBImA4oAABAG'
    'A4kAAAABAID/QAcIBnAAGwAAEyERMxEhEAIGIyIvARYzMjYSESEVEAEnABE1IegCMKADUDiIqICAKJiQUEgo/Vj9IFgCmP3Q'
    'BRABYP6g/Oj+GKgQoBBYAgACGCD84P4IkAHQArgg//8AaP9IB2gGeBImBCUAABAGBGIAAP//AEj/MAdQBngSJgQkAAAQBgNg'
    'AAD//wBw/0AHeAaIEiYELAAAEAYELgAA//8AaP9IB2gGeBImBCMAABAGA4gAAP//AFD/SAeYBngSJgVJAAAQBgQzAAAAAgBw'
    '/2AHoAZoAA0AJQAAATMRIxEGBSckJREhNSEBMxEkNxcEBREUFjMyPgE3FwIOASMiJjUCoKCg4P7wQAEwAQD96AIYAdigARDw'
    'aP7o/rBImJhAIAioCEB46PiIBmj4+AG4oHiwiKACIKAB0P2oiLCQyJD8+CAgKHDgMP8AoEBIWAAAAgDQ/5AHcAY4AAcAGwAA'
    'ARUhESEVIREBFwYHFhcHJicGASc2ASYlNwQXNgcw+kAGAPlgBNiYmMDYwIC40KD+iGDwARDo/viAAQDYsAY4mPqImAao/vhQ'
    '+PDY6IDo2Mj+6JCgASjo2GDQ0NAAAQB4/0gHiAZ4AAsAABMhETMRIRUhESMRIXgDMKADQPzAoPzQBAgCcP2QmPvYBCgAAQCI'
    '/0AHgAZQABIAAAEXBgURIRUhESMRITUhEQQFJyQGeIi4/ggDMPzQoPzYAyj++P6gaAPABlCQMDj+EJj8cAOQmAHYGBigSAAB'
    'AID/SAeABngAHgAAARcGBxEhETMRIRUhESMRIRUQAScAETUhNSERBgcnJARASLjQAlCgAZD+cKD9sP4IaAG4/igB2LDAOAHw'
    'BliQQDD+IAMA/QCY/GgDmCj96P6wiAEwAbAomAG4KCCYSAADAHj/QAeIBoAAEwAZAB8AABMhETMRIRUhESEVIREjESE1IREh'
    'ARcGByc2JRYXByYn2ALYqALQ/TADMPzQqPzIAzj9KAVokICYeJj8AKBgmFiYBBACcP2QmP6wmP2wAlCYAVACsEj4iHCYuKDA'
    'WMCoAAADAFj/SAeQBngAFwAbAB8AAAEzFSEVIRUhESEVIRUhESMRITUhNSERIQEhNSERITUhA2iYA0D8wAKo/ZgDUPywoPy4'
    'A0j9uAIQ/pgECPv4BAj7+AZ4gJiY/QiYmP6oAViYmAL4/sig/jiYAAAGAIj/OAdwBogABQAbAB8AIwAnACsAAAEWFwcmJyUX'
    'BgchESEVIRUhESMRITUhNSERITYBITUpARUhNQEhNSkBFSE1AqhYQJA4WANIqDhYATD9oAMg/OCo/OADIP2gA4Bo/LgBwP5A'
    'AmgBwPvYAcD+QAJoAcAGiFhwQHBYQCiQePyYuJD+kAFwkLgDaJj+ANDQ0P3I0NDQAAIAaP9IB5gGeAAcADgAABMhNTMVIRUh'
    'FSERFAYjIi8BFjMyNREhESMRITUhARYXMzY3FwYHMxUhFSEVIREjESE1ITUhNSEmJ2gDSKADSPy4AtBwcGCIKLBYUPrgmALg'
    '/LgCmGhAwEAwoDA4+P5AAfD+EJj+CAH4/kABEDhIBbjAwJjA+7hgaBCgEFADkPt4BRjA/ohweHh4KHBYkLCQ/rABUJCwkFBI'
    'AAIAmP9IB3gGeAALABUAAAEVIRUhNSERMxEhFQEzFQQFByQlESMEKANQ+SAC8KACePzooAF4ARBo/vj+6KAE0PigoAKg/vCY'
    '/hDQqJiYqIj94P//AND/SAdQBgASJgNdAAAQBgUzAAAAAQBQ/0AHcAY4AAkAAAEVIREQAycSGQEHcPoYqJCYBjiY/Wj96P5Q'
    'WAGoAfgDAAD//wBQ/0AHcAY4EiYA0gAAEAYDGAAA//8AUP9AB3AGOBImANIAABAGAxcAAP//AFD/QAeIBjgSJgDSAAAQBgMW'
    'AAAABQBg/0AHqAaAABEAJgAsADIAOAAAARcGByQlJic3FhcHJicEBSckASE3FwYHIRUhBAUHJAEhAgUnJDchBRcEBSckBRcE'
    'BSckJRcABSckA0iQoKgBcAGISFCAyMB4OED9yP2IKAE4/ggCkFCYEBgD0P34ARABEGD+uP64/qDg/jBIAXCo/fgEQGj+wP4A'
    'UAIQAfBo/mD9aFgCqAJwYP4Q/GhYA8AGgCjQcBAwQEBYkMCAQEBIGIiA/oh4OCAgmMBooJgBMP7weJBYoFB4yGiAeDB4+ICI'
    'kBBw/phoiID//wBo/0AHqAYQEiYE9QAAEAYE9gAAAAMAUP9IB2AGcAAkACkALwAAAQYHIRUCBxYFByQlBAUnJCUmJwIFJwAT'
    'IScTFwMhNhMXBgchFQE2NyEWARYXByYnA4AoKAOQmODwAShI/rD+6P7Y/nhQAXABAMiQuP6wcAHwmP5AMKiYiAFoQDCYMDAD'
    'eP2I0Hj9WJABsJCIcICoA/B4aHj+0LCAWJhgsLhYoEiIoOD+wPhwAZgB6IgBgCD+uNABECj4wKD9KJDQ0ASgcJhwkJD//wBo'
    '/0gHqAY4EiYDKwAAEAYDhwAAAAYAmP9IB3AGeAAFABMAGQAfADEANgAAARcEBScgBRcGByERIzUhFSMRITYlFhcHJiclFhcH'
    'JicTIRUGBwQFByQlBAUnJCUmJyMhFhc2NwbAUP2Q/HgwAugCaLhgeAFIoPqAoAS4kP4IYCigKFj+mGAooChYKASgkMgBEAGY'
    'WP5Q/sD+oP4wYAHIASDokIgBSIDYwHAGeJBQEJB4QLiQ/pDY2AFwyJBwkDiQeCBwiDiQcP2QkOiQeEioWKi4UJBQkJjYqHiA'
    'oAD//wCg/0AHgAZ4EiYDTgAAEAYECgAA//8AoP9oB2AGYBImBBgAABAGBBcAAAACAUj/YAbABeAABwALAAABESM1IRUjERMh'
    'ESEGwKD7wJiYBED7wAXg+YCwsAaA+sgEoAAABAB4/0gHeAYIAAMABwANABMAAAEhESE3IREhAQQBBwItARcABSckAXAFIPrg'
    'oAPg/CADEAFYAQCI+P6o/iiI/wD+mHABgAYI/DiYApj8WOj++IgBKPBgYP6oyIDoAAMAaP9IB6AGCAARABcAGwAAEyEVIREU'
    'BiMiLwEWMzI2NREhAREhFSMREyERIWgHOP7QcKhYSCBYUFg4+pgD4P2goKABwP5ABgiY+qhwYBCYECg4BTD+yP1AcAMw/dgB'
    'kAAAAwCo/0gHWAaAABAAGAAcAAABABMHJwQFJwATFwAHJCUmJwERIzUhFSMREyERIQWIASCwmGD9SP1ISAGg8KD+6PAB4AJI'
    'cIgBoKD74KCgBCD74AWY/wD+4FiYcBCYAQgBqED+QKgQWIh4/VD8uIiIA0j90AGgAAMAYP9IB6AGeAAbAB8AIwAAATMVIREh'
    'AgcEBQckJQYFJyQ3Jic3Fhc2EyERIQEhESEBIREhA7CoAqj9UBiQAYACeDD9eP5I4P5QQAFwyNiQgJjQgBj9UAKw/fACEP3w'
    'ArgCAP4ABnjw/Sj+yLi4GKgY4LBIoDiAkLBYuHCQARAC2P3AAaj+WAGoAAIAWP9YB3gGeAAZAB0AABMhNjcXBgchFSEGByER'
    'IzUhFSMRBgcnABMhASERIYgCeDggqBg4A8j8AGCgBGig/HCgmLhoAcig/cgCKAOQ/HAFKJi4GKCYmPC4/HCQkAMokHiQASgB'
    'YPvwAdAA//8AcP9IB3gGiBImBCwAABAGBBQAAAAEAFD/SAeoBpAADAAQABgAHAAAARcGBwAFByQBAAUnAAEhFSEFESM1IRUj'
    'ERMhESED8KgYIAGQAbhg/lj+YP6I/iBYAoj+yAS4+0gFAKD78KCgBBD78AaQMCAg/sCwoLgBcP6g2JABMP6goNj84ICAAyD9'
    '+AFwAAAEAMj/OAc4BjgAEAAUABgAHAAAAREUBiMiLwEWMzI1ESERIxEBIRUhFyERITchESEHOHBwYIAgqFhA+tCgATAEGPvo'
    'aANI/LigAgj9+AY4+dhgaBCgEFAFaPmYBwD+iJjg/ZCYAUAAAAIAYP9IBxgGeAAfACMAAAEXBgchFQAFIREjNSEVIxEGByck'
    'ASEHFhcHJicGBycAEyERIQMoqCgwA5D+2P1YA+Cg/DigmKhwBEgBkPzAeIiAcICYYHCQAdBAA8j8OAZ4ODg4iP4w8PzAeHgC'
    '6CggsJgCCHBgcHiAYEhAcAEI+wgBmAADAFD/SAdoBmgAEAAYABwAAAEXBAUVIRUhEAIHJzYSGQEkAREjNSEVIxETIREhBqhQ'
    '/dj9EAWI+nhwkJCAaANYAlCg/OCgoAMg/OAGaJBQKPiY/fD+QLB4kAGoAiAByDD8oPyYiJADcP24AbAAAAMA4P9IByAGgAAW'
    'ABoAHgAAARcGByERFAYjIi8BFjMyNREhESMRITYDIREhNyERIQMwwDBYA7hwaGiIILBYOPsQqAHIUIgDGPzomAHw/hAGgDho'
    'gPq4YGgYoBhQBIj6gAYYeP3o/VCQAZAA//8AYP9IB5gGOBImAy0AABAGA1oAAP//AHD/SAewBoASJgNcAAAQBgNbAAD//wBY'
    '/0AHMAaAEiYDLAAAEAYDFQAA//8AoP9IB5gGMBImBSgAABAGA2YAAAADAGj/SAeYBngAFgAeACIAAAEXBgchETMRIRUhESEV'
    'ITUhESEGByc2AREjNSEVIxETIREhAfigMDABgKACuP1IA0D40ANQ/ig4UIjIBSig+9igoAQo+9gGcDiAYAEg/uCY/uCYmAEg'
    'YGBo8P0A/PB4eAMQ/gABaAAEAFj/SAcgBkAAFQAlACkALQAAAREUBiMiLwEWMzI1ESEREAMnNhIZAQEhNTMVIRUhFSEVITUh'
    'NSETIREhNyE1IQcgWGB4qCi4cDj7QNCYcFgBMAF4oAGA/oABuPwQAZj+iFADCPz4mAHY/igGQPnYYGgQkBBoBWD9aP3g/lhg'
    '+AGIASAC+P6AmJiQsJCQsP5I/hiI2AAFAGD/QAeoBpAACwAPACAAKAAsAAABFwcABQckAQAFJwADIRUhBREUBiMiLwEWMzI1'
    'ESERIxEBFSMRIREjPQERIRED+Kg4AZABsGD+UP5g/pD+KFACgOgEEPvwBSBwcEBgKIBASP6AoP04kAJwmP64BpAwOP7gkKCo'
    'AUD+0MCQAQj+2JCw/fBoaAioCFgBSPzYA8D9SKADWPz4UJgBkP5wAP//AKD/QAeoBmgSJgPlAAAQBgNqAAD//wCg/0AHaAaQ'
    'EiYEmAAAEAYDagAA//8AoP9AB4gGKBImA5UAABAmA5YAABAGA2cAAP//AKj/SAeYBoASJgO5AAAQBgNpAAAACQBY/0gHmAZA'
    'AAMABwALAA8ALAA0ADgAQABEAAABIREhNyE1ISUhESE3ITUhAyE2NxcUByEmJzcWFyEVIRYFByQDIwYEBSckNyEBESM1IRUj'
    'ERMhESElESM1IRUjERMhESEEaAKY/WiYAWD+oPwAAoj9eJABaP6YuAKYIAiYGAFwGCB4SEABCP2gwAHgOP3I6GhI/nD+wGgB'
    '2Mj94ALQoP64mJgBSP64BTig/qCgoAFg/qAGQP4QkNCQ/hCQ0P34SFAQSEAgGFhAUJCgMJA4AShoyCiQOJD+mP2YSEgCaP5w'
    'AQCQ/ZhISAJo/nABAAD//wCo/0gHuAZQEiYEvwAAEAYDaAAAAAIAuP9IB0gGOAAHAAsAAAERIzUhFSMREyERIQdIoPqwoKAF'
    'UPqwBjj5EHBwBvD6GAVQAP//ALj/SAdIBjgSJgD2AAAQBgMUAAAABADg/0gHKAYIAAcACwAPABMAAAERIzUhFSMREyERIQUh'
    'ESE3IREhByig+vigoAUI+vgBCALw/RCgAbD+UAYI+UCQkAbA+mgFAPj88JgB4P//ALj/SAdIBjgSJgQpAAAQBgD2AAD//wC4'
    '/0gHSAY4EiYEUAAAEAYA9gAA//8AuP9IB0gGOBImBE8AABAGAPYAAP//AMD/SAdABjgSJgQ7AAAQBgSeAAAAAgBA/1AHgAaA'
    'ABgAKAAAEyE2NxcGByEVIQIHESMRBgcnNjc1MzY3IQEhETMRIRUhESEVITUhESGAAjg4MKAoKAQQ+6iQkKBYYHCgiGhIWP4Q'
    'AjgB4KAB8P4QAjj66AJA/iAFgICAIHhomP7QuPxQAuhgWICgqIhwqP4YAYj+eJj90JiYAjAA//8AWP9wB6AGeBImBPIAABAG'
    'BPAAAP//AFj/SAdYBlgSJgTyAAAQBgOpAAAAAwBQ/5AHmAaAAA8AHAApAAATIREzESEVIREhFSE1IREhARcGBxYXByYnAgcn'
    'AAEXBgcWFwcmJwYHJwD4ArCgAsD9QANI+OADOP1QBMigECi4uICAqHCoeAEw/CCgECi4uICAqGiweAEoAhgEaPuYmP6omJgB'
    'WASIKIiAyPiA0Mj/ALh4AVgBwCiIgMj4gNDI8Mh4AVj//wBY/0gHsAZ4EiYFNwAAEAYE8gAA//8AaP+AB5gGeBImBGcAABAm'
    'BGYAABAGBGgAAP//AFj/QAegBngSJgTyAAAQBgS7AAAABQCA/5AHgAZgACUAKQAtADEANQAAARcEBRUhFSERIRUhESEVIRUh'
    'FSE1ITUhNSERITUhESE1ITUFJyABESERIxEhGQEhESkBESERBrBQ/sj+gAMQ/tgBUP6wARj9AALw+aAC0P0YARD+sAFQ/uAC'
    '+P2IMALYAcj+qKD+wAFA/sAB4AFYBmCQGBi4kP7omP7gkNiQkNiQASCYARiQsBCQ/SgBGP7oARj+6P5IASD+4AEg//8AaP+A'
    'B5AGWBImBGcAABAmBA8AABAGBA4AAP//AFj/QAewBngSJgTxAAAQBgPQAAD//wBY/0gHoAaAEiYE8QAAEAYEewAA//8AWP84'
    'B5gGgBImBPIAABAGBMAAAP//AFj/QAewBogSJgTxAAAQBgNMAAD//wBo/zgHgAaAEiYDWQAAEAYDEwAAAAMAcP9QB6gGgAAa'
    'ACEAKwAAARcGByEVFAIHFgQFBywBJwIFJyQTJgMGBycSNxIXNhMhBgEzEQQXByYnESMB8JggMAHomFioAfAB2Ej+KP4QwND+'
    '4EgBILhwWFhwcPCYWIB4OP6ICAMQoAEo0GCw6KAGgDCgmKA4/fCgyMAIqAjI2P7YiKB4ARC4AUC4qHgBmDD+sODoAXAQAhD9'
    'wIjAkKiA/SD//wBw/0AHeAaIEiYELQAAEAYELAAAAAQAoP9AB1gGgAAmACoALgAzAAABFwchFSEHIREhBgchFQYHBAUHJCUE'
    'BSckJSYnBgcnJDchEQYHJyQTITUhESE1IRMWFzY3AjCYMARY+2BYBHD9ACg4A1CI8AEAAXhA/jD+wP7Q/lBoAXgBGJBwgIh4'
    'AUCo/vhIWHABEKADgPyAA4D8gJiAqNiIBoAgcJCA/aBAQJCocEgoqDCQcFCYOFhgiGBIkIjAAghYSHjo/qho/rhg/gB4UFB4'
    '//8AeP9QB1gGeBImBScAABAGBFsAAAACAID/QAb4BogAGQAwAAABFwYHIRUABSckASEHFhcHJicGByckPwEzNhMXBgchFQAF'
    'JyQBIQYHFhcHJicGByckBAigQFACmP7I+6BABAgBGP1YcFhYcGB4aGhoAXCYCAiIuJAwOAJo/qD7KEAEkAEw/ZCIUGhgeGiA'
    'cHBgAdgGiCBQQJD+GKCgaAGAQEBIcFhYMCBwgHAIWP0wSCgokP3AuKCIAdBgIEhQeGBgOCiIoAD//wBI/0AHeAZ4EiYEmwAA'
    'EAYECAAAAAEAWP9IB7AGcAASAAATIREzESEVIRIBBwABAgEnABMhsALosAMQ/RDYAnBY/cj++LD9SFgDCDD9IASgAdD+MKD9'
    'CP7wsAEIArj9uP6ImAG4AmgAAAEAcP9AB5gGGAAZAAABIRUhEAchFSESBQcAAwIFJyQAEyE1ITYRIQEIBeD9WAgDIPzw4AJw'
    'cP242JD9WGABiAFwIP0QAwAI/WgGGJj+YDCY/cj4qAEYAdj+CPigiAGQASCYaAFoAAIAWP9IB6AGgAAUABoAABMhETMRFAch'
    'FSEAAQcAAQIBJwATIQEWFwcmJ6ADEKgIAwj88AFgAfhY/gD+wMj9cFgCyHj9CAMgmIBwgJgE0AGw/sA4OJj8+P7IsAFYArj9'
    'iP5okAHQApD86GCAiJBoAAADAGD/OAegBngAFwAdACMAAAERMxUhEgUHJAMGAAUnABMhNTMRIREzEQEhNjURKQERFAchEQag'
    '+P0QyAIwWP2w8ED+QP6wWAJwmP0A6AJIoP24AaAI/lgCSAgB0AVA/ZCY/lCgsMACKMD+cIiIAQgBYJgCcAE4/sj9kCggAZD+'
    'cCAoAdgAAAEAaP84B7AGeAAlAAABFwYHIREzESEVIREUByEVIRIFBwADAgEnABMhNSE2NREhBgcnEgIAmCAoAYCgAoD9gBAD'
    'AP0Y+AJAaP2Q0Nj9kFgCaLD9QAMAEP44YIB46AY4IIh4AWD+oJj/AFBQmP5YuKABAAGo/lj+8JgBEAFomFBQAQDYkHABEAAE'
    'AHD/SAeIBngAEgAYAB4AIwAAEyE2EhEzEAcUByEVIQIFJyQTIQEWFwcmJwcWFwcmJwEEFwcBcAOwMCCgCDgCuP0Q2P1YWAJg'
    'uPyYAdDowHi42GjowHi42ARIASDocP4AApiAATACMP3AEOCwmP4o4JDYAVAEGICogLh46ICoiLh4/TDQuIgBkP//AGj/QAeg'
    'BoASJgP2AAAQBgMSAAD//wBo/0AHoAZ4EiYFAAAAEAYEKgAA//8AaP9AB5AGgBImBRIAABAGAx8AAP//AFj/QAeQBngSJgPx'
    'AAAQBgPwAAAAAQB4/0gHiAYwABsAAAEhFQQFFSEVIREUBiMiLwEWMzI1ESE1ITUkJSEBQAWY/uD+oAMw/NBwcJCIGHCYYPzI'
    'AzgBSAEI+0AGMLDw0IiY/UBIUCCYICACoJjYyLgA//8AiP9AB3gGiBImBQsAABAGAxEAAAACAFj/SAeYBoAAFwAzAAATITY3'
    'FwchFSECBxEjEQYHJzY3NTM2NyEFIRUGBxUhFSERFAYjIi8BFjMyNREhNSE1NjchiAI4MCiYQAQI+7CIiKBYYGioeGBwKP4Y'
    'AtADaIioAgj9+GhoSEgYOEho/agCWIh4/VgFsGhoMKCY/uiw+/gDSGBYaKiogLhQ0LCQiFiY/lBQSAiYCBgBmJiocHD//wBo'
    '/0gHmAaIEiYDNwAAEAYDEAAA//8AmP+IB2gGiBImBFkAABAGBFoAAP//AID/QAd4BogSJgULAAAQBgPjAAAAAwB4/0gHqAaQ'
    'AA0AEQAsAAABESM1IRUjESEmJzcWFwEhFSEHIRUhERQWMzI2NxcCBiEiJjURIQIABSckEyEHOKj62KgC8BggqDgY/UgEiPt4'
    '+AaA/fA4eNBICKgQgP7I0Ij+0DD+yP7QSAHwQP4YBcj+mMjIAWhQSDBYcP6ImNiY/gAgIEjQOP8AgEhgAjj+sP6YSKB4AegA'
    'AAIAcP9QB6AGiAANACoAAAERIzUhFSMRISYnNxYXASEVIREhFSERFikBByEgJCcGBycAExcGBxIXESEHWKj6mKADGCAooEAg'
    '/QAFEP3YAiD94LgBAAGIOP6w/ej+iIhguHgBUDigGECg2P3ABdj+oNDIAVhIODBQYP5okP6YkP6AEKiY0OC4eAFwAdgouKj+'
    '+DADYP//AIj/SAeIBogSJgULAAAQBgMPAAD//wCA/0AHgAaIEiYFCwAAEAYDDgAA//8AaP9IB5gGiBImBQsAABAGA9YAAP//'
    'AHD/QAeoBogSJgULAAAQBgMNAAD//wBY/1AHkAaIEiYEPAAAEAYDDAAAAAIAgP9IB3AGeAAVABsAABMhETMRIRUhERQGIyIv'
    'ARYzMjY1ESEFEhMHAgOABJCgAcD+QFB4oJggoKAgIPtwAbjYiJiA2AUQAWj+mJj7uIhgIKggKEAEIJj/AP7YWAEgAQj//wBo'
    '/1AHkAZ4EiYEzQAAEAYEuQAA//8AmP9IB3AGOBImA08AABAGAwsAAP//AGj/UAeYBngSJgUpAAAQBgUUAAD//wBI/0gHmAaA'
    'EiYEqgAAEAYFFAAA//8AUP9IB5gGkBImBCEAABAGAyIAAAADAID/SAeYBngADAASABgAAAEzERQGIyIvARYzMjUBFwIDJxIB'
    'EhMHAgMDyKBQiLCYILiwOP4wmJDgoPgEmOigsJDgBnj5mHBYIKAoSATIOP2o/lhoAbACIP44/ehQAjABwAAABABo/0gHaAZw'
    'AAMACQAPABYAAAEzESMBFhMHAiclFwIDJxIBFwAFJyQAA6CgoAJg2JCgiND8cKCI2JjgBNBw/fD8KFgCOAKYBnD7OAQA+P7Y'
    'SAE48Dg4/jD+wGABSP8AgP2AuJiIAWgA//8AaP9IB5gGaBImBP0AABAGBP4AAP//AFj/SAeoBngSJgRCAAAQBgRBAAAAAgBg'
    '/0gHoAYYABIAFgAAARUQASc2EhkBIREjNSESAQcAAwEhESECEP7omJh4BXig/lCQAnh4/XCgAlD7yAQ4A0hQ/ej+aGDwAYAB'
    'GALo/MBw/eD+wJgBeAKAAjj+YAAABABg/zgHoAZAABAAFAAaACAAAAEVEAMnNhI1ESERIRIFBwADASERIQEEBQckJQMEBQck'
    'JQHw+JiIaAWA/uhYAZBY/jhoARj7wARA/HgBuAEwaP7g/lgYAegBsEj+MP44A+Bw/ij+kGDYAVj4ApD9oP4Y4KABCAJgAcj+'
    '0P6giLCYuIj+wJjYoPiQAP//AFD/QAeoBkgSJgUNAAAQBgMKAAD//wBQ/0AHYAZIEiYFDQAAEAYDCQAA//8AUP8wB3gGSBIm'
    'BQ0AABAGAwgAAP//AFD/QAeIBkgSJgUOAAAQBgUMAAAABQBQ/0AHeAZAACYAKgA0ADgAPAAAASEVIRYXNjcXBgcWFwckAyMR'
    'NjcXBgcnESMCAycSGQEhESEVIRUhEyEVIQURFAchNSE1ITUFNSEVESE1IQXIAaj9WFB4kGhweHCY0FD94OD4kIhAsNhw+DiI'
    'iMAF6P7QATj+yJD7WASo+1gIAXj+yAE4AhD+iAF4/ogCQIiIaEBoeFgwWDiQoAHI/kA4QIBYWGgCEP6g/wBoAWABuANo/iDI'
    'kAKw0Ij+eEhQyJDIyMjI/qjI//8AYP9YB6AGSBImBQgAABAGAoYAAAABAGj/iAd4BngAHAAAEyE2NxcGByEVIQIHIRUhESEV'
    'ITUhESEGBycAEyGwAfgoEJgQGAP4++BQcASI/bAC2PmIAwD+GIiweAGIkP4wBVCQmCCIgJj++MCY/ciYmAI44Lh4AagB2AAB'
    'AMD/gAd4BggAHgAAEyERIzUhERQWITI2NTI+ATcXAgYhIyAmNREzESERIcAFwKD76JgBkODgoFAwCKA44P2QoP6YwKAEGPrg'
    'Bgj8cID9iDgoCAg4qJBA/ph4WGgEWP74AeAAAQBY/0gHgAaIACkAABMhNjcXByEVIQYHIREzESERFAYjIi8BFjMyNREhESMR'
    'IREjEQYHJwATIYgCSEg4oGAD8PvIUIABoKACQHBoWHAomFBA/mCg/miggKBoAUDo/ggFcIiQMOiYoMgBMP7Q/XBgYBiYGFAB'
    '0PxwA5D9GAK4oIhoAVABoAADAJD/OAdoBoAAGwAjADwAAAEzFSE1MxUhNTMVIRUhFSM1IRUjNSEVIzUhNSEBESM1IRUjEQER'
    'FAYjIi8BFjMyNREhESMRIREjESE1MxUB0KABQKABOKABQP7AoP7IoP7AoP7IATgFmKD6aKAF8GBoWHgooFBA/lig/ligAkig'
    'BnjAyMjIyJj4+PDw+PiY/jD+kODoAXj+cP5AYGAQmBBQAQj9cAKQ/ggCiMDAAP//AIj/KAeABngSJgS+AAAQBgQBAAAAAwCY'
    '/0AHYAZ4ABcANAA4AAABMxEzNjcXBgchESM1IRUjESEmJzcWFzMBIREhFSERFAYjIi8BFjMyPQEhESMRIREjESE1ITchNSED'
    'oKD4UDioQEABeKD6eKABcDBAiGA46P44BED+OAKIcHBIaCCIQEj+GKD+GKACiP4omAMQ/PAGeP7geIAwcFj+sMjIAVBoYEB4'
    'kP7o/jiQ/ohYYBCQEEjQ/eACIP5YAjCQgMj//wCI/0gHcAZ4EiYEvgAAEAYDuAAA//8AYP9IB8AGeBImBKAAABAmA1EAABAG'
    'AwcAAAABAJj/SAdoBfAADwAAASEVIREhFSERIxEhNSERIQEABgD9UAMY/Oig/OgDGP1QBfCY/eCY/KgDWJgCIAADAID/UAeA'
    'BigADwAVABsAABMhFSERIRUhESMRITUhESEFFwIHJxIlFhMHAifgBjj9QAMo/Nig/MgDOP0oBTCoaIigmPwImGioYJAGKJj8'
    '4Jj9eAKImAMgYDj+uOhYARDo6P7gSAEg6AAAAwBw/ygHmAaIAAUAIQAlAAABFhcHJiclFwYHIRUhESEVIREjESECASckEyE1'
    'IREhNSE2AxEhEQJYcGiAYIADoLBgYAHY/ngB6P4YoP3wGP4IWAGwGP4QAfD+iAPAcAj98AaIaJBogIBYMMCImP44mP04Asj+'
    'OP7gkPABaJgByJiw/PAByP44AAEASP9AB2gGgAAQAAABFSEREAMnNhI1ESEmJzcWFwdo+lDYmHBgAvggOKBIIAWQmP2w/gj+'
    'kFjoAWj4ArBgWDhwgAD//wBQ/0gHaAaAEiYE7AAAEAYDBgAA//8ASP9AB5gGgBImAUUAABAGAwUAAP//AFD/SAeABoASJgTs'
    'AAAQBgR+AAD//wBQ/0AHoAaAEiYE7AAAEAYDBAAA//8AUP9IB5gGgBImBOwAABAGAwMAAP//AFD/QAeABogSJgPhAAAQBgMC'
    'AAD//wB4/0gHsAZ4EiYDpQAAEAYEugAAAAIAeP84B5AGIAAXAB0AAAEhFSERIRUhESMRIQIBJwATITUhNjURKQERFAchEQEY'
    'BgD+yAGw/lCg/cBQ/lB4AZBI/hgB+Aj+oAIACAIwBiCY/dCY/IgDeP2Q/uh4AQACEJhYYAF4/nhYUAIwAAMAkP9IB5AGeAAY'
    'AB4ALQAAEyEmNTMUFyEVIRITFjMyExcCBiMiAwIDIQEWFwcmJwEhFSERNjcXBAUnNjcRIZAD6BCwCAJY/bAomGhASCiQKHhg'
    'iIjIOPwQBYiIaGhwgPsgA1D+mOC4GP5Y/fAg0Lj+uAUgqLC4oJj98P6I+AF4OP7IyAEYAagCgAHwSGiAeFD9MJj+ACAomGhA'
    'qBggAhgA//8AiP9AB6gGaBImBUQAABAGAyAAAP//AIj/QAe4BngSJgUbAAAQBgVEAAD//wCI/0gHoAZwEiYFRAAAEAYDygAA'
    '//8AiP9AB5gGQBImBUQAABAGA0sAAAADAPj/SAb4BoAAEQAXAB0AAAEzESERIzUhNSERITUhESE1IQEWFwcmJyUXAgcnNgOw'
    'oAKQoPq4BUj6+AUI+sgCqP3goGiYYKAFUKhoiKCYBoD9cPtYcJgBOJgBOJgCQMDYWNjAUDj++LBY0P//AID/QAeYBkgSJgNQ'
    'AAAQBgMBAAD//wBY/0gHqAZoEiYFHQAAEAYE2QAA//8AaP9IB6gGaBImBNkAABAGA4EAAP//AGD/QAeoBngSJgVOAAAQBgOr'
    'AAD//wBg/0AHmAaAEiYFTgAAEAYEEwAA//8AWP9IB7AGgBImBRoAABAGBO0AAP//AGD/QAeYBngSJgVOAAAQBgS9AAD//wBQ'
    '/0gHkAZ4EiYDPgAAEAYFGQAAAAQAcP+AB7AGYAAFABcAHQAjAAABBBcHAiUDMxEUFjMyPgE3FwIOASEgJjUBEhMHAgMlFwID'
    'JxIDMAEg6IDw/vhAqFC44HgwCKgQUKD+yP7woAQooGiwYJj7MKBYcKCIBmCo8JgBCLD+qPvQICAoePgw/uiwQEhgBBD+mP5Q'
    'UAHAAWAoOP3o/pBYAbj//wBQ/0gHmAZ4EiYFMQAAEAYE6QAA//8AUP9IB7AGeBImBTcAABAGBTgAAP//AEj/cAeoBngSJgSk'
    'AAAQBgMAAAD//wBY/0gHoAZ4EiYFOQAAEAYDpAAA//8AUP9wB6gGkBImBAwAABAGBPMAAP//AGj/YAegBpASJgU0AAAQBgUy'
    'AAD//wBo/0gHoAZ4EiYEzQAAEAYFDwAAAAIAUP9IB5gGeAAFADwAAAEWFwcmJwUVIRITNhMXAgMSMzI2NxcCIyIDBgcnNjcC'
    'AyERIQoBIyIvARYzMjYTIRUQAyc2EjURIQMzFBcGEFhAkDhYAaj94BhocFCgYLCASBg4EJBIqJigmLhQwJCQIP0wAiAIYIBQ'
    'YBhgWCgQGP6IwJBoUANgEKgIBnhYcEBoYPCQ/kD+0OgBUED+WP7g/vh4cED+sAEguGigcLgBcAI4/rD9yP7YEKAQWAHgUP44'
    '/phY2AFI8AKAATCgkAAABQB4/0gH0AaAACIAKAAsADAANgAAEyERMxQXIRUhEhM2ExcCBx4BMzITFwIjIiYnBgcnJDcCAyEB'
    'FhcHJicBIREhNyERIQEXBAUnJHgEAKAIAmj9oCBYeGCQgJhAmDAwEJgosEDYWLjoUAEAoJAo+/gGAFhAoDBQ+xACsP1QoAFw'
    '/pACaBj+cP4YIAIYBVABMKCQmP5o/ujYARBI/ojwmLABMCj+SMCo2JCYqNgBcAHoAchgeEiAYP3I/aiYASj9uJiAUKhQAP//'
    'AIj/QAeYBngSJgQ9AAAQBgQ+AAD//wBY/0gHoAaAEiYEhwAAEAYEhgAA//8AaP9IB5AGYBImAygAABAGAv8AAP//AFj/QAc4'
    'BngSJgQVAAAQBgL+AAD//wBY/0AHQAZ4EiYEFQAAEAYC/QAAAAEAaP9QB5gGgAAkAAABFwQFESEVIREhFSERFAYjIi8BFjMy'
    'NjURITUhESE1IREEBScgBsBQ/tD+iAKo/VgDMPzQWIiIeCCAiDAo/KADYP0oAtj+sP6AOAMABoCQSDD+uKD+4KD+WHhgGKgg'
    'KDgBgKABIKABMCAQqAAAAQCg/0gHaAZ4ABoAABMhETMRIRUhERQGIyIvARYzMjY1EQABJwABIaAEkKABmP5oYIiYiCCQmDgo'
    '/jD9yGgCcAHg+5AFEAFo/piY+6BwYBCYECg4A2D96P7YgAFAAlj//wBQ/0gHUAZ4EiYDSgAAEAYFEAAA//8AWP9IB5gGeBIm'
    'BEMAABAGBUIAAP//AFD/SAegBngSJgUPAAAQBgUQAAAAAwBY/1AHsAY4ACsAOABDAAABIRUEBRUzFSMVIRUhFSEVIREUBiMi'
    'LwEWMzI1ESE1ITUhNSE1IzUzNSQ3IQEXBgcSFwcAAzcWFzYlIQoBByc2NzYTIQFIBXD+6P6o2NgBEP7wAWD+oFhQoJgYgKgw'
    '/sgBOP8AAQDY2AEo6PuQBeBwqLiI8Hj+iGCYCBiY+egB+Ajg6GjAWHAQ/qgGOJiYiFCIuIi4iP7AUEgYmBgYASiIuIi4iKBw'
    'cP7wgLhw/hDoiAF4A1goiIBwaP4Q/fC4iJDA4AFw//8AYP9IB6gGeBImBQEAABAGBOMAAP//AFj/QAeYBngSJgVCAAAQBgNl'
    'AAD//wBg/0gHqAaAEiYE4AAAECYEkwAAEAYEkgAA//8AUP9IB1gGeBImBRAAABAGA3gAAP//AFD/OAegBngSJgUQAAAQBgL8'
    'AAD//wBY/0gHkAaAEiYFQgAAEAYD3gAA//8AWP9IB5gGgBImBUIAABAGA1MAAP//AGD/SAeYBoASJgVBAAAQBgM0AAD//wBg'
    '/0gHkAZ4EiYFQQAAEAYDNgAA//8AYP9IB5gGeBImBUEAABAGA4UAAP//AFD/SAeYBoASJgUQAAAQBgQRAAD//wBQ/0gHgAZ4'
    'EiYFEAAAEAYD7wAA//8AQP9AB5gGeBImBR8AABAGAyYAAP//AFD/SAdoBngSJgUQAAAQBgPzAAD//wBA/0gHoAZ4EiYFHwAA'
    'EAYEUgAA//8AYP9IB6gGgBImBUEAABAGBEkAAP//AED/SAeQBngSJgUfAAAQBgPEAAD//wBY/0gHmAaAEiYDxQAAEAYDOgAA'
    '//8AQP9IB6AGeBImBR8AABAGA84AAP//AFj/SAeQBngSJgM5AAAQBgM6AAD//wBg/0gHkAZ4EiYFAQAAEAYDTQAA//8AYP9I'
    'B5AGeBImBUEAABAGA1YAAP//AGD/SAegBoASJgVBAAAQBgR7AAD//wBg/0gHkAZ4EiYFQQAAEAYDKgAA//8AYP9IB4gGeBIm'
    'BQEAABAGA7cAAP//AFj/SAeQBngSJgOGAAAQBgM6AAD//wBg/0gHsAZ4EiYFQQAAEAYDqgAA//8AYP9IB5gGgBImBUEAABAG'
    'A4QAAP//AFj/SAe4BngSJgS/AAAQBgM6AAAAAgCI/0AHiAZ4AB0AIgAAEyERMxEhFSERIRUCBQQFByQlBAUnJCUkAyM1IREh'
    'ARIFJBOQAxigAyj82AJwoP64ASABmED+MP6o/oj+CCgB2AEw/uDAgAJ4/OgByNABCAE4mAVwAQj++Jj+yIj+gOCASLBIyMhA'
    'kDCo0AGImAE4/jD+mJjIATgA//8A0P9AB6gGeBImBT8AABAGBFcAAP//AJD/QAeoBngSJgU+AAAQBgU/AAD//wBY/0AHqAZ4'
    'EiYD/QAAEAYE1wAA//8AaP9AB6AGeBImBUAAABAGA1IAAP//AEj/QAegBngSJgVAAAAQBgP7AAD//wBo/0AHoAZ4EiYD/AAA'
    'EAYFQAAA//8AeP9AB6gGeBImBNcAABAGAvsAAP//AGj/aAeYBoASJgNrAAAQBgL6AAAAAgBQ/zgHiAZwABkAHgAAEyEmJzcW'
    'FyEVIQIABwQFByQBBAUnJCUAAykBEgEAE4ADOEhQiHhYAwj+yED+6GABIAHYYP5A/pj+sP4QcAHgAUj+uIj+2AHYiAEoASho'
    'BSh4cGCQuJj+0P5AONiosJgBIPi4mKjoAUAB6P5Q/vgBAAG4AAMAwP9IB3gGeAALABEAFwAAATMRJRcFESMRBSclAQQXByYl'
    'AwQXByYlBQCgAcgQ/iig+9gYBED9OAEQ0Gjo/wA4ASDwcPj+6AZ4+8g4mDj9oAJQeJh4A7h4qIiwgP6wiLCAwIAA//8AqP9Q'
    'B5gGeBImA3cAABAGBQMAAP//AGj/QAeYBngSJgUDAAAQBgQaAAD//wBY/0gHmAaIEiYFBAAAEAYFAwAAAAEAgP9IB3gGgAAg'
    'AAABFhchFSEUByEQAiMiLwEWMzI2EyECASckEzYRITUhJicD2Gg4AwD7uAgDiIDAaJgYmGhgSBD9CCj+AFgBCIBw/fADODBQ'
    'BoCgsJiwkP0Q/uAQoBC4AiD9mP7wkIgBEPgCMJiYgAD//wBQ/0AHsAZ4EiYEzwAAEAYDMAAAAAEAcP9AB5AGGAAkAAATIRUh'
    'BgchFSERFBYzIDc2NxcOASEiJjURIwIBJwATITUhNjch8AYg/SAIIANo/WA4gAEAKDAIqBCQ/pjYgEiI/YBwAkiA/VgC0CAQ'
    '/WAGGJj4yJj9EBggICjAMPCASFgDIP2Y/oCAAWACCJjI+AADAWD/SAaYBiAABwALAA8AAAERIzUhFSMREyERIREhESEGmKD8'
    'CKCgA/j8CAP4/AgGIPkomJgG2P04AjD68AJIAP//AJj/UAeQBngSJgS5AAAQBgRLAAD//wC4/0gHWAZIEiYDogAAEAYDowAA'
    'AAMAaP94B3AGSAAhACUAKQAAASERIRUhFSEVIRUhFSEVITUhNSE1ITUhBgcnNjcXByE1IRMhNSERITUhAUgFeP2oAsD9QAKA'
    '/YADCPkgAzD9kAJw/fBQaJDQYJgwAcD9iKAEOPvIBDj7yAZI/SDAkLiQwJiYwJC4gGBwwPA4eMABsKD+QKAABABQ/0gHoAZQ'
    'AAMABwALACgAAAEhESETITUhESE1IQEhFSEVIRUhFRYpAQcjICQnBgcnABMXBgcWFxEhAYgE8PsQmAPA/EADwPxA/mgG8Pzg'
    'Arj9SNgBYAEQONj+EP34kIC4gAFYQKAQKJDY/NAGUP0oAbCY/kig/mCQ0JD4KKDAqOCYgAEQAXAgcGi4SAIoAP//AHD/qAeQ'
    'BjASJgU2AAAQBgL5AAD//wCQ/0gHiAaAEiYDxgAAEAYETAAAAAUAaP84B4gGOAAfACMAJwArAC8AABMhFSEVIREhBgcEBQck'
    'JQYFJyQ3Jic3Fhc2NyERITUhASE1KQEVITUBITUpARUhNagGsPzwAoj9cBhYAWgCUDD9mP5o4P4wQAGYwKBwgHiQUBj9iAKA'
    '/QABIAHg/iACgAHo+5gB4P4gAoAB6AY4mKj9ANCAqBioENiwQJgwgGiIUHhYaKADAKj+GLCwsP4gsLCw//8AaP9IB5gGQBIm'
    'BRcAABAGBRYAAAADAHj/QAdwBoAAIgAmACoAABMhNjcXBgchFSEGByERFAYjIi8BFjMyPQEhESMRBgcnABMhASE1IREhNSGY'
    'AmA4MJggKAPA+/BAWAQIcHB4qCjYaEj8gKCImHgBYND98AIYA4D8gAOA/IAFoHBwIGBgmHh4/ABgaBCgEFCo/lgD6JB4cAEg'
    'AVj9uMD9+Lj//wB4/3gHgAaIEiYDRwAAEAYC+AAA//8AaP9AB1AGeBImBSQAABAGBLgAAP//AGj/QAdQBngSJgQbAAAQBgQa'
    'AAAAAQBY/0gHmAZ4AB0AAAEhETMRIRUhESEVIQAFByQBESMRAAEnAAEhNSERIQEgAoigApj9aALo/YABKAHAWP4o/uCg/uD+'
    'OGgB4AEA/YAC8P14BUgBMP7QmP7YmP5IwLD4Acj8wANA/kD/AJABAAGYmAEoAAABAFj/SAeoBngAHQAAEyERMxEhFSERIRUh'
    'AAUHJAERIxEAASckASE1IREhiAMgoAMo/NgC2P2IASAB4Fj+KP7QoP7o/jBoAdABEP2gAtD84AVAATj+yJD+0Jj+cMCw6AGw'
    '/MgDOP5Q/viQ+AGYmAEwAAABAFj/SAegBoAAHgAAEyERMxEhFSEAAQcAAREhFSERIxEhNSERAAEnNgA3IagDAKADAP14ASAB'
    'wFj+KP7YAcj+OKD+QAHA/uj+MGjAAahw/XgFGAFo/piY/cD++KgBOAJY/UiY/ngBiJgCqP3Q/rCQgAHw8AAAAgCQ/0gHcAZA'
    'ABMAKQAAASEOAQcnPgE9ASERFDMhFSEiJjUBITUzFSEVIQAFByQBESMRAAUnJBMhBPD+ABCY0HjIkAM4QAEw/qhgWPvYAvCg'
    'Avj9mAEIAYBQ/lj+4KD+8P5QaAGY8P2wBaj4+IBwcOCwmP5QYJBgWP5g6OiY/qigoMgBoP1YArj+aOCIyAFIAP//ADD/SAeo'
    'BngSJgUiAAAQBgUhAAD//wAw/0gHmAZ4EiYFIgAAEAYFEQAAAAMAWP9AB6gGeAAdACEAJQAAEyE1MxUhFSEVIREhAAUHJAER'
    'IxEABSckASERITUhASERKQERIRGQAyCgAyD84AKI/eABKAHIWP4o/tig/uj+MHAB0AEQ/fACiPzgATgB6P4YAogB6AXAuLiQ'
    'wP2Y/siQsMABaP2IAoD+oNCQwAEoAmjA/XABOP7IATj//wCA/1AHmAaIEiYEKwAAEAYEkQAAAAMAUP9IB6gGeAAdACMAKQAA'
    'EyE1MxUhFSERIRUhAAUHJAERIxEAASckASE1IREhBRcGByc2JRYXByYnyALooALo/RgDSP1IARABuFj+KP7YoP7o/ihwAdAB'
    'CP1AA0j9GAVYkIiIgKD8IIhYmFCIBbjAwJj+AJj+iLCw6AHI/OgDCP5Y/wCQ6AFomAIAMFjQeHCIoKCwWLCgAP//AEj/SAeQ'
    'BngSJgUgAAAQBgOUAAD//wBI/0gHmAZ4EiYFIAAAEAYENwAA//8AMP9IB2AGeBImBSIAABAGBBkAAP//ADD/SAeYBngSJgUi'
    'AAAQBgO+AAAABQBo/0AHkAYwABkAHQAhACUAKQAAASERIRUhFSEABQckAREjEQAFJyQBITUhNSETITUpARUhNQEhNSkBFSE1'
    'ATAFmP2AA0D9SAEQAbBg/jD+6KD+4P5QcAGgARj9WAMw/YigAdj+KAJ4AeD7qAHY/igCeAHgBjD8wJiY/vCIsLgBWP24AkD+'
    'sLiQqAEQmJgB4MjIyP3wwMDA//8AYP9AB6AGgBImBPwAABAGAy4AAP//AGD/QAegBoASJgT7AAAQJgT6AAAQBgT8AAD//wB4'
    '/4gHiAaAEiYDSAAAEAYFAgAA//8ASP9IB5gGeBImBSAAABAGA4MAAP//AEj/QAegBngSJgUgAAAQBgN0AAD//wBI/0AHqAZ4'
    'EiYFIAAAEAYD5QAA//8ASP9IB6gGgBImBSAAABAGA/gAAP//AFD/SAeYBngSJgUVAAAQBgPiAAD//wBI/0gHaAZ4EiYFIAAA'
    'EAYD8wAA//8ASP9AB5gGgBImBSAAABAGA9QAAP//AEj/SAeoBngSJgN1AAAQBgUgAAD//wBQ/0AHoAZ4EiYDggAAEAYE9AAA'
    '//8ASP9IB6gGeBImBNEAABAGBSUAAP//AEj/SAewBngSJgTUAAAQBgUgAAD//wBQ/zgHkAZ4EiYE9AAAEAYDngAA//8AcP9I'
    'B6gGiBImBJwAABAGBJ0AAAABAGj/mAeYBngADwAAATMRIRUhESEVITUhETMRIQQgoAKg/WAC2PjQATigAeAGeP24mPyYmJgE'
    '8PsQAAABAGj/iAeYBhAAEwAAEyEVIREhFSERIRUhNSERMxEhESHIBpD9MAKY/WgDEPjQATCgAbD84AYQmP3omP1YmJgEEPvw'
    'BVgAAgBY/3AHqAZwABAAKAAAATMRIRUhESUXBAUnNxEzETcBMxEkNxcEBREUFjMyPgE3Fw4CIyImNQKIoAEo/tgBIBj+QP3Y'
    'IKCg8AIooAEA2Gj++P7IOGiYUCAIqAhAgPDIeAZw/diY/QBQmJBgqBgFCPsYMAXo/aBokJCgcPzYGCAgeOA4+KBASFgAAwCA'
    '/yAHgAaAAA8AGwAhAAABMxUhFSEVIRUhNSERMxEhETMRJBMXAgAFJyQlARcCByc2A7CgAnD9kAMw+QABSKABSKABKMCg0P1Y'
    '/ahIAbgBOP6oiKi4gNAGgPiY+JiYAej+GP8A/diwAQBA/tj+gHiQUIACSFD+2Kh4yAAABABw/0AHqAZ4ABgAHgAiADQAABMh'
    'JgMzEyEVIRITFjMyNjcXAgYjIicCAyEBFhcHJicFIRUhATMRIRUhETY3FwQFJzcRMxE3cAR4EAiYGAIQ/fgweFBAKCgIkBhw'
    'YJBwoDD7gAYIgFCYUHD7OAMg/OABiKABYP6g0Lgg/hj9oDi4oOAEmNgBCP4gmP4A/sjQsKgg/si48AFAApACUIigSLCAGJD+'
    'YP7okP5oICiYaFCYGALQ/UgoAAEASP9AB6gF8AAxAAATIRUhESQ3FwQFERQWMzI+ATcXDgIjIiY1ESEGByECAScAEyEGBxYX'
    'ByYnBgcnABMheAcQ/aABIPBo/uD+qECIqEggCKAIQIjo6ID9+CAwAfBY/RhgAnh4/oAwOKBwYGiYOEB4ARiA/pgF8Jj90GiQ'
    'kJhw/bgYICho4DD4oEBQUAVIkID8YP6YkAEIAth4aFBwkHBYYFh4AXgB2AD//wBY/ygHqAZ4EiYEOgAAEAYEmgAA//8ASP9A'
    'B6gGeBImA7QAABAGBLYAAP//AIj/QAeoBngSJgN7AAAQBgS2AAAABgCQ/zgHmAaAAAoAJQAqADAANQA7AAABFwYHIRUhBgcn'
    'AAEhNjchAyEVIQMzFSMUBiMiLwEWMzI3ITYTISU2NSEDARYXByYnARMhBgcBFhcHJicCQJggKASo+wB4qIgBMP7QAUAYEASQ'
    'EAEg/tgg4PCIcEBwIIhIQBD70Dgg/tAFQBD8sBgBeJBgmFCYAlAY/KAYIAGokFiYUJAGgDBQUJDQmGgBGP1w6Pj+IJD+uJhw'
    'kBCgEGDgAQCQqKD+uAEwWHBYaGD9UAFIsJgBMFhoWGBgAAACAQj/SAeYBmAADAAiAAABMxEhFSERJDcXBAUnATMRJDcXBAUR'
    'FBYzMjY3FwIGIyAmNQEIqAHw/hABCNAg/wD+sFADOKgBGPBo/uD+sFjweEgQmCCAyP64qAZg/cig/JBYaKh4cFAGyP2ocKCQ'
    'sID88CAgYMBA/viAYGgAAgB4/0gHqAZ4ABoAJAAAATMRFhckExcCBRIFBwABERQGIyIvARYzMjY1ASEVFAABJwATIQO4oEhY'
    'ARDIiND+wPgBaGD+MP7gWIigiCCYmDAo/OgCgP7Y/thYAZCA/hgGeP64sKioAQBo/ui4/lDwuAFQApj8QHBgIKAoIEAEcJhA'
    '/UD+8IgBcAIYAP//AFj/SAeIBmgSJgVWAAAQBgNAAAD//wBo/0AHoAZwEiYE3wAAEAYDegAA//8AWP9IB0gGeBImBVYAABAG'
    'A3kAAP//AFj/SAeQBngSJgVWAAAQBgNjAAD//wBo/0AHoAZ4EiYE3wAAEAYEuwAA//8AWP9IB6gGeBImBVYAABAGBVMAAP//'
    'AFj/QAegBoASJgVWAAAQBgTQAAD//wBY/0AHYAZ4EiYFGAAAECYDnAAAEAYDNQAA//8AWP84B7AGeBImBVYAABAGBAsAAP//'
    'AFj/SAeQBoASJgVWAAAQBgNkAAD//wBY/0gHOAaAEiYFVgAAEAYDmwAA//8AWP9AB5gGeBImBVYAABAGA8kAAP//AGD/SAeY'
    'BngSJgTqAAAQBgTHAAD//wBY/0AHkAZ4EiYDxwAAEAYDNQAA//8AYP9QB5AGeBImBOoAABAGA7YAAP//AFj/QAeQBnASJgR3'
    'AAAQJgR5AAAQJgR4AAAQBgM1AAD//wBY/0AHuAZYEiYD9QAAEAYDNQAA//8AWP9IB2AGaBImBVYAABAGA7MAAP//AFj/QAew'
    'BoASJgMzAAAQBgM1AAD//wBg/0gHmAZ4EiYE6gAAEAYEgAAAAAMAaP9IB6AGeAAQABYAHAAAATMQBxUSAQcAAwIBJyQAEzYB'
    'FwIDJxIBFwIDJxIDqKAI6AJ4aP2w0Jj9SGABgAFoOCD+OKBYmJiYBPCgeMiYyAZ4/cAQSP0o/uCgAVACEP2o/viYmAGgAQio'
    'AZA4/oj++GABCAE4OP6I/vBgAQj//wBI/1AHoAaAEiYFVAAAEAYEXAAA//8ASP9IB5gGgBImBVQAABAGBTUAAP//AHD/UAeQ'
    'BngSJgPXAAAQBgL3AAD//wBQ/0gHWAZ4EiYE6AAAEAYFVQAA//8AYP9AB6gGgBImBS0AABAmA4AAABAGAvYAAP//AEj/SAdo'
    'BngSJgVUAAAQBgOfAAD//wBo/0AHqAYwEiYD3AAAECYD3QAAEAYFLQAA//8AWP9IB7gGeBImBOEAABAGBOIAAP//AFD/SAew'
    'BogSJgSzAAAQBgS0AAD//wBo/0gHkAZ4EiYE3gAAEAYENgAA//8ASP9IB4AGeBImBSsAABAGBSwAAP//AEj/SAeYBoASJgUs'
    'AAAQBgQSAAD//wBQ/0AHsAZ4EiYEIgAAEAYEIAAA//8AWP9IB7AGgBImBLIAABAGBB0AAP//AHD/SAeQBoASJgTJAAAQJgPM'
    'AAAQBgL1AAD//wBo/0gHsAYYEiYEdgAAEAYEqAAA//8AaP9IB5gGGBImBN0AABAGBLwAAP//AGj/UAeYBngSJgRUAAAQBgN+'
    'AAD//wBo/4gHmAYgEiYEVAAAEAYEcQAA//8AUP9QB6gGiBImBTsAABAGA3IAAAABAID/kAeYBngAHgAAARcGByERMxEhFSER'
    'IRUhESEVITUhESE1IREhBgcnAAH4mDBIAcigArj9SAJo/ZgDGPj4A1D9mAJo/ehYcIABAAY4MKiYAbD+UJj+SJj+SJiYAbiY'
    'AbiwiGgBOAAABQBY/0gHGAYYABgAHAAgACYAKgAAAREUBiMiLwEWMzI1ESERIxEhAgMnNhIZARMhESkBESERASERIRUUJREh'
    'EQcYYGBgkCCYWED9+KD96CigmHhgoAIA/gACoAII+1ACCP4AAqACCAYY+iBwcBCgEHABWP3oAhj+sP7YYPABiAEQAuj+IAFI'
    '/rgBSPzYAUioUPj+uAFIAAAFAQD/QAcABngACwAPABMAFwAbAAABESM1IRUjESERMxEBIREpAREhEQEhESEBIREhBwCo+1Co'
    'Aqiw/VACAP4AArACAPtQAgD+AAKwAgD+AAUQ+jCgoAXQAWj+mP2wAbj+SAG4/AABuP5IAbgAAAcAeP9IB5AGMAADAAcACwAP'
    'ABMAFwAjAAATIRUhBSERIRMhESkBESERASERKQERIREBMxEjNSEVIxEzESF4Bxj46AGQA+D8IJgBEP7wAagBCP1QARD+8AGo'
    'AQgBOKio+uCoqAUgBjCYsPwgAjgBIP7gASD9MAEo/tgBKAHY+riAgAVQ+8j//wCA/0gHYAaAEiYDpwAAEAYDqAAAAAcAYP9I'
    'B5gGOAAPABMAFwAbAB8AJwArAAABIREhFgUHJAEhAgUnJDchEyE1KQEVITUBITUpARUhNQEzEAIHJz4BJTMRIwE4BYj+4OgB'
    'EGD+wP7I/nDg/oh4ASDY/uCgAdD+MAJ4AdD7uAHQ/jACeAHQ/FiguOBw2JACiKCgBjj8qJhooJABEP74oJhgsAH4yMjI/djI'
    'yMj9wP7Q/tBYkFDg+P1YAP//AOj/SAcoBngSJgNvAAAQBgL0AAAAAwCo/0gHWAYQABEAFQAZAAATIRUhBgchESM1IRUjESE2'
    'NyEBIREhESERIagGsPzwICgCqKD76KAB+Cgg/RgBSAQY++gEGPvoBhCYkHj62IiIBSiAiPzwAXD8kAFo//8AqP9IB2AGeBIm'
    'BNMAABAGA6YAAP//AGj/cAeYBoASJgSVAAAQBgVFAAD//wBo/3AHmAaAEiYElAAAEAYFRQAAAAQBUP9IBpgGIAAHAAsADwAT'
    'AAABESM1IRUjERMhESERIREhESERIQaYoPv4oKAECPv4BAj7+AQI+/gGIPkosLAG2P4gAUj84AFI/OABQAAABQCQ/4AHeAZ4'
    'ABMAFwAbAB8AIwAAATMHIRUhByERIRUhNSERITchNSEBNSEVESE1IREhNSERITUhA9CoGALw/PAgAjABKPkYARgB0CD9GAMI'
    'Afj8mANo/JgDaPyYA2j8mAZ4sJjA+6iYmARYwJj9gJCQ/viI/miQ/liY//8AMP9IB0gGeBImBSIAABAGA78AAAAHAGj/SAd4'
    'BngAAwAJAA8AHgAiACYAKgAAATMRIwEXAgcnNiUWFwcmJx8BBAUhESM1IRUjEQcnJAEhNSERITUhESE1IQOwoKD+aJjAyIDg'
    'BLDAgKBwwDho/uD+gAMomPwImPBQA1j+gAP4/AgD+PwIA/j8CAZ4/fAB0Fj+8KB4uNC46EjYyNB4uIj76EhIA4BAoLD+cIj+'
    'aIj+aIAAAAcAeP84B4gGeAATABcAGwAfACMAKQAvAAABMwchFSEHIREhFSE1IREhNyE1IQE1IR0BITUhESE1IREhNSETFwYF'
    'JyQlBAUHJCUD2KAQAsD9KBACMAEY+PABMAH4EP0QAwgCEPxoA5j8aAOY/GgDmPxokIjw/rBgASgDCAEoAShY/tj+0AZ4kJB4'
    '/ECQkAPAeJD9+HBw8Hj+oHD+qHD+6HCAUIhAcDhomIA4AAAEAGj/SAdwBogAMAA0ADgAPAAAARYXITY3FwYHIRUhByEVIQYH'
    'IRUhBgchESM1IRUjEQYHJyQ3ITUhNyE1ITchNSEmJxMhNSERITUhESE1IQLYWDgBYEgosBhQAcD80CAC4PzoGCAD8PvAMBgD'
    '0Jj8mJiQuHABSLj+KAJAQP4YAiAo/VgB2Cg4eANo/JgDaPyYA2j8mAaIYHhgeDgwcJBwiEA4kEAY/IA4OALAcFhwqMiQeIhw'
    'kEhI+5Bo/rBo/rhoAAEAeP9IB5gGeAAeAAABFwchFSEUByEVIRIFByQBAgEnABMhNSE2EyEGBycAAmCgYARQ/XggAwD9KNAC'
    'WGD9yP8AcP1IYAKgYP1AAuggCP6AcJCIASAGeDDomPjAmP4oqLDAAfD+cP7omAEIAYiYuAEAyJBoASgA//8AWP9YB6AGeBIm'
    'BLEAABAGA9oAAP//AFD/SAdoBngSJgPYAAAQBgR1AAAABABo/0gHmAYIAAMAFAAaACAAAAEhFSEDIRUhERQGIyIvARYzMjUR'
    'IQUAEwcCASUXAgcnAAEoBbD6UJAG0PzwYKBoWCBwcGD84AUQASDQiND+6P0IkODwiAEYBgiY/piY/KBwWAigEEgDSMj+4P7A'
    'gAFYASBgWP5Y+HgBKAAABACQ/zgHaAaQAAkAHAAkAEsAABMhJic3FhchFSEFFwYHFhcHJicEByc2NyU3Fhc2BTMRIREzESEF'
    'ERQGIyIvARYzMjY1ESEGBzYlJic3FhcHJwQFJzY3IREjESE3FweQAxAoQKhYMAMA+SgEuIBYiJCAaKCw/ui4YLC4/tBY0Mio'
    '/ECYBJCQ+kgGKJCIYIAoqFhAQP0gYGDwAQA4QJioWJgw/pD+aDCIcP5IoAKoMKAYBdhIQDBYYJAYSEBIOEBwWEBwMHgwSGBw'
    'QEhICP54AYj96ID9sGBgEJgQKCgBmKhgEChIODCYwDBgSBiIcLD9eAMYcDBAAP//ADj/QAegBoASJgVXAAAQBgN/AAD//wA4'
    '/0AHcAaAEiYDbAAAEAYFVwAA//8AOP9AB2gGgBImBVcAABAGBAkAAP//AFj/SAeQBmgSJgTbAAAQBgMyAAD//wCY/4gHeAaI'
    'EiYFCwAAEAYC8wAA//8AYP9IB1gGiBImBPkAABAGBPgAAP//AGj/SAeYBogSJgRNAAAQBgROAAAAAwBo/5AHmAaAAAkAEwAZ'
    'AAATISYnNxYXIRUhBRcCAyEVITUhEgESEwcCA8AC+DBAsEgoAuD5eAUAuHjIAmD40AQY2PzgwGCwYLgFEKiQOKjImDgo/dD+'
    'QJiYAgAB+P54/ihAAeABiP//AID/gAeQBngSJgNJAAAQBgLyAAD//wBo/0AHmAZ4EiYEawAAEAYEbAAA//8AYP9IB5AGiBIm'
    'BUsAABAGAvEAAP//AGj/UAeQBogSJgVKAAAQBgNEAAD//wBo/0gHmAaIEiYFSgAAEAYC8AAA//8AcP9IB5AGiBImBKEAABAG'
    'A80AAP//AGj/UAeYBogSJgVLAAAQBgLvAAD//wBY/0AHmAZ4EiYEHAAAEAYEBAAA//8AWP9AB6gGeBImBLAAABAGBNwAAP//'
    'AFj/SAeYBngSJgSvAAAQBgOOAAD//wBY/0AHcAZ4EiYEAgAAECYEtwAAEAYDsAAAAAMAaP9IB0gGaAAwADYAPAAAARcABSQl'
    'Jic3FhMHJicFERQGIyIvARYzMjURBAUnJCUGBSckEwUnJCUXBAUCByQ3NgEXBgUnJAEWFwcmJwVIkP5I/iAB+AGYUFiQ+JiY'
    'OFD+QFBwcGAgaHAo/tD+uCgBKAEQ+P8AIAEQuP4wWAP4AaB4/rj+MLDwARjQmP2waPD+4FABAAQw+JiYkPgFODj+UPAoOFhY'
    'WOj+8FhwaED+GIBgGKAYYAG4IBiAkMAoGJCoAQAQkCA4iCgg/wCoGCh4/OiA+JiYeAEA0OhY4ND//wBo/zgHmAZ4EiYE6wAA'
    'EAYD2wAA//8AcP84B1gGSBImA0YAABAGA9sAAP//AGj/iAeYBngSJgSIAAAQBgQoAAD//wBo/0gHYAZ4EiYEiAAAEAYE0wAA'
    '//8AaP9wB7gGeBImBEUAABAGBIgAAP//AGj/QAeoBngSJgSIAAAQBgSaAAD//wBo/1gHQAZ4EiYESAAAEAYEiAAA//8AaP9I'
    'B6gGeBImBIgAABAGBNoAAP//AGj/SAeYBngSJgSIAAAQBgMjAAD//wBo/0AHqAZ4EiYEmQAAEAYEZQAA//8AaP9AB5gGeBIm'
    'BIgAABAGA+wAAP//AGj/aAewBoASJgSIAAAQBgPoAAD//wBo/0gHmAZ4EiYEiAAAEAYDjQAA//8AaP+QB5gGeBImA9MAABAG'
    'BIgAAP//AGj/QAd4BngSJgRlAAAQBgNDAAD//wBo/0AHsAZ4EiYEZQAAEAYDoAAA//8AaP9AB6gGeBImBIgAABAGBUwAAP//'
    'AGj/SAd4BoASJgRlAAAQBgNCAAD//wBY/0gHoAaAEiYD6gAAEAYD6wAAAAMAyP9IB0AGKAAQACMANwAAAREUBiMiLwEWMzI1'
    'ESERIxEFFwIHFhcHJwIHJzYTJic3Fhc2JRcCAxYXByYnBgcnNhMmJzcWFzYHQHhwUGgokEhQ+sigAligGEhoUJhgeMBg0GBw'
    'kIhgUCACeKAgaHBgeFBYgMhg0HiAmIBwaDgGKPnwYGgQoBBQBVD5uAbg+Bj+6PiouEjg/uDIgPgBKMioQHB4qMgY/sD+6MDQ'
    'gLig+LCA2AEA2NBYoKDAAP//AKD/SAboBkASJgSMAAAQBgLuAAD//wB4/3gHkAZQEiYEiwAAEAYC7QAA//8AiP84B3gGYBIm'
    'Az0AABAGBAMAAAABAFD/YAeQBngAOAAAASE1MxUhFSEVMyQBFwYHIRUhBgUVJCUXBAUVFBYhID4BNxcOAiEgJjURBgcnNjc1'
    'FzY3ITUhNSEBAAH4qAIA/gDwATgBAHDA2AHw/Ujo/rgB+AG4YP4g/dCIAWABIJhAGLAYYLj+cP44yLC4SODQaKiY/MgCiP4I'
    'BYD4+Jj44AEYeNiomKCouICoiLiAgCAgGGDAMOCYMFhQAbBYSJhYYFAYWGCY+AABAHD/SAeQBigAIgAAEyEVIQYHIREUBiMi'
    'LwEWMzI1ESERIxEhESMRIREjESE2NyFwByD8sDA4A0BoaDhIIGgwOP7AmP7AoP7IoAI4QCj86AYomKCQ+7hgaBCYCFADiPvw'
    'BBD78AQQ+4AFGJCg//8AUP9IB7AGcBImA/QAABAGBToAAP//AJD/SAd4BngSJgNBAAAQBgLsAAD//wCI/0gHqAaAEiYE5wAA'
    'ECYE5gAAECYE5QAAEAYE5AAAAAQBIP9IBtgGgAANABEAFQAZAAABFwYHIREjNSEVIxEhNgEhESERIREhESERIQNguBhAAxig'
    '+4igAehA/ngEePuIBHj7iAR4+4gGgChYcPm4oKAGSHD94AEY/TgBGP04ARj//wBg/0AHqAZ4EiYE1wAAEAYD7gAA//8AYP9I'
    'B7AGiBImBKMAABAGBT0AAP//AGD/SAeoBogSJgQHAAAQBgU9AAD//wBg/0gHgAaIEiYFPQAAEAYD1QAAAAQAaP9wB5gGgAAe'
    'ACQAKAAsAAABFwchFQYHIREhERQWISA3NjcXBgcGISAmNREGBycAByE2NyEGAyERIQEhESECoKBQAqhIUAHg+wiQAagCUFAg'
    'IJgoWED9SP3owEhIUAGQOAKIYDD9sHgoAeD+IAJ4Aej+GAaAMICAiGj9WP6gMCAoEOhY8EAwSHAD0DgwkAEg4HBwkP2YAYj+'
    'eAGIAP//AID/UAeoBngSJgUuAAAQJgR0AAAQBgQ0AAD//wBo/zgHsAZ4EiYFHgAAECYD+gAAEAYC6wAA//8AcP9AB7AGeBIm'
    'BS8AABAGAuoAAP//AGj/OAeQBngSJgUwAAAQJgP6AAAQBgOtAAD//wB4/0AHgAaIEiYD5wAAEAYC6QAA//8AYP9AB5gGeBIm'
    'BU4AABAGBMEAAAABAFD/WAe4BngANAAAAQYHJyQ3ITUhNSE1ITUhNSE1MxUhFSEVIRUhFSEVIRYXNjcXBgcWBQcAAyMGBxE2'
    'NxcGBScCKNCgaAGg8P2QA0D9UAKw/QgC+KAC+P0IArD9UANA/RhAWOC4cNDQuAFYWP1YqGhocPC4IOj+yFABcIhAkKDwmKiY'
    'oJigoJigmKiYsHBYmICQWLiAmAEIAmB4YP4gOEiYWEhQAP//AGD/WAe4BoASJgTIAAAQBgLoAAD//wBI/0AHmAZ4EiYErgAA'
    'EAYEMQAA//8AUP9IB5gGeBImA+QAABAGA/4AAP//AGj/UAeoBngSJgRHAAAQBgLnAAD//wBA/0AHoAZ4EiYD8gAAEAYDOAAA'
    '//8AWP9AB5AGQBImA/EAABAGAuYAAAADAJj/SAeQBiAABwASACMAAAERIxEhESMRATMQBxAABSckABIXMxEUFjMgNjcXBgcG'
    'ISImNQZgoPxooAHwoAj+iP5oaAE4AThwuKBIgAEAUBCYIFA4/rD4cAYg+0AEKPvgBLj+8P4wEP6Y/hCQiGgBIAFYMP24KCBQ'
    'oCjoQDBIYAD//wBo/0AHoAYwEiYEzQAAEAYD0QAA//8AaP9AB6AGeBImA9EAABAGA24AAP//AEj/MAeoBogSJgN2AAAQBgNF'
    'AAD//wBo/0gHkAaIEiYDNwAAEAYC5QAAAAYAQP9AByAGoAAjACkALQAxADcAOwAAARcGByEVBgchERQGIyIvARYzMj0BIREj'
    'ESECByc2GQEGByckFSE2NyEGAyE1KQEVITUBITUhFRQlFSE1AqCwKDACuFBYAhhQUHjIKOhYKP34oP4IMOBw+FBYcAGQAlho'
    'OP3AQEgB2P4oAngCCPt4AeD+KAJ4AggGoChIQIBoUPtocGgYuBg46P4wAdD+8NCQ4AIIAag4MIDgoFhYUP4Y8PDw/ZDwSECI'
    '8PD//wBg/0AHmAaAEiYEFgAAEAYC5AAA//8AYP84B4gGgBImBBYAABAGA64AAP//AFj/QAegBoASJgOxAAAQBgM8AAD//wBo'
    '/zgHmAZ4EiYEiQAAEAYFCQAA//8AaP84B6gGeBImBIkAABAGBGMAAP//AGj/cAe4BngSJgSJAAAQBgRFAAD//wBo/0gHgAZ4'
    'EiYEiQAAEAYDVQAA//8AaP+QB6AGeBImBFYAABAGBP8AAP//AGj/SAdQBngSJgSJAAAQBgN9AAD//wBo/0gHqAZ4EiYEigAA'
    'EAYFBQAA//8AaP9QB2gGiBImBFYAABAGA/cAAP//AGj/SAeYBoASJgSJAAAQBgUmAAD//wBo/0AHqAaIEiYEigAAEAYDOwAA'
    '//8AaP9IB5gGeBImBIoAABAGBMcAAP//AGj/QAewBngSJgRWAAAQBgOgAAD//wBo/0gHWAZ4EiYEiQAAEAYE7gAAAAMAkP84'
    'B2AGeAAXACIAKAAAAREjESERIxEhNjchBgUnJBMXBgchFQYHATMQBxAFJyQANTYBBAUHJCUGqKD8OKACiGhI/eCw/vhwAYi4'
    'qCAwAnhYWP7IoAj8uGgBwAFQCAE4ATgBOID+8P6YBFD8cAL4/QgDkICIuIh4yAEgKDg4gKBw/uD+yBD+ELiAYAEg4Aj+sHig'
    'iKigAP//AGD/QAeoBngSJgTXAAAQBgQ1AAD//wBg/0gHmAZ4EiYEHwAAEAYENQAA//8AYP8wB5AGeBImA/AAABAGBB4AAP//'
    'AEj/SAeQBngSJgPDAAAQBgOLAAAAAQBo/0AHoAZ4ACgAAAEhNTMVIRUhFSEVIREhFSERFikBByMgJCcGBycAExcGBxYXESE1'
    'ITUhARgCkKACoP1gAwj8+AKw/VDgAWABGDjg/gD98KBgmHgBKDigGDig8P0IAvj9cAWI8PCg8Jj+6Jj+iCiouKjYsHgBWAHY'
    'IMCouEgDAJjwAP//AEj/OAegBngSJgSrAAAQBgStAAD//wBI/zgHoAZ4EiYErAAAEAYC4wAA//8ASP84B6gGgBImBKwAABAG'
    'AuIAAAACAHD/QAegBjAAHAAgAAABIREhESEVIREWKQEHIyAkJwYHJwATFwYHFgURITchESEBgAUg/dgCqP1Y2AE4ARg44P4I'
    '/fiYaJiAAUAwoBg4oAEI/aigA+D8IAYw/UD+2Jj+gCCwwLDgsHgBcAHQIMCg0FADGJgBkP//AFD/aAegBoASJgTKAAAQBgSW'
    'AAD//wBQ/2gHoAYwEiYEzAAAEAYEOQAA//8AUP9IB6gGgBImBMwAABAGBMsAAP//AFD/SAeoBogSJgTKAAAQBgPPAAAABABg'
    '/0gHoAaIACIAJgAqAC4AAAEXBgchETY3FwYHERQGIyIvARYzMjY1EQAFJyQBITUzESE2AyE1IREhNSERITUhAyCwKDAC+GhY'
    'cJCgkIiQyCj4gEBA/gj80EgCoAH4+6jAAWA4+APQ/DAD0PwwA9D8MAaIMEg4/MhISHh4aP4wYGAomCgoKAFI/tj4mMABCJAD'
    'kFj+eKD+MKj+KKgAAAEAaP8wB6AGgAAhAAABFwchFSECByERMxEhFSERIRUhESMRITUhESEnNhMhNSE2A1CgYAOw/AiIsAHg'
    'oAJQ/bADEPzwoPx4A4j9aCjImP4wAiBABoAg2Jj+8MgBUP6wmP8AmP5IAbiYAQCYyAEQmHgA//8AaP9IB6AGgBImBI4AABAG'
    'A2EAAP//AGj/SAegBngSJgSOAAAQBgQ/AAD//wBo/0gHWAZ4EiYEjgAAEAYDbQAA//8AcP84B6gGeBImBEcAABAGAuEAAP//'
    'AGj/SAeQBngSJgPmAAAQBgSOAAD//wBo/yAHsAZ4EiYEjwAAEAYEjgAA//8AaP9IB7AGgBImBKUAABAGBKYAAP//AFj/SAeA'
    'BoASJgRgAAAQJgRfAAAQBgReAAAAAgBg/1gHoAZIAAUAFwAAExYXByYnAyERFgQpAQchICQnByc2NxEj8KCAcIiYGAGQYAEo'
    'AfACMFD9gP6g/sB46HCAePAGSGiQiKBo/eD9AEhAsGBo6KhIUAKAAP//AGD/WAegBngSJgQnAAAQBgKGAAD//wBg/1gHoAaA'
    'EiYEJgAAEAYChgAA//8AYP9YB6AGcBImAoYAABAGAuAAAP//AGD/WAegBkgSJgKGAAAQBgLfAAD//wBg/1gHoAZoEiYEOAAA'
    'EAYChgAA//8AYP9YB6AGeBImA9IAABAGAoYAAP//AGD/WAegBkgSJgKGAAAQBgLeAAD//wBg/1gHoAaAEiYChgAAEAYC3QAA'
    '//8AYP9YB6AGcBImAoYAABAGAtwAAP//AGD/WAegBkgSJgPBAAAQBgKGAAAABQBg/1gHoAaAAA0AEQAVABsALQAAARcGByER'
    'IRUhESERITYDFSE1ASE1IQEWFwcmJwMhERYEKQEHISAkJwcnNjcRIwSAqBggAdD84ANI/BgBSCDIAoD9gAKw/VD9UKCAaJCY'
    'GAGQYAEoAfACMFD9gP6g/sB46HCAePAGgChoWP4AsP34BLh4/vjY2Pxw4APoaIiImHD94P0ASECoWGjoqEhQAoAA//8AYP9Y'
    'B6AGSBImA+0AABAGAoYAAP//AGD/WAegBmASJgP5AAAQBgKGAAD//wBg/1gHoAZgEiYChgAAEAYC2wAA//8AYP9YB6AGSBIm'
    'AoYAABAGAtoAAP//AGD/WAegBoASJgPCAAAQBgKGAAD//wBg/1gHoAZ4EiYChgAAEAYC2QAA//8AYP9YB6AGSBImAoYAABAG'
    'AtgAAP//AGD/WAegBngSJgKGAAAQBgO9AAD//wBg/1gHoAaAEiYChgAAEAYC1wAA//8AYP9YB6AGeBImA3wAABAGAoYAAP//'
    'AGj/SAeIBngSJgPfAAAQBgP/AAD//wB4/0gHiAaAEiYD/wAAEAYDmAAA//8AKP9IB4gGeBImA/8AABAGA5cAAP//AGj/SAe4'
    'BkASJgR6AAAQBgRGAAD//wBA/0gHkAZwEiYD2QAAEAYDXgAAAAUAiP+YB4AGOAATABcAGwAfACMAAAEhESEVIRUhFSEVITUh'
    'NSE1ITUhEyERKQERIREBITUpARUhNQEwBbD9eAKo/VgDKPkIAzD9SAK4/XigAej+GAKIAej7kAHo/hgCiAHoBjj8QNCY4JiY'
    '4JjQAiABCP74AQj9cPj4+AAFAHD/gAeIBlgAJQApAC0AMQA1AAABFwQFFSEVIRUhESEVIRUhFSEVITUhNSE1ITUhESE1ITUh'
    'NQUnIAEhNSkBFSE1ASE1KQEVITUGuFD+wP6AA0D8wAKQ/XAC8P0QAzj48AM4/RgC6P1oApj82AMo/WAwAvD94AIA/gACoAIA'
    '+2ACAP4AAqACAAZYiBgIgJBw/VhwkHCYmHCQcAKocJB4EJD8+ICAgP54gICAAP//AFj/SAd4BjASJgNfAAAQBgREAAAACQBg'
    '/3AHmAZQAAMABwALAA8AIwAnACsALwAzAAABIREhEyE1IREhNSEBIRUhFyERIRUhFSEVIRUhNSE1ITUhNSETITUpARUhNQEh'
    'NSkBFSE1AVgFQPrAoAQA/AAEAPwA/pAG6PkYyAVY/agCoP1gA0j4yANI/WgCmP2ooAG4/kgCYAG4++gBuP5IAmABuAZQ/egB'
    'SFj+4Fj+2HhQ/fBQeFCIiFB4UAE4WFhY/vBQUFAA//8AUP9wB5gGeBImBIMAABAGAx4AAP//AFD/UAeYBpASJgSEAAAQBgMh'
    'AAD//wBQ/zgHoAZ4EiYEVQAAEAYEgwAA//8AUP9IB6gGgBImBIUAABAGA8sAAP//AFD/SAeYBngSJgRzAAAQBgMvAAAAAgBw'
    '/1AHYAZwABYAHAAAEyERMxEhFSESBQcAAyERNjcXBgcnESEBFwAFJyRwAaCgBLD9GMgCIGD9mND+6LCAILD4SP5gBXiA/uj+'
    'aFgBaAOYAtj9KJj+CNCoAQACcP0gYGiYiHhQA2ADaGj+qMiQsAAAAwDQ/0AHMAaQAAUAFAAYAAABFhcHJicFIREUBiMiLwEW'
    'MzI1ESEFMxEjAgBwSJBAcAHgA9hgWEBYKGBAOPzI/XigoAaQgJhYmIAI+fBwcAioEHAFUJD6OAD//wDQ/0AHMAaQEiYCqwAA'
    'EAYC1gAA//8AqP9AB5AGeBImBKkAABAGAykAAP//AKj/QAeoBjgSJgSpAAAQBgTcAAD//wCg/0gHmAaAEiYFBwAAECYEBQAA'
    'EAYEnwAA//8AqP9AB5gGgBImBKkAABAGAtUAAP//AKD/SAeYBoASJgUHAAAQBgPpAAD//wCo/0AHqAZIEiYEzgAAEAYEqQAA'
    '//8AiP9AB6gGgBImBFMAABAGBHIAAP//AIj/QAeQBnASJgRTAAAQJgSQAAAQBgLUAAD//wCg/0gHgAYwEiYFBwAAEAYDrwAA'
    '//8AiP9AB3gGWBImA1QAABAGBVIAAP//AID/OAeYBmASJgVQAAAQBgLTAAD//wCI/0AHeAZYEiYFUQAAEAYFCgAA//8AaP9I'
    'B5AGgBImAzEAABAGAtIAAAAGAGj/UAeQBigADwATABcAGwAfACMAABMhFSEHIREjNSEVIxEhNyEBIREhASERIQUhNSERITUh'
    'ESE1IWgHKPyIWANQoPsQoAJAWPzwARgBKP7YA8gBKP7Y/fgBcP6QAXD+kAFw/pAGKJjw+rBoaAVQ8Pq4A8D8QAPA2Nj9uNj9'
    'sOj//wBo/0AHaAZ4EiYEZAAAEAYEUQAAAAUAaP9IB5gGiAAJABkAIQAlACkAAAEWFyEVITUhJicDFhchNjcXBgchFSE1ISYn'
    'AREjNSEVIxETITUhESE1IQQAOCAC0PmwAsggKMBYKAG4YCi4KGACEPjQAgAwQASIoPwooKAD2PwoA9j8KAaISFiYmDg4/th4'
    'mKhoOFiAmJh4aP34/FBgYAOw/qDI/eDI//8AaP9IB5gGOBImBHAAABAGBGkAAP//AFD/QAeYBkgSJgRYAAAQBgNzAAD//wBo'
    '/0gHmAZoEiYEggAAEAYFPAAA//8AcP9IB7AGOBImBG4AABAGBG8AAP//AGD/SAeYBjgSJgSCAAAQBgRqAAD//wBo/0gHmAaA'
    'EiYEggAAEAYE1QAA//8AYP9AB5gGeBImBG0AABAGBIEAAAABAJD/YAeoBfgAGQAAEyEQFzY3FwYHFhcHJicSMzITFwIjIgMC'
    'AyGQBOgIwKhw0Ojg2ICQsECgWECYWNi4YIAY+8gF+P8A2JDAmMiQkLiIkIj9SAEgKP5YAQgBaAOQAP//AEj/QAdwBogSJgSX'
    'AAAQBgNxAAD//wCA/1AHkAZgEiYEMAAAEAYDcAAA//8AgP84B2gGgBImBC8AABAGBNYAAP//AGD/MAegBnASJgPgAAAQBgOy'
    'AAAABgBw/0AHkAaIAAgADAAQACEAJQApAAABFhchFSE1IScBIREhNyE1IQERFAYjIi8BFjMyNREhESMRASERITchNSEEEDgg'
    'Ayj44AM4QP4gBOD7IKADoPxgBSB4gFh4IJhQYPqooAGIA4D8gJgCUP2wBohIUIiIaP6Y/mCIkP54/RhgWBCQEEgCQPzoA6D/'
    'AP5QiKgAAAkAYP9AB5AGQAATABcAHQAhACcALQAzADkAPwAAASERIRUhFSEVIRUhNSE1ITUhNSE3IREhBRYXByYnJREhEQcX'
    'BgcnNgEXBgcnNiUWFwcmJyUWFwcmJyUWFwcmJwEwBZj9gAKQ/XADKPkgAyD9cAKQ/YCgAeD+IAEASCiQKFACEAHg+JBAUIhY'
    '/FCQeICImAWoeHiAaJD9AFA4qDBIAnBgQKBAWAZA/SigkKiQkKiQoIgByEh4kDCYcHj+OAHIQDigcEiA+/BY0IB4kKCAoIio'
    'oFCQsEi4iEiQqEiwiAD//wBg/0AHoAaAEiYE0gAAEAYEpwAAAAIDgP/gBIAFuAADAA8AAAEjAzMTFAYjIiY1NDYzMhYEQHg4'
    '4BBAQEBAQEBAQAGgBBj6uEhISEhIQEAAAAEDEP7ABeAFuAALAAABMwAREAEjJgAREAAFIMD98AIQwOj+2AEoBbj+wP24/cj+'
    'yGgB6AEgASgB6AABAiD+wATwBbgACwAAASMAERABMxYAERAAAuDAAhD98MDoASj+2P7AATgCOAJIAUB4/hj+2P7g/hgAAQFQ'
    '/wgCmAEwAAYAACUDIxMjESECmNB4iHgBOCj+4AEgAQgAAgGoAAACyAQgAAMABwAAASERIREhESECyP7gASD+4AEgAtgBSPvg'
    'AUgAAgGI/vgCqAQgAAMACgAAASERIREDIxMjESECqP7gASCAaFiQASAC2AFI++D++AEIAUgAAAMAaALQB5AGgAAVABkAHQAA'
    'ARcHITUzFSEVIRUhFSE1ITUhBgcnNgMhESE3ITUhAeCIMAFwoALI/TgDSPjYA0D+EDBAcLhYBYj6eJgEWPuoBoAoUHh4iHiI'
    'iHgwIFhw/jj+oHhwAAIAgP84B5gDwAAdADcAAAEXBgchFQYHBAUHJCUEBScgJSYnNxYXNjchBgcnJAMhNjczBgchAgYjIi8B'
    'FjMyNjchBgUnJDchAqhwICgDeIjAAQgBkCj90P6w/rj+EDgBEAF4iFh4oMjggPzoiKBgATjAAigYCKAIEAKYMHiIaHgYgHAw'
    'OBj92Jj+KFABQLD+SAPAUDAocHhQKAiQEFBYGHhAMDhISChAWHhQaLD98DAwMDD++JAQiAgwWOBIkChwAAMD6ABYB3AGcAAh'
    'ACUAKQAAATM2NxcGByEVIQYHIREUBiMiLwEWMzI9ASERIxEHJzY3IwEhNSERITUhBDDwOCiYICgBoP4YQDACQGBYOFAgaDgw'
    '/oCQaGiIYKABGAGA/oABgP6ABZhwaCBgWJBwQPywWFgQiBBIgP64A4hocIiQ/jCY/mCIAAABAzj/SAeYBoAAHQAAASERMxEh'
    'FSERIRUhESERMxEjNSERMxEzESE1IREhA4ABkJgBsP5QAfD+EAEAmJj82Jj4/igB2P5wBTABUP6wmP7gmP1IAgD9IFgCgP4I'
    'AriYASAAAAMCkACwBWgEaAADAAcACwAAAREhEQERIREVESERBWj9KAJA/lgBqARo/EgDuP5wAQD/AJj++AEIAAAGAigAeAeA'
    'BoAAHwAjACkALwA1ADsAAAEWFyEVIREzNTMVITUzFTMVIxEhESMVEAMnEhkBISYnATUhFQUWFwcmJyUXBgcnNiUWFwcmJyUW'
    'FwcmJwVAMBgB2PwAyJgBOJDg4P2gyKiQoAIYGCABUP7IAghwSIBIYP1wiEBYiGgBaCgQkAggAYAwGJAQKAaASGCQ/wDIyMjI'
    'iP6QAXBQ/nD+0FgBOAFwAihAOPyI6OiwoMg40JgoMNiYUKiIoLAouKAgmKgosJgAAAQCgABQBzgGSAAZAB0AIQAlAAABESEG'
    'ByEVAgUnJBMhBxYXByYnBgcnNjchEQUjETsCESMBMxEjBzj9mCgwAlDY/SBAApi4/fAYeGhwaHhAWHDwmP6gArDIyJDAwP1g'
    'uLgGSP3ASEiI/gCgmHgBkCBYYIB4WEBAeLjwAkCQ/uABIP7gASAAAwJgANAHiAZ4ABUAGQAdAAABFwczNTMVIRUhFSEVITUh'
    'NSEGByc2AyERITchESEDoIhA2JgBwP5AAjD62AJg/uBIWHjAOAPw/BCYAsD9QAZgKJjY2JD4kJD4eFhY0P2I/eCQAQgABQLQ'
    'AIgHSAZIACMAJwArAC8AMwAAASEVBgcXIREUBiMiLwEWMzI9ASERIxEhESMRISYnNxYXNjchEyE1IQUhNSEBITUhBSE1IQLQ'
    'BGDI6CABqGhgUHAgkEgw/qig/riYAfhoiIBgUKB4/LCYAUj+uAHoAVj+qP4YAUj+uAHoAVj+qAZIcJhoIPx4UFgQiBBAoP7A'
    'AUD+qAQgSEBgODhAUP3YkJCQ/kioqKgAAAICSABYB6AGYAAbADUAAAEXBgUVIRUhFgUHJCcRIzUGBSckNyE1ITUFJyADIzUh'
    'ByECBiMiLwEWMzI2NyE3IQ4BByc+AQbAUNj/AAIo/lDYARhQ/sDYmMj+0GABIND+SAIg/lgwAgDo6ANwSAE4EFhwUHggkFgg'
    'GAj+oFD+wBCw0GjAmAZgiBgIkIiQQJhwyP8A8LhwgFiQiIgQkPxwiNj+qKAQmCBAqNjQ+GBwWMAAAgJ4AFgHgAZwAB0AIQAA'
    'ASERMxEhETMRIRUhESEVIREjESECBSc2EyE1IREhASERIQKwARigASCgAUD+wAFY/qig/tg4/vCI+DD+wAFQ/ugBuAEg/uAF'
    'KAFI/rgBSP64mP6omP3YAij+mOBoyAEYmAFY/qgBWAAAAgKYALAHUAaAAAUAHQAAARYXByYnASEVIQIHFhcHJicGBSckNyYn'
    'NxYXNhMhBMhoMKA4YP6IBKD/ABiAuKCAmKjo/phoAXjA0PB46MBoGP0ABoBwkDiQeP7gmP6gwKCogKig8FCYWMC4qFiYoIgB'
    'KAAAAgJYAKAHgAYgAA8AFQAAASEVIQYHESMRBwYHJwABIQEWFwcmJwK4BKD+OCg4oLiAiHgBeAEQ/dgDUNigeKDgBiCYWGD7'
    '0ANA2JBwgAEYAej+oMjYePDIAAICkACoB2gGQAADABkAAAEhFSEDIRUhAgckJSYnNxYTByYnBAUnNhMhAygDoPxgmATY/XCQ'
    'iAEwAUBQaJDYiJggKP5o/jAwsID+cAZAmP6omP5wqBA4gHhY+P7gWEhIUBigyAGAAAIC2ABoB4AGcAAVABsAAAEzESEVIREU'
    'BiMiLwEWMzI2NREhNSEBFhMHAicFeKABaP6YWJBwYCBocDgo/WACoP4ogECoQHgGcP7ImPyYcGAooDAoOANAmP7I2P74OAEQ'
    '2AAAAQCA/zgEaAPgACEAAAEzFSEVIRUlFwYHESMRBSclNSEnNjcjNSE3FwchFSEGBzMCgJgBKP7YATgYoLCY/iAgAgD+eCBo'
    'UMgBGECIMAHQ/ehIWPACkLCAiDCAIBj+6AEAQJA4oIBoeIiYGICIgGAAAAID8ABoB6gGgAAoAC4AAAEVIRIXNjcXAgcWMzI2'
    'NxcOASMiJwYHJzY3AgMjETY3FwYHJxEhAzMbARYXByYnB1D+qBAoUECQYIhIOBgYCIgQYFCIYHCgULhoSBjYODhAaIBgAWgI'
    'kBC4SCiAKEAFOJD+8NCo4DD+qNjocHAY2JD4iHB4iKgBGAGA/SBASHiIeGgD+AFI/rgBMGBwOHhYAAADA9gAqAdABigAEwAX'
    'ABsAAAEhEAYjIi8BFjMyNhMhAgUnJBMjEyERITchESED+ANIWHhYcCCAWCAgCP7YEP7QaAEAEPAgAwj8+JgB2P4oBij98MgY'
    'mBhgAVj+KJiAcAGA/Wj9oJABQAAAAgQQ/0gHmAYgABMALgAAASEQBiMiLwEWMzI2NyECBSc2EyMTFwYHMzUzFSEVIRUhFSER'
    'IxEhNSE1IwYHJzYEMANAWIBQeCCAWCgYCP7YMP8AYNAw6LCAGCCYmAEY/ugBQP7AmP54AYjQMDh4kAYg/lCoGJAYUPD+mJCA'
    'cAEI/hAoWFjQ0JDgkP54AYiQ4GhIWNAAAAMAaP9IB5AD0AAHAA8AHwAAAREjESERIxEBFwIABSckADsBERQWMyA2NxcOASEi'
    'JjUGGJj86JgB4KA4/lD+SEgBqAF4oJhIeAEQWBiQGJD+mOhwA9D9MAJA/cgCyP74MP6Y/mhQmEgBWP7QIChIkCjYcEhoAAAF'
    'AKADEAdgBkAACwAPABMAFwAbAAATIRUhFSERIREhNSEFNSEVASE1KQEVITUzFSE1oAbA/dgByPoAAdj9yAQI/sD+OAE4/sgB'
    'yAFAkAEoBkCYoP4IAfigoKCg/pDo6Ojo6AAAAgBo/4AEmAPgABkAJgAAEyEmJzcWFyEVIQYHETY3FwYHJxEGByckNyEFFhc2'
    'NxcGBxYXByYnoAHAGCCYMCABiP4YQGCYgCjYuFBQYFgBCIj+qAIIYFBgQIhIaFhQaNDwAzhAODBIYJBwWP5IKDCISDBYAYBA'
    'OIiQsIg4OFhgSGhgSFCA6JgAAAMAYP9YB7gE4AAoACwAMAAAASERIRUhESEWHwE2NxcGBxYFByQBBgcRMiUXBAUnEQYHJyQl'
    'IREhNSEzITUhESE1IQFwBQgBKP7Y/cA4OHDIkIhw6MgBUDD9gP6ogIgoAYAo/tj/AFCwiGgBmAEg/lj+8AEQmAPY/CgD2Pwo'
    'BOD+6JD+6FhAcFiIaHBogBigGAJYaEj+yHiIYEBYAUBQKIhouAEYkIj+YIgAAwGY/3gHeAIoAAsAEQAXAAABMxEzETMRIRUh'
    'NSEBFwYHJzYlFhcHJicDsJi4mAHg+iACGAMAmGh4kJD8MHhYkFCAAij94AIg/eCQkAIAMPigULjAsNBAwLgABQBw/0AHsAU4'
    'ABcAHgAkADYAUgAAARcGByEVBgcWFwckJwQFJyQ3JicGByckFxYXNjchBiUWFwcmJwMhERYEKQEHISAnBgcnNjcRIykBNTMV'
    'IRUhFSEVIRUhFSEVIzUhNSE1ITUhNSEESIgYEAIoYJjg6FD+yPj+4P5wQAFA4GhgSGBwAUhIgJigWP4ICP0wiHhggJBQAYhg'
    'ASgB2AJIQP1w/bDAeIhggIDwAnABwKABwP5AAZj+aAIw/dCg/dACMP5oAZj+QAU4KCAQiHhYOCCIOFBoMJgYQDA4MDBYoEBI'
    'QEBYCMBYeHiAWP6Q/UBIQJCwaGCQQEgCSGBgeEh4WIBwcIBYeEgABAJw/0gHsATYABYAHQAlACkAAAEXByEVBgcWBQckJQQF'
    'JyQ3JicGByckFxYXNjchBgERIzUhFSMREyE1IQQQmDACaHCg2AEIUP7A/wD/AP6oWAEwyGhYUFiIASBoeKCgWP4ICALAmP2g'
    'kJACYP2gBNgwUIC4cFAwoEB4gDiQOFBIWEhAaMg4cFBgeBD92P2wWFgCUP6Q6AACAJADmAd4BngADQAjAAABMxEjNQYFJyQl'
    'NSE1ISUzFSQ3FwQFFRQWMzI2NxcOASMgJjUC4KCg+P7YMAFAARD90AIwAXCgARDwWP7o/sBIwIhQEJggiNj++KAGeP04oGhQ'
    'kFhggICQuEBQgGBAoCAYUKA42GhIYAAFAHj/eAeQBOgAEwAXABsAHwAjAAABMwchFSEHIREhFSE1IREhNyE1IQE1IR0BITUh'
    'ESE1IREhNSEDsKAIAvD9AAgCUAEQ+OgBGAIAEP0YAvACSPw4A8j8OAPI/DgDyPw4BOioiGD8qIiIA1hgiP44WFjQWP7YWP7Q'
    'YAAAAQCg/0gGiAPAABgAAAEGByckExcGByEVAgUEBSckASEGBxYXByYCGEBQgAFIyJgoMAMwqP7Y/oj9sFAEEAEQ/SAQQIBw'
    'cHABqDgwgNABMFBAQJD+2LDgYLiIAdgYOFhggHgAAAYAaP9QB5gEuAAPAB0ALgAyADYAOgAAARYXITY3FwYHIRUhNSEmJwEz'
    'ERQGIyIvARYzMjY1AREUBiMiLwEWMzI9ASERIxETITUhESE1IQEzESMCcFhAAchAKKAoOAIg+NAB6DA4BICgUHhoYBhgaCAg'
    '/WBoaEBQIHA4QP5AmJgBwP5AAcD+QANIoKAEuFBgUGA4QDiQkDgw/rj86HBQGJAYIDgC0Pz4WFgQiAhIWP7QA7j++Hj+kHAB'
    'YP1wAAAFAGj/SAeYBJgAFQAZAB0AIQAlAAABIREhFSEVIREjESEGBSckNyE1ITUhEyE1IREhNSERITUhATUhFQFIBYD+yAII'
    '/fig/iAw/oBwATg4/ggCEP7QmARQ+7AEUPuwBFD7sAMQ/igEmPz4eJD+yAE4wICYSGCQeAIoWP7YWP7YWP6oeHgAAAMAYP9I'
    'B0AEeAAeACIAJgAAASERIRUhAgYjIi8BFjMyNjchESMRAAUnJDchEyE1KQEVITUBITUhATAFsP2AAuAQYFiIoCCweBgQCP3Y'
    'oP74/gBYAfjQ/cBgAnj9cAMwAeD7aAIY/ggEeP5AsP6IsAiYCEDI/cgB+P7YoJCQ6AHAsLCw/hiwAAADAQAC0AdgBngAAwAa'
    'AB4AAAEzESMBFhc2NyE1IRUCBxYXByYnBgcnNjcmJwEzESMCaJiYAdBwmKBQ/XADUHCooOhw6LjA6FDIkIho/UCgoAZ4/FgC'
    'kIBgeKCYcP8AiFA4kEhgeDiYKFBggAEY/RAAAwCw/4gHeATIAAUACwAXAAABFwAFJyQlBAUHJCUBIRUhESEVITUhESEDGGj/'
    'AP6IWAGQArABUAEggP7w/rj8oAXY/WADGPlAAwj9aATIeP8AgIiYyKDYgOCY/kig/kCYmAHAAAIA6AMYBygGeAARACUAAAEX'
    'BgURJSc3FhcHJicGBycRJCkBCgEjIi8BFjMyNhMhAgUnJBMjA0hw+P7AASBQgIBYkBgg4NBIAWABqAM4CICYKFAgYDBAOAj+'
    '6Aj+2HABAAjgBniAaDD+iHiISMDgQEhAcEhYAmA4/hj/ABCgEJgBIP544HjQASAAAAUAoAHIB2AFkAAdACMAKQAvADUAAAEX'
    'BgcyNzY3FwIFNjcmJzcWFwcmJwQFJzY3BgcnNiUWFwcmJyUXBgcnNgEXBgcnNiUWFwcmJwOokHhgcIhIQJDo/uDIqCAogIhg'
    'kCAo/tD+oCjAsIiYGKj+GIBYkFCIBdiIiIh4oPvAeJDYeOAEqKiQeIigBZAo+HAYUFgw/sjQICgwMECgyEBQSEgwgHiwGBCI'
    'yEBwiFCAcFhQsGhweP7wWLCYeJh4YIiQoGgAAQBgASgDMAaAACAAABMhETMRMxUjETcXBgcRFAYjIi8BFjMyNj0BBgcnNjcR'
    'IYABKKjQ0MgYcHBgkDg4IDhAQCCAmDCwmP7YBTgBSP64kP74QIAwIP7weGAIoAgoOLgoIJAgMAEwAAACATgBgAc4BngACwAP'
    'AAABMxUhFSERIREhESEBIREhA4igAxD88AKY+ngCUP5QBEj7uAZ42Jj++P2AAoD+GAFQAAAEAHgCqAdQBogAEwAnACsAMAAA'
    'ARYXIRUhETc2NxcEBScRIzUhJiclERQGIyIvARYzMj0BIQYHJzYZARMhNSEDITUhFAHoWEABUP3IIPDYKP64/uhIiAFQMDgF'
    '8EhQQHAgeDAo/gBASIigmAHY/igQAej+IAaIYHiY/lAQQECIYEhYAfiYQDgo/QBQWBCQEDBouHBgyAEQAXD+8ID+iIBAAAAD'
    'AHD/qAeQArAACwARABcAADchETMRMxEzESEVIQEWFwcmJyUXBgcnNnACgKDwoAJw+OABIJBgkFiQBWCQcKhokDgCeP2IAnj9'
    'iJAC6MjgUNjISFDQwGi4AAAFAHgCOAeYBoAAFwAdADsAPwBDAAABFwchFSMCBxYXByYnBgcnNjcmJwYHJzYXFhc2NyElITUz'
    'FSEVIRUhESEWFwcmJxUjEQYHJzY3IxEhNSETMzUjIRUzNQUQkDAB+HAwgIjIYLiYgMhgwIBoSCgoYKBYWGhoKP7Q+2gBmJAB'
    'kP5wAUj+8IhwWGhwkIjgWLig+AFg/mjI0NABYLgGgCCoiP7giHBYgGCAeFCAQHBogDgwcNhYmHiIwNhwcHhw/nhYaHBoUOgB'
    'KKhoeEiIAYhw/oCYmJgABgB4/0AEQAZwABAAFgAcACIAOwBBAAATIREzESEVIREjNQYHJzY3IRMWFwcmJyUXBgcnNhEWFwcm'
    'JwEhNjcXByEVBgcWFwcmJwYFJzY3Jic2NyMhBgcXNjeQAaCQAYD+gJCIuGjImP6owEAogCg4Ash4SFBoUFg4eDBY/ZABOCAY'
    'mDABaGCIiHBgaKio/ugw0JiAmGBI6AGQOEDAeEgFIAFQ/rCI/pD4wHiAaMgBuGB4QHhoODiISGBI/mBgaEhwYP5wQEAQcIjQ'
    'kFBIkFhgkFiIQGhISIB4aFBggJgAAgNo/zgHoAZQACAAJQAAASMRIxEhAgYjIi8BFjMyNhMhESECAxYXByYnBgcnNjcmBTY3'
    'IRIEYFigA6gIaHhoeBh4eCgQGP2YA0go0IjAWMiYmNBo4Ii4ASCIKP5oUAMI/EgHAP5YyBiYGDABEP3g/lD+2IBQqGCYoGiQ'
    'YJDQUNj4/vAABAGw/0AHQANIABQAKQAvADUAAAEhERQGIyIvARYzMjURBgcnJDcRISUhERQGIyIvARYzMjURBgUnJDcRIQUW'
    'FwcmJyUWFwcmJwIAAkhQSFiIIJg4MNDwQAEo2P5QAqACoFBIWIggmDgw6P7wQAFI8P34/chwWGBYaAMQeGBgYHADSPygUFgQ'
    'kBAwAQCYeIiImAEgkPygUFgYkBgwAQCQeIiAmAEgKFBocHBQaFhocHhQAAQCEP9QBzgDIAAYABwAIAAkAAABERQGIyIvARYz'
    'Mj0BIREjESMRIxEjESMREzM1IwUzNSMFITUhBzhoaDBAIFgwSP8AkPCQ8JiY8PABgPDwAYABAP8AAyD86FhgEJAQSOj+qAFY'
    '/pgBaP5YA7j+gPDw8PDwAAACAGj/SAPwBkgADwAUAAABFwQFFSERIQIDJzYSGQEkASERIRQDoFD++P6oAhj92AiIiEBIAaj+'
    '8AGA/ogGSIhQMOD9kP5g/vhwgAGoAiABwCj8oAFAsAAAAgCIAjgHgAZ4ABUAGwAAEyE2NxcUByEVIRIFByQDIwIFJyQTIQEW'
    'FwcmJ/ACkBgImBgDEP2w2AHIQP3w+ECw/aBgAhiw/aACwKiQcJCgBWh4mBCIeJj+gHigmAIA/fiIkHgBiP64UGCIeFgAAwCI'
    '/0AHmANoABoAIAAmAAABMzcSFzY3FwYHFgUHAAMRFAYjIi8BFjMyNjUBFhcHJicFFwQFJyQDoJAYeKioYIh4sLABGID+IPhQ'
    'eGhYIGhgICD+MIBQkEiAAfgg/pj+4FABuANYEP8AsHiAaIhwmICgARABmP3QeFgYmBggQAKIcIBYgHi4mPB4qKAAAAUBuP9A'
    'B3gFYAAIAB8AIwAnAEYAAAEWFyEVITUhJwUVAxYVFAYjIi8BFjMyNjU0JxMhESMRBSERITchNSEDIRUGBxU2NxcGBxUUBiMi'
    'LwEWMzI9AQYHJyU1NjchA4AgGAEw/PABQDAEgJiocHgwWBhgQDAwwKD+6JD88AKI/XiQAWj+mLAC0ICYqIgYoKhgWFBIGEBQ'
    'QKCoGAFgcGD+EAVgOEiIiFBAiP6A2OCQmBCYGFBI0NABmPrYBbDw/qh4aP7AiFhQIBAYeCAYoEhIEJAQGHgYEIggiDA4AAAD'
    'AYj/cAeYBPgADwAcACkAAAEhETMRIRUhESEVITUhESEBFwYHFhcHJicGBycSARcGBxYXByYnBgcnEgIYAhigAlD9sALI+fAC'
    'qP3oA+CYECCgcHhYeECQePD9AJAIGHhgeEhYOJhw6AGgA1j8qJj/AJiYAQADuCBwaKi4gKiQqKB4ARABWCBgWKiogJiIqLBw'
    'AQgABAGI/0AHoAUQAA8AEwAlACoAAAEhNTMVITUzFSEVIREhESEFNSEVASEVBgUWBQckJQQFJyQ3JicjIRYXNjcB4AEwmAHo'
    'mAEw/tD86P7QA7D+GP6IBKiI/wDYAXgw/jj+6P7Y/oBgAWj4uJhoATCYqNCABHiYmJiYiP7AAUC4uLj+8HjIkFgQoBCYeECQ'
    'MFh40KhQaJAAAwH4/6AHmARIAAUADwAVAAABEhMHAgMBIRITFwIDIRUhExITBwIDBICQMLAoiP4YA0DAiKiAuAGo+mDwoFCg'
    'UKAESP64/rgwAWgBMPwYAcgCKDj98P5YmAQQ/tj+kDgBcAEwAAECEP9IB1AEsAAlAAABIRUGBRYXIRUGByc2NyERFAYjIi8B'
    'FjMyNREhNSEmJzcWFzY3IQJoBGjI/wAYEAIgQFioUDD+UFh4eGggcHhI/dACUHiQcFhYuKD8mASwkLCAEBiIsKAwkIj96Hhg'
    'GKggYAHwkFhYUDgwUGgAAwBgAGgHwAUoABgAHAAgAAABIREhByEVIRYFByQnIQYFJyQ3ITUhNjchEyE1IREhNSEBkATg/RhA'
    'BDj+WLABOHj+mND9wNj+uFABSGD+eAIQMCD+sJgDsPxQA7D8UAUo/bhgiIB4kLjQ4LB4uGCIMDABYGD+yGAAAgIQ/zAHeAOQ'
    'AAMAGQAAASEVIQEhNSEVIQIHJCUmJzcWFwcmJwQFJzYCsAQY++gBGP5IBWj9EJioAWABcFhoiPigmCg4/gj90DDwA5CY/piY'
    'mP7wgBAwYGBQ0PhYSEhQGJCYAAMBWP9IB2ADkAANABEAFQAAASEQAiMiLwEWMzI2EyEXIREhNyERIQFYBghwoHCgIKh4QDgQ'
    '+pDgA3j8iJgCSP24A5D84P7YEJgQqAKAmP3gkAEAAAEBwP9oB6gECAAmAAABFwQFFSUXBRUlFwUVFBYzIDY3FwYHBiEiJj0B'
    'BSclNQUnJTUFJyQGiEj+4P7AAoAQ/XAC6BD9CFCIAVBoEJgYWFD+YPh4/gAYAhj+YBgBuP5wOAJ4BAiAKCCIQJBAoFiQWMAg'
    'IFCIKMBIOEhg0ECQSKAwkDCIIIgwAAACATACqAdIBjgAEwAXAAABESEVFBYhIDc2NxcGBwYhICY1ERcVITUGgPtQmAHAAiAw'
    'IBiYIFg4/ZD90MigBBAGOP3wmDAgGBCQWKgwIFBoAtiY4OAAAAcAWP9QB5AFMAAKAA8ALAAwAEEARwBNAAABFhcHJAM3FyEV'
    'BiUWFzY3JRcGByEVAgUnJBMhBxYXByYnBgcWFwcmJwYHJzYBIRUhEyE1IRUhERQGIyIvARYzMjUlFwYFJyQlBAUHJCUF+Ljg'
    'QP2Y+IA4AfhA/qA4UDg4+/iQCBABcPD9yFgCCND+4AhIOGAwOBggOChgKDAwMGD4AWACgP2A8P1gBfD9SFB4YFAYYGgw/uhY'
    '8P7YSAEAA5gBCAEAWP8A/vgDWIBQkNACMDhogHh4UEBAUOggKBiI/mDgeMgBQBAwOFg4MCAYKDBgODAoIHCo/siI/tiQkP7I'
    'aFAQkBBA6HioaJBQoFC4iMBgAAQAcP9AB6gE2AAXABsAIwA0AAABITUzFSE1MxUhFSEVIREjESERIxEhNSEFITUhEzMQAAUn'
    'JAA3MxEUFjMyNjcXBgcGISImNQFAAWigAXCgAXD+kAEIoPyAoAEI/pgCCAFw/pA4oP6I/ghAAeABMNiYYGj4UBCYGFBA/rj4'
    'aARAmJiYmJCo/aAB0P4wAmCoqKj+eP6Y/qgomCgBCCD+4CAgUJgwyEAwQFAAAQCA/0AHgASYADMAAAEhFSEHFhckNxcGBxIF'
    'ByQDBxYVFAYjIi8BFjMyNj0BAAUnJAEmJwAFJyQlJicEBSckJSEBcAUg/cBomDgBAMhwiIiAASBw/tiQeCCQiGjAKLiYMDj+'
    'iP34UAIwAYAQGP6g/lBQAcgBSCgw/uj+8GgBaAEo/hAEmJBIiKhoqIBgSP6owJDgAYAwcIjg6BiwIJCQWP7omJiYAShQMP74'
    'cIiI6DAwmFCQUKgAAAQAiP9IB4gE0AATABkAHwAkAAATITY1NhEzEAcUByEVIQIFJyQ3IQEWFwcmJwcWFwcmJwEEFwcBiAOQ'
    'SAioCDACmP0Y2P2AWAH44PzYAcjgwHC42GDguHC40ARAASjwaP3oAeCYwBABiP5IEKiAoP6wqJiA4ANIaIh4iGCQaIh4iGD+'
    'EKCQgAE4AAEAaP9IB5gDuAAbAAABIRUGBRUhFSERFAYjIi8BFjMyNREhNSE1NjchAbgEeNj/AANA/MBoaHBoGFhwYPyoA1jQ'
    'oPyIA7iggHg4mP6QSFAYmBggAVCYiGBYAAEAiP9AB3gEcAAbAAABIRUGBRUhFSERFAYjIi8BFjMyNREhNSE1NjchAZAEyOj+'
    '6AMg/OBwaLCoGJC4SPzoAxjwwPxABHCoqJBIoP4wSFAgmCAgAbCgoHh4AAEAiP9AB4AEmAAiAAABFSEVIRUhFSEVIRUhFSEG'
    'ByQlJic3FhcHJwQFJzY3ITUhEQaA/AADwPxAA8D8QAUA+4hwYAGoAcA4SIj4mJhw/bj9cCigeP5AAWgEmJB4gIiAeJCwUAgw'
    'MDBYoLhYgEgYiGiwkAMIAAADAGj/OAcYA5AACgAOABIAAAEhAgcnNhkBIREjESERKQIRIQZ4+0gQ2HC4Bfig/fgCCPtIAhD9'
    '8AFg/qDIiLABkAGQ/UACKP8AAQAAAgF4AQgGQAXoAAcAFgAAATMQAgcnNhIBFQYjIicmNREzERQWMzICwJi42FCwmAOASFDI'
    'KECYMGhQBej9mP4YkJCAAaj+aJAQIChoA7D8cCAgAAICiP9ABzACSAAHAAsAAAERIzUhFSMREyERIQcwoPyYoKADaPyYAkj9'
    'AICIAwj+GAFYAAAFAZD/SAeIBYgAFQAZAB0AIwApAAABITY3FwchESERFAYjIi8BFjMyNREhEyE1IREhNSETFwIHJzYlFhcH'
    'JicCSAGIKBCYMAKA/hBQaIBwIHiAMP3okAOA/IADgPyAMICo4HDwA6C4sJCYyATYWFgoiPz4/kh4WCCgKGABkAHQqP4YuP6A'
    'WP7YqHjIwJDQcMC4AAIBmP+YB1gFCAAPABUAAAEzESEVIREhFSE1IREhNSEBFhcHJicEGKACEP3wAqD6QAKA/hAB8AHQoGCI'
    'YJgFCP5omP1YmJgCqJj+8KDAULioAAABAej/QAcIBTAAHQAAASE2NzMGByEQAgYjIi8BFjMyNzYRIQoBByc2EhMhAlgBgBAI'
    'oAgQApAweIBoYCh4eFAQIP4IKOjwgNjgKP6QA+iYsLCY/XD+aIAgoCBoqAJg/oD+OLBwkAGgAVgAAgGAAIgGgAYoACUAKwAA'
    'ASEVBgUVNjcXBgUVBBcHJicRFAYjIi8BFjMyNREEByckNxE2NyETFhcHJicBkATw8P7g6Khg0P7gATDYYNDYWFBgYBBIYDD+'
    '4OBQAXDg6Lj8IHjAmGigsAYoqJiI0FCIgJBwIKCYgKB4/vhIUAigECABONhwoKiwAZBwaP7oeKCAsIAAAAIAiP9YBvgFMAAT'
    'ABcAAAEHIQoBIyIvARYzMjYTIRMXByEVASEVIQJwIASoKKDQgMAg6HhoYBD7YGioIAQI+fgFIPrgA8jo/Yj+8CCgKNABiALo'
    'EMCY/dCYAAEAgP9IB5AFYAApAAABFwIHJCUmJzcAEwcmJwYHERQWMzI3NjcXAgYhIiY1EQYHAgUnJBMFJyQDSKDg4AGwAdho'
    'eIgBILiYQEiAgDiI0CAoCKAIgP7I4ICYkFD98GgB2FD+iCgBUAVgMP6YoBBIeHBY/vj+2FhoaBgQ/WggGCAo4Dj++IBAYAK4'
    'EAj9iPiQ0AIAEIDAAAECeABYBJAGQAAMAAABFwYHETY3FwYHJxEkBFg4kOCYoDDQ+EgBAAZAkFBA+/gwSIhYWFgE8DgAAQBY'
    '/1ADwAaAAA4AAAEzERQHFhcHJicCAycAEQHwoCDAkGBwoHj4iAGYBoD+GNjIkLCQmIj+KP7gcAH4AuAAAAMDeP9wB5gGIAAN'
    'ABEAFQAAASEDMxUhNTMTIzUzEyMBIRMhAyETIQPQA3hYqPvgsDjA0DjYAUABcCj+mHgBiCj+iAYg+eiYmAKgmAJI/bgCSPqA'
    'AqAAAwN4/0gHkAaAABEAGQAdAAABFwIHJCUmJzcSEwcmJwQFJzYBESM1IRUjERMhESEFAKCwqAEQASBIUIiweJAgKP6Q/mAw'
    '6ALAmP3gmJgCIP3gBoAw/kCoEDiIeED/AP7QQFhYUBiQ4P3Q/MCAgANA/dABoAACAxD/QAeoBmgAFgAcAAABMxEhFSESBQcA'
    'AyMRNjcXBgcnESM1MwEXAgcnNgPIoAMI/liAAWBQ/mCIyICAQKjQaLi4AoiIyMh46AZo/TCY/fjQmAEIAmj9AFBYgHhwaANY'
    'mAKgUP6wwGjwAAAGA0D/UAeYBpAABQAmACoALgAyADYAAAEWFwcmJwUhETMRIRUhFSERFAYjIi8BFjMyPQEhESMRIREjESE1'
    'IRMhNSkBFSE1ASE1KQEVITUGkGhAeEBg/SAB4JAB6P4YAbBocDA4IFgoSP7okP7wmAGo/iDQARD+8AGgARj9SAEQ/vABoAEY'
    'BpBYYEhgUNABCP74kJj7wFhYCJAISMj+WAGo/lgE+Jj+ANjY2P3I2NjYAAMC0P9QB5gGkAAVACoAMAAAAQYHJyQTFwchFQAF'
    'JyQTISIHFhcHJgEhNTMVIRUhERQGIyIvARYzMjURIQUWFwcmJwPwSEhoARiAmDACQP74/ShYApjg/igIOFBQaFD+iAMooAEA'
    '/wBYgIB4IICAUPzYATCAUJBIgATYODBosAEIIGCA/gCYiIgBgEg4SIBQ/jDg4JD9+HhgGKAYYAHgWJCYUJiIAAADA2j/SAeY'
    'BngADwAXABsAAAEhETMRIRUhESEVITUhESEBESM1IRUjERMhESEDaAHAoAHQ/jABiPxgAXj+QAPQmP3YmJgCKP3YBXABCP74'
    'mP7omJgBGP2I/OiIiAMY/ggBYAAAAgUA/0gHMAZ4AAwAEAAAATMRFAYjIi8BFjMyNQEzESMGkKBgkHBYIHB4UP5woKAGePmg'
    'eFgYoBhIBXD7eAACAGD/cASIBiAAFQAmAAATIRUhAgc2NyYnNxYTByYnBAUnNhMhARcEBSclESE1ITUzFSEVIRGAA/D+IIiA'
    '4PA4QJCYYKAYIP6w/ogwuIj+qAPoIP5A/dhAAbj+iAF4oAGA/oAGIJj+uJAYOHhoQPD+6EhQUFAYmKgBQPsYkFhIqDABGJDw'
    '8JD/AAADAvD/QAeYBngADQAmAC0AAAEWFyERIzUhFSMRISYnExcGByEVIwIHFhcHJicGBSckNyUTIzUhNhM2EyEGBxYFYDgg'
    'AcCY/PiYAdAYMAigMDACeMA4gNC4aJD46P54SAFYyP6QiPgBOEDgcCj+uDBAmAZ4eJj+sMDAAVB4aP5QEKiIkP7QuICQkIiY'
    'yFiYSKDQATiQqP0wmAEAkGhQAAYCGP9AB3AGgAAPABMALAAwADQAOAAAASYnNxYXIREhERADJxIZARMhNSEBERQGIyIvARYz'
    'MjURIxEjESMRIxEjESMREzM1IyEVMzUzFTM1BLgoOKBAKAH4/AC4iKCgA2j8mAQYYGA4QCBgMDCIgJCAkJCQkJABEJCAiAWo'
    'WFAwYHj+EP7o/kD+aGgBSAGoAwj+oND+APzgWFgQiAhAAQj+6AEY/ugBGP4gA9j+kODg4ODgAAEDSP9IB5AGYAAUAAABFwQF'
    'ESEVIREjESEVEAEnNhI1ESQHAGD+4P6AAtD++JD+yP74cIBgAagGYIhgEP6gkPvQBDCI/gj+WGjoAXDgAvgQAAABAoD/QAeQ'
    'BngAIQAAARYXIRUhFAchCgEjIi8BFjMyNzYRIQoBByc2EhMjNSEmJwVwWCgBoP1QCAJwCIC4aJAQmGhIGDD+QCDY6HDA+Ajo'
    'AfAwSAZ4mMCYkHj86P7oGKgYaPABoP6o/liwiIABuAKImKCIAAYC2P9IB5AGeAATABsAHwAjACcAKwAAASERMxEhETMRIRUh'
    'FSM1IRUjNSEBESM1IRUjERMhESkBESERASERIQEhESEC2AEImAGAmAEA/wCY/oCY/vgEaJj9KJiYASj+2AG4ASD9KAEo/tgB'
    'uAEg/uAFeAEA/wABAP8AkPDw8PD+uPuocHAEWP5QASD+4AEg/TgBIP7gASAABABo/0gEOAY4ABEAFQAZAB0AABMhFSMRNxcG'
    'BxEjEQQFJzcRIwEhESERIREhESURIYADiGB4GEhIoP7Q/rAgkHgBGAFw/pABcP6QAXD+kAY4mPvYEJAQCP5oAYAwKKAQBID/'
    'AAEA/XABAP0gMAEgAAIAWP9ABwgGgAAQABQAAAEVEAIHJwAZASEmJzcWFyERAyERIQIQoKhwARgCgBgomDAYAnig+6gEWAMw'
    'QP6o/lCoiAEIAmgCaGBIOGh4/ZAB2P7AAAIAYAJoB5gGOAAOABQAABMhFSEGBxEjEQAFJyQBIQUEBQckJbAGoP0YEBig/tj+'
    'WHACKAEg/QgEeAFoAQiA/vj+oAY4mCAY/QACUP7wsIjgAUB4yOCA+NAAAAMAaALQBzAGgAAaAB4AIgAAEyE2NTMUByEQBiMi'
    'LwEWMzI2EyEGAgcnJBMhJSERITchESGgARgImAgBsHCYUHAgeFBQKBD+4BCouHABMBj+8AP4Apj9aKABYP6gBeBIWFhI/ejY'
    'IJAYiAE46P7oeHC4AVCY/VCQAYgABAKg/0gHmAZ4ACcAKwAvAE4AAAEzNTMVIREzFSMRIRUhFSEVIRUhFSM1ITUhNSM1MzUj'
    'NTM1ITUhNSMhFTM1AxUzNQEWFzYTIycTIzUhFQIHMwIDFikBByEgJwYHJzY3JgMEuMiQASBoaP7gATD+0AFg/qCQ/vABEODg'
    'yMj+4AEgyAFYmJiY/LAgICgYyBDY2AF4cGjIEGhgAbABmDj+oP44kFBoUHBIUCgF4JiY/vCI/vCYgJCA0NCAkICYgJCIkJCQ'
    '/uiQkP6YqICoAQB4AdCAeP74yP4o/tjgmOCQcHiAoLgBGAACAyD/QAewBngACwAsAAABFwYHIRUhIgYHJzYTIRUGByc3IxEh'
    'FSERFjsBByMgJCcGByc2ExcGBxYXESEEUJAYIALo/OAISFh4sCADUDhIoGjoAXj+iICwsDh4/tj+yGhAcGjQGJAQIFCA/ugG'
    'eDBYSJCgcGDo/uCIeHgwuP6okP5gGKCIkLCIiPgCCBDosIhIA1AAAgCI/0gHeAL4AA8AHwAAATMRIzUhNSE1ITUhNSE1ISUz'
    'FSEVIRUhFSEVIRUhFSMC8IiI/ZgCaP3wAhD9oAJgAYiYAlj9qAIA/gACaP2YmAL4/FCYiHiAgICYmIB4gICImAADA1D/iAeQ'
    'BjgAAwAHABsAAAEhESE3IREhAyE1ITUhFSEVIRUhFSEVITUhNSEDuAN4/IiYAkj9uKABeP5gA+D+YAFo/pgByPvAAdj+iAY4'
    '/ZiQAUj7+PCQkPCQ+JCQ+AAEAfj/WAewBoAACQAPABUARQAAASEmJzcWFyEVIQUXBgcnNiUWFwcmJxUWFwcmJwcWFzY3FwYH'
    'FhcHJAMGIwYHETY3FwYHJxEGByckEwYHJzYTFwIHNjcmJwJ4AiAgMKg4KAIQ+xgBGICQ2HDQAyCgoHiQuLCocDAwsDBIiHB4'
    'kJCI4FD+OLAQGFhYkIAo0LhQmIBgASjogIgo8KCgkJjo+EBIBcBQODhYaJAQSLCocJCgeKCAoKDAiMhwQDggqJBgaHCAWLgo'
    'oHgCsAh4aP5gMDiAYDhQAXCAQICAASAQCICQASgw/wB4GChIQAAAAgKg/1AHmAaAAAoANwAAARcGByEVIQYHJyQBEAYjIi8B'
    'FjMyNhMFESMRBxEUFjMyNz4BNxcCBiEjIiY1EQcnNxEzETcRMxEEIJgoMAMQ/Jh4iGgBAAOYWGhASChISBggEP8AmNhI0IiI'
    'eCgImCiQ/mhY2ICYKMCY2JgGgCBwaJjAcHDw/sD9yOgQoBBwAThI/cgCCDj94DggCAhYoED/AFhQWAIwKIg4AVj+2EABUP7g'
    'AAMAWP9AAgAGWAAFAAsAEQAAARYXByYnExYXByYnARcCAycSAQCQcHhwkDiYgHCAkAEIgFioiKgGWHB4eJB4/nhggICQaP5Q'
    'WP6Q/qhoAUgAAwMw/1AHkAZQAAUAFAAdAAABEhMHAgMlMxADFhMHJicCBSckExIBMxE2NxcGBycEoKBokGiYAhiYcLCIcHiQ'
    'iP74UAEgeGD9AJh4cECYyGAGUP7o/rhAAVABEDD8kP7g0P74gPi4/viwkMABcAEgAnj7YFhogIiIaAADAKADmAdYBogABQAT'
    'ABkAAAEWFwcmJyUXBgchESM1IRUjESE2JRYXByYnBABYKKAgUAJ4uFCYAaCY+niYBGCY/FhoQJA4aAaIcJA4kIAYOJCQ/nj4'
    '8AGAqJhgcFhwaAABAED/QAegA0AAJAAAJQYHJyQlITUhJic3FhchFSEWFzY3FwYHFhcHAAEGBxElFwQFJwHomKBwAgABAP1I'
    'AvgYIJgwIANI/UBYcIhgiHCAqPh4/ej++KDgAeAw/rj+6FDAQDiImLCQODAwSFCQiHBQeGh4SIBomAEIAdCYeP7YgIhYOFAA'
    'AAQCWP9IB5AGIAAHAA0AEwApAAABESM1IRUjEQEXBgcnNiUWFwcmJwEhETMRIRUhEgUHJAMRIxECBSckEyEHWJj8sJgBaJCY'
    '6HjYAgDouHDA2P2YAdiYAgj+UMABKFj+6NCY0P7YaAFIyP54BiD+ePjwAYD++FDYwHiwsIi4iNCI/jABAP8AkP7AmKiwAWD9'
    'gAJw/sC4gMABOAABAFj/SAKQBngAHwAAEzMRMxEzFSMRNxcGBxEUBiMiLwEWMzI1EQYHJzY3ESN4wJjAwJggWGBAWFBIKFhQ'
    'GFBYOHhowAUoAVD+sJj+cFiQQDj9yHhYEJgQYAHAMCioMDgB2AAAAgKQ/0AHqAaIABwANgAAARcGBxUhFSEWBQckAxEjEQYF'
    'JyQ3ITUhNQYHJyABIQMhAgYjIi8BFjMyNjchEyEKAQcnNhI3IwboSND4Afj+gKgBIEj+0MiYqP7gYAEQiP6QAgDI4CgB8P4A'
    'A9BoARAYgKg4UCBoQEhAEP7YaP5YEJioeJiAGNAGiIAwGMCQyGiQiAEQ/pgBePioiJCgkLAYCJj8eP7w/niwCJAQWMgBEP7g'
    '/sh4gGABCOgABgBYAyAHoAaAABkAHwAzAEgATABQAAABFwYHIRUjBgcWFwcmJwYHJzY/ASYnBgcnNhcWFzY3ISUzNTMVMzUz'
    'FTMVIxUjNSMVIzUjHwEGByEQBiMiLwEWMzI2NSEGByc2FyERITczNSMFEJAQGAIAcDh4mLBA0LCguEhYSIhIQCgoYJhYUGhw'
    'MP7Q+2DoiOiA+PiA6IjoeHgIEAKYSGggKCBIIBgQ/cA4YGCIUAG4/kiAsLAGgCBAQHDAgEgwgDBoeDB4GChAQFA4MHC4UGBI'
    'YJjASEhQUGhQUDg4KCggIP54kAhwCFjgYGBYiHj+6FhoAAAEALgEYAcYBmAADAAYAB4AJAAAASERIzUEBSckJRc1ISUhESM1'
    'BAUnJCU1IQUWFQc0JyUWFQc0JwQoAvCI/uj+sCgBaAEgCP2Y/JAC6Ij/AP7YMAFIARD9oARoOIgo/XgwiCgGYP4gcEg4eDhA'
    'EJB4/iBQODCAKDCoGEBIEFA4CEBIEEg4AAkCGP9oB5AGeAARABUAGQAdACEAJwAtAD0AQwAAASE2NyE1ITY3FwchFSEHIREh'
    'NzM1IyEVMzUzFTM1ASEVIQUWFwcmJyUWFwcmJyUzERQWMzI2NxcOASMiJjUDFwYHJzYC2AFYGBD+QAHgGBCoIAIg/bgwAjj7'
    '0JigoAEwqICo/CAE2PsoAlhgQIA4YAIoeIB4cJD9cJhAmJBIGJgggOjwgNiQSFiIaASwOECQYGAgoJB4/gCI8PDw8PD+GJAQ'
    'aHhQeHAoiLh4uKgw/tggGDhgOJBgUGABMDDgmEiwAAICOP9AB6gGeAAFABkAAAEWFwcmJwUXAgEWBQckJwQFJyQ3AAMzEgEA'
    'BKCYOLAwkAKQmFD+qOgBQGj+yPD++P5wSAF4+P6QaKBgAUABMAZ40OAw8MjgIP2A/ojoqIiw+PiokKjoAagCMP4A/pABMAAC'
    'AmD/UAeIBhgABwAgAAABESMRIREjEQERFBYzMjYTFwIGIyImNREhERACByckGQEHKKD80KADiBBAMCAIoBBYqIhQ/qiwwHgB'
    'SAYY/hgBUP6oAfD+UPvQMBhQARgg/riQSGgDwP5g/vj+sIiA2AHgAeAAAAMBYP9IBpADSAAQABQAGAAAAREUBiMiLwEWMzI9'
    'ASERIxETITUhESE1IQaQeHhwiCi4YGj8AKCgBAD8AAQA/AADSPy4YFgYkBhIcP64BAD+4JD+YIgABQLw/0gHeAaAAA0AGAAq'
    'AC4AMgAAAREjNSEVIxEhJic3FhcFFwYHESMRBgcnEiUhFSEGByERIzUhFSMRMzY3IxMhNSERIREhB3iY/OCYAdggKJg4IP5Y'
    'iCg4mCAoWMABEAKQ/vgQGAEQkP7AkMAYEPigAUD+wAFA/sAFwP7wgLgBSFBAMFho8CiIiPuwAxhAOJABIPCIWFj7+HBwBAhY'
    'WP3Y+P1oARgABAKQ/0AHeAZ4ABcAHwAnAC0AAAEhNSE1ITUhNSE1MxUhFSEVIRUhFSEVIQURIxEhESMRBRcCAAUnJAAXBBcH'
    'JicDCAHQ/ogBeP5IAbigAcj+OAGA/oACAPuQA8iY/diYAXCYKP64/rg4ASgBENgBANBo4PAD4HiIcIigoIhwiHiIYP2YAeD+'
    'EAJ42Aj+wP6wSJA4ARhwaIiAmGgAAwB4/1AHiASYAA8AJQArAAABITUzFSEVIRUhFSE1ITUhAyE1MxUhFSERFAYjIi8BFjMy'
    'NjURIQUWFwcmJwEIArCgApD9cAMw+PADQP1QOASYoAFA/sB40JiIGJigWFD7aAEoeICIaJAEMGhokJiQkJj+OHBwkP7QcFgg'
    'oCgoIAEYIGCAaHhwAAEASP9AAzAGiAAYAAATISYnNxYXMxUGBxYXByYnESMRBgcnJBMhgAEIMDiYSDDoYHCIYGhQUJh4cGAB'
    'UOD+CAWIYFhIeIiY6LBYYIhYUPyAAxiQSJDoAfgAAAUBMAOIBugGSAADAAcACwAPABMAAAEhESETITUpARUhNQEhNSkBFSE1'
    'ATAFuPpIoAHo/hgCiAH4+4AB6P4YAogB+AZI/UABqIiIiP5ogICAAAABAID/eAeAAnAAEwAAASE1ITUhFSEVIRUhFSEVITUh'
    'NSEBGAKQ/RAGiP0IApj9aAM4+QADKP1wATiokJCoiKiQkKgAAAQAgP+IB3gDQAADAAcACwAPAAABESERATUhHQIhNQEhFSEG'
    'mPrQBJD8EAPw+ogG+PkIA0D9UAKw/uiQkIiIiP6AmAAAAgCA/4AHkAMYAAkAGQAAEyEmJzcWFyEVIQUWFyE2NxcGByEVITUh'
    'JifwAtgYIJgwIAKw+cgBOHhIAiBgSLBQWAHY+PABuDhgAmhAODhYWJAwwNC4yDDAkJiYoJgAAAEDQP+QB1AFqAANAAABIREh'
    'NSERIzUhNSERIQOAAyj8wAPoqPyYA2j82ANQAcCY+eiImAIIAAQC+P9AB5gGQAAaAB4AIgAmAAABIREhESEVIREhESUnNxYX'
    'ByYnBAUnJREhESEDITUhAyERIQEhESEE4P6gA2D+mAGo/lgBCFCAkFiQGCD+UP34IAHo/mgBmMgCOP3IQAEI/vgBoAEQ/vAE'
    'MAIQ/fCo/aj++Bh4ULDIUEhASDCgKAEYAlgBOPD8EAE4/sgBOAAABQJo/0AHsAaIABMAGQAzADcAOwAAASEmJzcWFyEVIwYH'
    'IRUhNSEmJyMFITY3IRYBIREhFRQzMjY3FwYHBiMiJjURIwIFJyQTIxMhNSERITUhAwAByBAYmCAYAfDgGBgBUPswAUAYMMgB'
    'sAEAGBj+kCj+mAPo/vBogCgIkBA4KNCwULBI/khYAWhQ8JgCuP1IArj9SAXoODgwUFCIeECQkGBYuFBoYP7A/Wj4SFCIKNg4'
    'MEhgASj+gGiYQAEQAZB4/oh4AAQC2P9QB5AGeAAJABkANAA7AAABFhchFSE1ISYnASEmJzcWFzM2NxcGByEVIQchNjcXBgch'
    'FSMGBxYXByYnBgUnJDcmJzY3KQEGBxYXNjcFYCgYAdD7uAHIECD+OAEoKDiQSCj4QDCoODgBMPtoIAF4KCCgIBgCkMBIcLig'
    'YJDYuP6gUAEIsLjYWEj+0AHgQECooHA4BnhYcJCQUEj9oHhoKHiQiIgwgGCQ0FBQEEhIkOiQUFCIUGiQMJAQaFBIiIBwUDhA'
    'cMgAAgCo/0AHgAKQABIAFwAAASM1IRUCBQQFByQlBAUnJD8BJAUkNyEWAaBoBXCY/tgBGAGAOP4w/rD+kP4YKAEY0OD+8AHA'
    'ATCQ/HDQAfiYiP7woFAwmDCQmCiQGDBAmFCQyPAAAAIAmP9IB3ACeAAUABoAAAEzFSEVIREUBiMiLwEWMzI1ESE1IQUWFwcm'
    'JwVQoAGA/oBgkFhQIGhgUPtIBLj84LiQaKCoAniYkP7IcGAQoBBQARiQ2FBogHhQAAEAgAMQB4AGSAANAAABITUhNSERIRUh'
    'NSE1IQGQBAD7uAToAVD5AAUQ/AAE+LiY/WCYmLgAAAEBwP9IBmgCCAAYAAABMxUhERQGIyIvARYzMj0BIREjESERIxEhA7iY'
    'AhhgYDBAIFgwMP6AmP6gmAH4Agh4/vBYWAiQCEho/jgByP6YAegAAgBo/5gDwAZ4ABMAFwAAJRUjESERITUhETMRIRUhESER'
    'Iz0BESERAUCgASD+qAFYoAFg/qABGKD+aFjAA3gBYJABeP6IkP6g/PhQmAGY/mgAAAMDAP+YB5gGgAAJABMAGQAAASEmJzcW'
    'FyEVIQUXAgMhFSE1IRIBEhMHAgMDUAGwKDigQCgBuPvwAxCweIABgPtoAmiY/jhwKKgoaAUgoIg4oMCYSDj9yP5gmJgB6AH4'
    '/lj+WDAByAGIAAAFATj/QAbAAnAABwALAA8AEwAXAAABESM1IRUjERMhNSkBFSE1ASE1IQUhNSEGwJj7qJiYAej+GAKAAdj7'
    'qAHo/hgCgAHY/igCcPzQODgDMP7IqKio/iioqKgAAAMCwP9IB4AGOAASACQAKQAAAREUOwEVIyImNREhAgYHJz4BEwMjNSEV'
    'AgcWFwckJwYFJyQ3JgU2NyEWBog4uNhgWP6gCICQaIhgCDBoA6CAwMj4WP7w2PD+yFgBMNCoASigWP4wSAY4/iBYiFBYAYD+'
    '6PBYeFjgAUj8UJBw/siwiFCgYKi4UKBQkLhYmMjQAAQC+P+IB5AGeAANABMAGQAlAAABESM1IRUjESEmJzcWFxMWFwcmJyUX'
    'BgUnNgMhFSERIRUhNSERIQeAoPzIoAHoGCioMBhYwKBwoMD+6JCI/wBg6KgD0P5oAgD7aAH4/mgFmP6Q4PgBiGBYKHBw/tiI'
    'sIjIiGBQ2KCAmP6IkP5wkJABkAAAAgBo/4gHkAGoAAMABwAAASEVIQchFSEBQAVo+pjYByj42AGomPCYAAIAcAIQB6AGeAAQ'
    'ACgAAAEzESEVIRElFwQFJzcRMxE3ATMRJDcXBgURFBYzMj4BNxcCBwYhIiY1AjigATj+yAE4IP5o/hA4aKDAAjigARDAcPj+'
    'uDCAyFggCJgQUED+wNh4Bnj+2Jj+UDCAYEigEALo/SggA4j+gFiIgJho/sAgGCBYoDD++EA4SFgAAQCABBAHgAaAAA8AABMh'
    'NTMVIRUhFSEVITUhNSGAAzigAyj82AKo+hACqPzIBeiYmJiomJioAAACAUD/SAa4AqAABwALAAABESM1IRUjERMhESEGuKD7'
    'yKCgBDj7yAKg/Kh4eANY/bgBsAAAAgFY/0gG0AIIAAcACwAAAREjNSEVIxETIREhBtCg+8igoAQ4+8gCCP1AYGACwP44ATAA'
    'AAMAcAIYB7AGgAAMABIAGwAAARcGBwAFByQBAAUnAAUWFwcmJwEhFQYHJzY3IQPooBAQAXgB0GD+SP5o/pD+MFACaAFAWDCY'
    'KFj+KASYgLiIgFj8UAaAMBgQ/si4oMABYP6Q2JgBMChoiDCIaP7wmKCAYGBgAAADAND/mAQQBgAAEQAVABkAABMhESERNjcm'
    'JzcWEwcmJwYFJxMhNSERITUh0AMI/ZDguDhIkJhooBAg8P7ISJgB0P4wAdD+MAYA/HD98FBYaGhI4P8ASEBAeGhQBJjw/Zjo'
    'AAMDoP9IB5AGOAARABYAKgAAASM1IRUCBxYXByQnBgcnNjcmBTY3IRYBITUzFSEVIRUhFSERIxEhNSE1IQQoSANAcKCg4DD+'
    '+Mi46FDgmIgBAJBQ/lhQ/vABOJgBWP6oAaj+WJj+cAGQ/sgFqJBw/vCYWDiQMJCIOJA4YJhAgKiw/YjAwJDImP64AUiYyAAF'
    'AFj/kAQABiAAFQAZAB0AIQAlAAAlFwQFJyU1ITUhNSERIREhFSEVIRU2ATMRIyERMxEBMxEjIREzEQPoGP5o/hAgAXj+sAFQ'
    '/qgDQP6wAUj+uND92MDAAVi4/fDAwAFYuMCQYECgMNCQwAOg/GDAkLggA/gBAP8AAQD9gAEA/wABAAACBHj/sAdQBdAABwAL'
    'AAABESM1IRUjERMhESEHUJj+WJiYAaj+WAXQ+eiIkAYg+wAEcAAAAQNg/0gHoAaAACUAAAEXByEVIQYHIRUhByEVBgcWFwcA'
    'JTcWFzY3ISc2NyE1ITchNSE2BQCgKAH4/fAYIAJ4/WhAAqCQwGBQeP7w/sBooJCQeP2oODgg/vgBKDj+6AEwGAaAEOCQeHCY'
    '4JjwsEhQiAEAsIhYaJC4kGiAmOiQeAAFAmD/SAeQBoAACQATABkAIQAlAAABISYnNxYXIRUhBRcGByEVITUhNiUWFwcmJwER'
    'IzUhFSMREyERIQK4AdgYKKA4IAHQ+6ADULBIUAFw+tADCFj9+EgooChIA9ig/SigoALY/SgFwFBAMFhomEAwsJCYmLC4eJA4'
    'mHj9cP0oUFAC2P4QAVgAAQKI/0gHkAZ4ACAAAAEhETMRIRUhESEVIQIHJCUmJzcSEwcnBAUnNhMhNSERIQLgAdCoAdD+MAI4'
    '/WCgqAE4AUhAUJCweKhA/mD+MDDYmP5QAij+MAUgAVj+qJj+qKD+WLAgUJiIQP7g/qhIyGAgmNgBkKABWAAABQJY/0gHkAaA'
    'AAUACwARABcAMwAAARcEBScgBRcGByc2JRYVBzQnJRYXByYnAyE1NjchNSEVBgcVIRUhERQGIyIvARYzMjURIQboUP4w/XA4'
    'AigB+JBYcJCA/og4iDj+uHBAiEBoWAJwsIj8wAQouNgCOP3IcHBoaBhQcHj9kAaAiGgYoKgw2IhIqHCYsBC4iAiImDigePzo'
    'aGhoiJiQiBCg/qhIUBCYECABOAAAAwK4/0AHmAY4ABIAIwAoAAABERQ7ARUjIiY1ESECBgcnPgETAyM1IQIFFgUHJCcGBSck'
    'NyYFNjchEgZoQMDoWGD+oAhwgGh4UAhYOAOoKP7wyAEYUP640OD+uFABMMjIAVDIKP34eAY4/iBYiFBYAYD+4OhYeFjYAVD8'
    'UJD+cPCAIKBAmJhYmEh42Hiw4P8AAAACAKAAkAKYBcgABQAJAAABESEVIxETMxEjApj+oJiYyMgFyPuQyAU4/CADUAAAAgCg'
    'AJACSAXAAAcACwAAAREjNSMVIxETMxEjAkiQiJCQiIgFwPsYiNAFMPwoA1AAAgCoAJACaAXAAAcACwAAAREjNSMVIxETMxEj'
    'AmiQoJCQoKAFwPsYiNAFMPwoA1AAAgCoAJACmAXIAAcACwAAAREjNSMVIxETMxEjApigsKCgsLAFyPsQgMgFOPwoA0AAAgCg'
    'AJAC4AXIAAcACwAAAREjNSEVIxETIREhAuCY/vCYmAEQ/vAFyPsQgMgFOPwoA0AAAAEAaP9oB5gCGAATAAATIRUhFSEVIRUh'
    'FSE1IREzESERIcgGcP0YAmj9mANI+NABUKABWP0YAhiIiIiIkJABGP7oAZgABANI/0AHcAZ4ABEAHgAkACoAAAEXBgchFRQG'
    'Byc2NyEHBgcnEgUzERQGIyIvARYzMjUBEhMHAgMlFwIDJxIEeJAgMAK4WDCAQCD9wEgoUIDYARCgSHBwaCCAeBgBsGAgoBhg'
    '/ciQKJCYmAZ4MIiAiAjIUFhoWLhYeGgBYND76HBYEKAYSAL4/rj+sDABaAE4KCj+oP7YUAEwAAUDoP9IB1gGeAALAA8AEwAX'
    'ABsAAAERIzUhFSMRIREzEQEhESEBMxEjASERIQEzESMHWJj9cJABkJj+aAEA/wABmPj4/mgBAP8AAZj4+AUI+kCYmAXAAXD+'
    'kP24Abj+SAG4+/gBwP5AAcAAAAEAaP+AA6AGeAAcAAABAgcnABMhNSERIzUzETMRIRUhESEVIQYHFhcHJgIIYMCAASAo/tgB'
    'KPj4oAEA/wABGP7gCBjAuHiAAYD+0NBgAUgBuJgBSJgBIP7gmP64mGBgmMB4mAAFAQj/SAbwAtgABwALAA8AEwAXAAABESM1'
    'IRUjERMhNSkBFSE1ASE1IQUhNSEG8KD7WKCgAgD+AAKoAgD7WAIA/gACqAIA/gAC2PxwcHADkP64sLCw/hCwsLAAAAUDIP+Q'
    'B5AGYAAPABQAHgAkACoAAAEXBgcSBQcmJxUhNQYHJwADISYnBgEhEhMXAgMhFSEBFhcHJicHFhMHAicFIKAQGPABCFhIQP1I'
    'QDhgAWBgAnigsJD+sAJAgEioYHABIPwAAeBAIKAQQKBgGJAgWAZgMCgo/sCooDA4eGgwMJABMP7IkPDo+8ABYAFYOP6Q/vCg'
    'A0Dg6Cj42BD4/vgoARjwAAACAEj/WAMwBoAAEAAZAAABFwYHIRUUBgcnNjchAgcnEhczETY3FwYHJwFImBAgAYBYQIBQKP74'
    'WHhwqGigkHggoOBIBoAoeHCQEPBoSIiY/tC4eAE4yPxQWFiggGhQAAADAFD/UAPgBogAHQAjACkAABMhNjcXBgczFSMRMxUj'
    'ESMRIwIHJzYTIzUzNjURIwERIxEUBwMWFwcmJ5gBsGBQmFBY0JC4uJjgINBwqCCgqAiQAfjQCIhoSJBAaAUQsMgwuJCY/kiY'
    '/TAC0P4Y8HjAAaCYQEgBMP5IAbj+wEA4A7hwiECIcAAAAwBQ/0ADOAZIAAUACwASAAABFwIFJyQBFwIFJyQBFwYAByckAnCQ'
    '+P6oWAEoAQCI+P6wYAEoASCQmP7o2GABUAZISP7oqIiA/vBQ/tiwkIj+4FDg/viQkMgABAKo/0AHoAYQAAMAFQAbACEAAAEh'
    'FSEDIRUhERQGIyIvARYzMjY1ESEFEhMHAgMlFwIHJxIDkANg/KB4BGD+GGi4QDggUEhAOP4wA3ioaJhgqP3AkIiggKgGEJj+'
    '0Jj8YHBgGKggKCgDgMj+2P6wWAFQAShQSP5Y4HABEAAABQL4/4gHqAZ4AAwAEAAWACAAJgAAARcGBxIFByQBAgUnAAMhFSEF'
    'FhcHAicBIRITFwIDIRUhExYXBwInBRCgEBj4AShg/vj+8ND+8FgBeGACgP2AAQBQIKAgSP64AjiYSLBwiAF4+7iwcCCgKGAG'
    'eDAoKP7YsKCoAVD+wNCQATD+wJBY8PgwAQjw/UABaAFYOP6I/vCYAyjw8DABCOgAAAICiP8wB6gGOAAHACIAAAERIxEhESMR'
    'ATMQAzMRFBYzMjY3FwYHBiMiJjURAgUnNgASBtig/eigAWCYKHAwWIg4CJgQQCjoyGCI/kBQ6AEQYAY4+4gD6PwYBHj+sP44'
    '/wD+CCAgQKgo2EAwQFgBiP6A0IhwAUABmAAAAwCo/9AEQAZ4AB0AIwApAAATMxE2EyM1IREzESEVIRUWFwcmJxEjEQYHJxEh'
    'FSEBFwYHJzYlFhcHJieomLho+AEYkAEQ/vCgeFhgYJBYkFgCaP0AAxCISFhwWP5YUDh4MFAGGPuQyAEYiAJo/ZiISJiYgIBw'
    '/hgCIOCwcP7IkAZIMPCoQMioqMg4wLgAAAIC8P9QB1gGeAAOABIAAAEWFyERIRADJzYTESEmJwMhESEFYFAoAYD86NCAqAgB'
    'kChAgAJw/ZAGeJCw/SD+CP7wePABiAL4kID8qAGwAAUCyP9IB0gGeAALAA8AEwAXABsAAAERIzUhFSMRIREzEQEhESkBESER'
    'ASERKQERIREHSJj8sJgB+Jj+CAFg/qAB+AFY/LABYP6gAfgBWAUI+kCYmAXAAXD+kP24Abj+SAG4+/gBwP5AAcAAAAMCUP9A'
    'B6AGOAASACMAKAAAAREUOwEVISImNREhAgYHJz4BEQMjNSECBRYFByQnBgUnJDcmBTY3IRYGaEDg/vBYWP5oEICQaIhoYEgE'
    'CCj+wNgBOFD+oPDw/pBQAWDQ0AFg6Dj9oIAGOP4gWIhQWAGA/uj4UHhY2AFQ/FCQ/mjwgCCgQKCYWJhIeMh4sPD4AAIAiP94'
    'A8gGeAAVACQAAAEXBgcVMxUjFSE1IzUzNSM1IREhETYBFwQFJzY3ESE1IRUhETYBuICIgNDQAfjY2NABaPzYsAJoGP5Y/rBI'
    'wJj+0ALw/tiwBnh4WCi4kNjYkMiQ/LADEDD6uJCAQJggIAFwkJD+uCgAAAcCCABgB5AGeAAJABMAFwAtADMANwA7AAABFhcz'
    'FSE1MyYnARUQByc2GQEhEQMjETMlFwYHMxUhFTMVIxEjESE1ITUhNSE2JxYXByYnASERITczESMGUCgQ8P2A+Bgg/Xi4cJgC'
    'GJD4+AKAmDg4wP74+PiQ/wABAP7gAWhA6DgoeCA4/hgBiP54kGhoBnhQaJCQUDj9uBD+KPh40AHYAdj96AGQ/viYMJBwkNiQ'
    '/mgBmJDYkJCQYHg4cGj+YP1wiAGAAAAEA1j/SAdQBjAADgASABgAHAAAASERFAYjIi8BFjMyNREhByEVIQURIRUjERMhESED'
    'iAPIYGBIcCBwSED82DACwP1AAoj+SJiYASD+4AYw+fhwcAigCHAFQNCQ0P2IYALY/iABUAADAsj/UAeYBngABQAsADIAAAEW'
    'FwcmJwUhETMRIRUhERc2NxcGBxYXByYDERQGIyIvARYzMjURAgcnABMRIRcWFwcmJwZgYDiIMFD9IAHYmAHQ/jAoeFiQiIC4'
    '4GjoyFiAcGAgaHBYwPBwAVjI/iiYcEiIQHgGeGhwSHBo+AE4/siQ/ngomLBY4IjwuJDQARj98HBgGKAgYAHg/uDAgAEgAVAB'
    'cICYsFCooAAABAKw/0AHoAZ4AAMACQAPABcAAAEzESMBEhMHAgMlFwIDJxIBFwIABSckAAUAqKgBiKhwkGCo/eCYUICYiAMA'
    'oKD+AP5YSAGIAcgGePtIA+j+8P7IUAEwARhAOP5Y/thgATD+yDj+qP5geJhoAXAAAAEDOAD4B6gGeAAoAAABMzUzFSERFBYz'
    'MhMXAgYjIiYZASMUBxYXByYnAgcnNhMmJzcWFzY1IwOI8JgBcCAgQCCIGHBgaGjgGGhgaEBIUNhwyEhwgGhYUBDwBYjw8P2Y'
    'uLgBGCD/AKDQAUgB0NCoYGCAUED+4LBwqAEwYFBwOEB4kAAHAGj/SASYBkgACwAPABMAJAAoAC4ANAAAEyERIRchFSE1ISch'
    'EyE1IREhNSEDIREhERQGIyIvARYzMjURITchNSEDFwYHJzYlFhcHJifIA3D+eCAByPvQAcAg/sCYAkj9uAJI/biYA3D+qFCA'
    'SEAYUFA4/oCQAlD9sDCYWHCIgAKwaEiIQGAGSP3YaIiIaAFQWP7YWP3Y/nD+uGBQIIggQAEweKD+sDDAgEiYcGB4SHBoAAAF'
    'Auj/QAegBngADwAVABsAMwA4AAABITUzFSEVIRUhFSE1ITUhExcGByc2JRYXByYnBRcGByEVBgcWFwckJwYFJyQ3JicGByck'
    'ATY3IRYDiAGAoAF4/ogB2PvAAcj+gKh4gMhouAJ4yKBwmLj+wKAoOAIgYKDA8Ej+8Njg/thoASDAcFBgcGgBIAFYgFD+SGgF'
    'yLCwkLCQkLD+sECwoHCIeGCAeIhgKCBgWHjIkHBAkEiQmEiYOHhYiGhQeNj+4GiAiAAAAgNY/5gHmAZ4AAUAGQAAARYXByYn'
    'ASEVIREhFSERIRUhNSERITUhESEFIHhIkEhw/tAECP5IAYj+eAHg+8ABwP6IAXj+UAZ4cIBYgHj+0Jj+SJj+IJiYAeCYAbgA'
    'AAcCwP9oB5gGgAATABkALQAxADUAOQA9AAABISYnNxYXIRUjBgchFSE1ISYnIwU2NyEWFwUhESEVIRUhFSEVITUhNSE1ITUh'
    'EyE1KQEVITUBITUpARUhNQMIAcgQIJAoGAH4mCgoARj7SAEoKDCoAtgoGP44MCD+kAQA/kAB8P4QAiD7KAIg/igB2P5YmAEQ'
    '/vABqAEw/SgBEP7wAagBMAXgQDgoSFiIUECQkEhIkEhISEj4/ZB4gHiIiHiAeAFweHh4/qBwcHAAAwJI/2gHmAZ4AA8AFQAy'
    'AAABMxMzAyEVIQoBByc2EhMjARYXByYnARcCBxEUFjMyNzY3Fw4BIyImPQEGByc2NxEzETYDKPAQoBACoP1QIODYiMjQKOAD'
    'CGBAiDhgAQiAqOhISIgYGAigCGjwuHCAaGioqJioBPABiP54mP44/fjIaKgB6AGgAfhoeFB4aP2oSP6w4P74GCAgKMAw8HBA'
    'UKB4SIh4sAJo/kDAAAUCyP9IB5AGeAAFAAsAEQAXADcAAAEXBAUnIAUXBgcnNiUWFwcmJyUWFwcmJxMGByc2NxcHIRUhFSEV'
    'IREhETMRIzUhETMRIREhNSE1BwhQ/kj9iDACCAHQkFhokHj+qEAYkCA4/thQOIgwUNA4QIiYSJAgA0D+KAIQ/fABOJiY/GCY'
    'ATj96AIYBniIaBCQcDDomFCweICYKJiACGB4SHBg/hhYUFiYyDBYiNCQ/oABKP34UAG4/tgBgJDQAAACBAD/UAeoBhgAEAAV'
    'AAABIQIDFhcHJicCByc2EwIDIzMSExITBDADKDDwiOho2Iio4Fj4kLBIYPA4iKAoBhj9YP4Y2OiA0ND/AJCAsAEAAXACgP4A'
    '/sABgAHAAAIAaABAA+gF6AADABkAABMhFSEDIRUhAgc2JSYnNxYTByYnBAUnNhMhuAKo/VhAAyj+oIig8AEIMEiQgECQEAj+'
    'wP6YMLB4/ugF6JD+wJj+MNAYWJiIKOj+4CgwMGggkPABwAABAJD/SAcAAYAAEwAAEyEQBiMiLwEWMzI2NyECBSckNyG4Bkho'
    'oIC4GLiAUDAI/RhY/dhwAeBo/eABgP54qCCYIEjA/tiAiFjIAAYAeAGwB4gGgAAPABwALQAxADUAOQAAARYXITY3FwYHIRUh'
    'NSEmJwEzERQGIyIvARYzMjUBERQGIyIvARYzMj0BIRUjERchNSERITUhATMRIwKAWEAByEgwqDA4AfD48AHoKDgEWJhQYGBY'
    'IGBgMP3QWGA4SCBoMCj+EKCgAfD+EAHw/hADOJCQBoBYcGBoMFBIkJBAOP7A/ZB4WBCgGGACMP2YWFgQiBBIKPADEOBQ/uhQ'
    'ATj90AADA6D/UAeQBngAFwAhACcAAAERIxEhESMRITY3IQcGByc2ExcHIRUUBwMzEA4BByckEjUTFhcHJicHWJj+QKABWEgo'
    '/vhwOGBo6GioQAFoaNCYUPjoYAEQ6OiIiHh4oARI/HgC+P0IA4h4eJBAUHjQARgoiIAo2P8A/jjw6EiAWAEY4P7AgKh4oKgA'
    'AAMAkP9ABMAGeAAVABsAIQAAATMRIRUhESEVIQIFJyQTITUhESE1IQEXBgcnNiUWFwcmJwJIoAGw/lAB2P4YMP7oiAEAMP5Y'
    'Abj+cAGQAaiYQFCQWP14aEiYQGAGeP2YmP6wmP6Y6GjYARCYAVCYAhA48KhQwLCowEjQoAABAwj/SAeYBngAMgAAASE1ISYn'
    'NxYXIRUhAgckJSYnNxITByYnBxEUFjMyNhMXDgIjIiY1EQYHAgUnJBMHJzYEoP7AAbggMKA4IAG4/diQkAEAASBASICwcJAg'
    'MHgoSEggCKgIKFCYqGhAQDD+sGgBGDjYKMAE+JBoWDBoiJD+uIgYQHhwUP74/thQaGgg/UAgGEgBGDD4kDhIUALYEAj9iPiI'
    'yAIQEICoAAQDUP9IB5gGeAAXACgALAAwAAABITUzFSEVIRUhFSEVIRUhNSE1ITUhNSEBERQGIyIvARYzMj0BIREjERMhNSER'
    'ITUhA4gBkJgBuP5IAYD+gAHo+7gByP64AUj+cAOYYGA4SChwOCj90JiYAjD90AIw/dAGAHh4iIiAgIiIgICI/XD9IGBgEJgQ'
    'UDj+4AOg/wCA/oCAAAIAsP9IBJgGIAAQACQAAAERFAYjIi8BFjMyNREhESMRARcCBxYXByYnBgcnNjcmJzcWFzYEmGhgMEAo'
    'YDAw/VigAnCQSFhoUJAwQFhgiIBgaICAYFBABiD58GBgEJgQUAVQ+cAG2P7IMP8A2MDQQJiIuJhYyOjIuDiAkKgAAAMAYP9A'
    'BIAGEAAHABIAGAAAAREjESERIxEBMxAHAgAHJzYaARMWFwcmJwQ4oP3ooAFomBAg/vjoYMDYUPi4iHCIwAYQ+6gDwPwYBID+'
    '6P24gP8A/oh4gGABGAFo/pCowHjYsAACAhD/SAewBngAGgAgAAABITY1ESE1IREzESERMxUhEgUHAAMCAScAEyElESERFAcC'
    'aAH4CP5wAZCgAdC4/cC4Aah4/mDIiP5YkAHAcP4oA9D+0AgC6DgwAUiYAUj+uP24mP5w4JgBCAGo/mD+8HABIAF4mAGw/rg4'
    'MAAABAI4/0gHoAaAAD4ARABJAE4AAAEXBgchFQYHIREhBxYXNjcXBgcSFwcmAwcWFRQGIyIvARYzMjY1NCcEBSckJScGBSck'
    'NyYnBgcnJDchEQcnJAchNjchBgMhNjcpAQYHITUEGJAgKAHYODgBYP2oKHhA2JiAUHBQwHjIWHgggHhIeCiAaDAwCP7w/ohA'
    'AaABECjo/shQATD4IDCY8GABCKD+yDBYAVAwAbBQMP5gOFgBGDgQ/qACABAoAXAGgCgwMHhIQP4wOGB4aJBoSED+mJCIoAGQ'
    'OHiIqKgQoBhgWDgo2HCIeNhYsHCIYKAoIHhQiFCIAXAgiLjASDg4/nhYWFhYsAABAGgAGAOoBngAEAAAARcFETY3FwYFJxEH'
    'JzcRMxEDiBD+WOi4GNj+2EjgGPiQBOiQcPzoWGiQgGhIA2hAkEACIP4IAAMDCP9IB5AGSAAFAAsAHAAAARIXBwADJRcCAScS'
    'ARITBycEBScSExcCAyQ3JicGWEjweP7wQP5ooDj+8ID4AjCYYJgw/sD+gCjQuKCwuAEY4DhIBkj96OCIAQgCUCgo/hD+kHgB'
    'SP3Q/sD+gEjIUDCIAXACmED9mP7AMDjIsAAAAwII/2gFCAYoABwAIAAmAAABIzUhCgEjIi8BFjMyNhMjAgUnNhMjNTM2NyM1'
    'MyERIwMTNjUjBgcDUKgCYAhogEBgEGhAICAQuFD/AFDASHiQEBCIiAEokAiICJAIEAWYkPrg/pgYoBiIATj+WPCIuAFYiHjI'
    'iAFI/rj+OKCgwIAAAAEFaP9AB4gGGAAWAAABFQMSFRQGIyIvARYzMjY1NAMTIREjEQeAoKhocEAoEEA4KCiwqP8AkAYYiP3w'
    '/uDokJAIkBBQUMgBOAIQ+bAG2AAABAAo/0gEgAZ4ACAAIwAnACsAABMhNTMVITY3FwYHIRUhByERIzUhFSMRBgcnNjchNSE1'
    'IQU3IwMhNSERITUhuAEomAEoMCCAeLgBQP4w4AJYmP4wmGBIWNDQ/qABeP7YAcC4uLgB0P4wAdD+MAWo0NA4QEjI0JDA/FiI'
    'iAMoQChwgLiQ2MjI/IjA/fjAAAUAeP9IBIAGgAAJABMAGQAhACUAABMhJic3FhchFSEFFwYHIRUhNSE2JRYXByYnAREjNSEV'
    'IxETIREhqAFwGDCQQCABePxwAqigQEABEPv4AlBQ/oBAKJAgSAMImP3omJgCGP3oBbhYSChYcJBAKMCQkJC4uHiYMJiA/WD9'
    'MFBQAtD+EAFgAAAFAqD/UAeYBngACQANABEAGQAdAAABISYnNxYXIRUhFyEVIRUhFSEFESM1IRUjERMhESECoAI4KDCoQCgC'
    'CPsIaAQg++AEIPvgBBCg/UCgoALA/UAFkGBQOGiAmKCQoJCg/WBgaAKo/lABIAACAkj/SAewBjgAGQAdAAABIREhFSEVIRIF'
    'ByQDESMRAgUnJBMhNSE1ITchESEDEAPI/nACKP4g0AFQUP7A2KDI/tBoAVDA/iACMP5ooAKQ/XAGOP2Q2JD+qKigwAFI/YAC'
    'gP6wyIjQAViQ2JABUAAABQLQ/0gHOAaAABQAGAAcACIAKAAAATMRIREUBiMiLwEWMzI9ASERIxEhASE1IREhNSEDFhcHJicl'
    'FwYHJzYEwJgB4GhwYJAgsFhQ/OiQAcD+0AMY/OgDGPzoQHBoeGCAA9CYYHiIiAaA/hj7cGBgEJgQUPD+KAVQ/pDo/aDoA8Bw'
    'oGCQiFgwwIhQmAADAhD/SAUwBggABwASABgAAAERIxEhESMRATMQBwYCByc2GgETFhcHJicFCJj+cJgBGJggKMCAYHioMOiQ'
    'WIhQiAYI+zAESPuwBNj+yP2YsOD+yFh4WAEQAVj+gKi4ULiwAAMCYP9IB1gGeAAdACMAKQAAASE2EzMCByEQAgYjIi8BFjMy'
    'NzYRIQIAByc2EhMhARYXByYnARYXByYnApgByBgIoAgYAlg4kJiAgCiYkGgYKP5QKP8A2JDQ+Cj+SAEQUCiYKFACcHBIkEBo'
    'BFjwATD+0PD9QP5IiBCwEGC4AqD+YP3owHiwAegBaAJ4mLgwwJj8yKi4ULigAAAIAsj/OAeQBngAGwAfACMAJwArAC8ANQA7'
    'AAABMzUzFSE1MxUzFSMVIRUhFSERIREhNSE1ITUjBSE1IQMhNSkBFSE1ASE1KQEVITUBFwYFJzYlFhcHJicDMOCYATCY4OAB'
    'IP3wAaj8IAGo/fgBKOABeAEw/tDQARj+6AGoARD9SAEY/ugBqAEQ/chokP7YQOgCUMjAWMDIBciwsLCwiLiIgP0YAuiAiLi4'
    'uP0IsLCw/iioqKj+qHBoUJAwaDhwkIhAAAIDEP9IB2gGcAAOACgAAAEXByEVBgcnNjchAgcnABMXBgcVIRUhESERITUhNSE1'
    'IREjNSEVIxE2BLigQAIQaJiAgFD+WJDAcAEQuIiosAEg/uACyP7gASD+0AHImP04mNgGcDCQiPDIWLCo/viocAEI/rCAWCDY'
    'kP74AQiQ0Jj8GFhYA8AwAAAFAvD/QAewBngAFAAaACoAMAA2AAABITUzFSEVIRUhFQYHJzY3ITUhNSETFhcHJicDITYRMxAH'
    'IRUhAgUnJDchExYXByYnARYXByYnA4gBeKgBeP6IAcBIWHhAMPx4Acj+iMh4YGBoaOgCGDiYKAHA/hCQ/ihIAWCY/iiYgHBY'
    'eHgC0OCwaMDYBcC4uIjAgKCAWGhYiMD+eEhoeHhQ/lioAVD+yMCQ/tCggHjYAfBYeGiIWP4gcJiIsHgAAAECMP9IB6AGeAAa'
    'AAABFwYHIREzESEVIREhFSERIxEhNSERIQYHJxIDiJgoOAEYoAHg/iACKP3YoP2IAnj+qFhwiOgGMDCIgAGA/oCY/iiY/VgC'
    'qJgB2MCQaAEwAAADALgAIANIBeAABQAJAA0AAAERIRUjEQERIREVESERA0j+EKAB8P6wAVAF4ProqAXA/bgBsP5QiP5QAbAA'
    'AAMDWP9IB1gGSAAUABgAHQAAAREUBiMiLwEWMzI1ESECAyc2EhkBEyERIREhESEVB1hYWGCQKJhgOP3YMICQaFCYAhj96AIY'
    '/egGSPnoaHAQmBBwAWD+oP7oWPgBiAEoAwD+CAFw/JABcKAAAAECoP+QB6AGcAAeAAABFwYHIREzESEVIREhFSERIRUhNSER'
    'ITUhESEGBycSA5CQGCgBKKAByP44AbD+UAH4+0gCIP5AAcD+qDhQiKgGCDCYgAGw/lCY/kiY/lCYmAGwmAG40JBoAUAAAQB4'
    '/0gHsAYQAB4AAAEWFzYTIScBITUhFQYHIQIDFgUhByEgJwYHJzY3JgMBMDhQUDD+wBABIP54AkCQgAEgGJiYAqACWDj94P1Q'
    '4GiQWIhgeEACmMCAsAFAiAGgoJjouP4Q/ui4CKDYkHCAcIigAQAAAwCo/5ADOAZ4AA0AEQAVAAABESM1IRUjETM2NxcGBxMR'
    'IREVESERAziQ/pCQsCgQqCAouP6QAXAFcPpYQHgF4ICIIIBo/ZgB0P4wmP4wAdAAAAUAgP9IA5AGgAAPABMAFwAbAB8AAAER'
    'IzUjESMRIxUjESERMxEBMxEjIREzEQEzESMBMxEjA5CQqJiomAFAmP7AqKgBQKj+GKioAUCoqAVQ/ABg/ZgCaGAEAAEw/tD+'
    'eAEA/wABAP1wAQD/AAEAAAABA2j/SAdgBjAAIgAAASMnJBMhNSEVAAUhEAIjIi8BFjMyNzYTIwIBJwATIwIBJwAEyNhAAYDw'
    '/dADEP74/uACiGCASGgIYEAwCCAISFD+eHgBcEiQSP7QeAEYAyCI4AEYkIj+0Mj8uP7oEJgQUOACCP2o/oCAAVACCP5g/shw'
    'ARgAAQKg/0gHWAY4ACIAAAEhJyQBITUhFQAFIQoBIyIvARYzMjc2ESMCAScAEyMCAScABFj+4EAByAEg/VgDoP7I/pgDIAho'
    'mFh4CHhQOBAoaGj+IHgBwGCwaP6AcAFgAyCI4AEQoJD+0Mj8uP7oEJgQWOgB+P2g/oiAAUgCEP5Y/tBwARgABAJQ/0gHsAZ4'
    'ACcAKwAvADMAAAEhNTMVITUzFSEVIRUzESEHIRUhFgUHJAMCBSckNyE1ITY3IREzNSEFITUhAyE1IREhNSECoAFAmAFAmAFA'
    '/sDQ/kAgAlj+EJgBcFj+WKiY/iBAAaBw/igCGBgI/lDQ/sAB2AFA/sDQAuD9IALg/SAF4JiYmJiQmP1wkJDQUKB4ATj+sFiI'
    'YNCQQFACkJiYmP5ggP6AgAACAvj/cAeoBegADwAbAAABBgUnJBMhNSEVBgcWFwckBSEVIREhFSE1IREhBWDY/uhoAkDg/UAD'
    'eFio8NhI/wD9KAOo/mgB2PuIAgD+kAOIoEiYgAGgkHjYqFBwmJDgkP5IkJABuAADAHD/SAVQBngAHgAsAEIAAAEXBgcVIRUh'
    'EQQXByYnESMRAgcnJBMRITUhNQYHJyABMxEjNQYHJzY3NSM1MyUzFTY3FwYHFRQzMjY3FwYHBiMiJjUEiFDI+AII/fgBGOBo'
    'wNCYwPhYAUDQ/hAB8LDIMAHY/uCIiGiAGJho6OgB8IiAYGCIuEBQIAiQECggsIBIBniIKBiYkP2gsOiA0KD9yAH4/wB4kKAB'
    'OAJYkJAQCJD+GP2oaDgwkDA4iIhQoDhQcGhAaDgocCioMCBAWAAABwJo/0AHkAU4AB0AIQAlACkALQBCAEgAAAEhNTMVISYn'
    'NxYXMxUhFSERIzUhFSM1IRUjESE1IQE1IRUnIRUhBTUhFSUVITUBITUzFSEVIRUUBiMiLwEWMzI9ASEFFhcHJicCcAI4mAEo'
    'GCB4QDBo/cAB4Jj+uJj+uJgB4P3IBBj+uJj+uAFIAeD+uP4gAUj9wANwmAEg/uBQkHhgGHh4SPyQAUBgQIg4YASoUFAoIEhA'
    'UHhg/dhIYGBIAihg/uBQUFBQuFBQUFBQ/phgYIDAaFgYmCBIqChYaEhgWAAAAwQw/zgHiAZ4ABYAGgAeAAABIREzESERIRE3'
    'JzcWEwcnBAUnNjcRISURIxEjESMRBFgBMJgBMP7QkECAWECQIP7Y/qAguKD+0AJooJioBQABeP6I/ND+eCDQOOj+8ECoSDiY'
    'GCABoJACEP3wAhD98AAABgNI/0gHgAYwAAMABwALABwAIgAwAAABIRUhFyERITchNSEBERQGIyIvARYzMjURIREjEQUWFwcm'
    'JyUXBgczFSMRIxEjNSE2A0gEOPvIaANo/JiYAjj9yAMwaGhIYCCASDj9CJgBiDgYiBgwAXCQICiI8JDoAVAoBjCQaP5oiIj+'
    'gPzQYFgQkBBIAoD8qAPo0EhgKFhQKChwWIj+sAFQiHAAAgLQADgFGAZ4ABEAFQAAATMRMxEzFSMRMxEhFSMRMxEjEzMRIwLQ'
    '2JjY2KD+oIiw2LDY2AUoAVD+sJD+sP1oeAMQAVD8qAF4AAAFAID/QAeIA0AACAAMABAAGAAcAAATISYnNxchFSEXIRUhFSEV'
    'IQURIzUhFSMRFyE1IYADQAgQmCADKPj4sAWg+mAFmPpoBaiQ+3CYmASQ+3ACyCggMHh4SGhIaEj+mDAwAWjIWAACA8D/MAeg'
    'BnAAGwApAAABFhchFSEGBzY3NjcXAgEnJBMGByc2NyE1ISYnARcCBxYXByYnBgUnJAAFsFgwAVj+MGCIqIA4KJjg/ihYASCw'
    'uMggkGj+wAGwMEAB+JCImKCIeIiQ4P7gUAFAAXAGcHiImOCQEBhogED9sP8AgKABCCgYkJjgmHBg/OBI/ujAgKCQsIjQiIiY'
    'AYAABgJQ/0gHYAYwAAsAEQAVACYAKgAuAAABETMRIzUhFSMRMxEBMxEhFSEFMzUjAREUBiMiLwEWMzI9ASERIxETITUhESE1'
    'IQaouJD8EJCwAiDw/ZABgP6A8PAC8GBgUHAgkEgw/ciYmAI4/cgCOP3IBjD+CP7wgIABEAH4/ggBcHj4eP6A/NhgWBCICEhY'
    '/sgD6P7okP5giAABAEj/SAPYBngAGQAAARcEBRUhFSERIRUhESQ3FwQFESMRByc3ESQDYHj++P7AAeD+IAHg/iABIPgY/wD+'
    '0KBwOKgBcAZ4gEgg8JD/AJD+2Cg4iEg4/pgBSBCgGATQKAAFAgj/QAe4BjgAHwAjACcAKwAxAAABIRUhFSERIQYHBAUHJCUG'
    'BSckNyYnNxYXNjchESE1IRMhNSkBFSE1ASE1KQEVFAchNQKIBPD90AHg/ggYUAEgAdAw/ij+oLj+sEABGJiYaGB4oEgg/jAB'
    '4P3g2AFI/rgB6AFI/NABSP64AegIAVAGOJC4/PDAgIAIqAigoDigMGBocICIWGCYAxC4/gi4uLj+CLBYMCiwAAAGAkj/cAeQ'
    'BngADQARABUAGQAdACEAAAERIxEhESMRISYnNxYXASEVIQchESETITUhESE1IQEhFSEHYJj8UJgCCCAwoEAo/jgC8P0QcAPg'
    '/CCgAqD9YAKg/WD+oAVI+rgFuP5oAQj++AGYUEAwWGj+6IiI/QABwLj+ELD+QJgAAAQCMP9IB4gGUAADAAcACwAoAAABIREh'
    'EyE1IREhNSEDFwYHFhcRITUhFSEVIRUhFRY7AQcjICQnBgcnAANAA6D8YJgCcP2QAnD9kHiQEDBouP3oBJD+IAF4/oiQyMgw'
    'mP6Y/pB4UHh4AQgGUP0gAbiY/kCY/ZAgiHiQQAIgkJDYkNgYoIiIqIBwARgACAOI/0gHcAY4AAMABwALABMAFwAbAB8AIwAA'
    'ASEVIRchESE3ITUhAREjNSEVIxETITUpARUhNQEhNSEFITUhA4gD4PwgQANg/KCYAjD90AMQmP1ImJgBEP7wAaABGP1IARD+'
    '8AGgARj+6AY4kJD+OIi4/jD8iGhoA3j+sMDAwP4IuLi4AAAFAoD/SAeYBoAACwAfACcALQAzAAABMxUhFSEVIzUhNSEFMxUz'
    'FSMVIzUhFSM1IzUzNTMVIRMRIxEhESMRATMCBSckNwQXByYnBOCYAaD+YJj+YAGgATCQ+PiQ/liQ+PiQAaj4mP1wmAGYoBD9'
    'aFgCUNgBANBw0PAGgJiQwMCQ+JiQkJCQkJCQkP6w/YgB6P4QAoD/AP2AQIgguGCAeIhYAAAFAjj/SAd4BogACQANABEAGQAq'
    'AAABISYnNxYXIRUhFyERITchNSEBESM1IRUjERMhFSERFAYjIi8BFjMyNREhAmgCABggmDgYAiD7MGAEKPvYmAL4/QgEGJj7'
    '8JjQA6D+kEh4gHggkIgw/mAF6EAwMEhYkFj+aICQ/pD+ePjoAXj+6Ij+qHBYGKAgSAFAAAADADj/SATYBjAACQANACYAAAEV'
    'EAMnEhkBIREBFSE1ExEUBiMiLwEWMzI1ESMRIxEjESMRITUzFQGw6JDYA6j8+AJowGhgGCAoQBgwkKCQoAEwoAQYsP4Q/jho'
    'AXAB4ALI/egBgOjo/Zj9iGBgCJgIUAG4/LADUP1QA0iwsAACAGj/SATABngAKwAwAAABFwYHMzUzFSEVIRUhFSEVIREUBiMi'
    'LwEWMzI1ESERIxEjESMRITUhNTMnNgE1IwYHAUiIEBiooAGA/oAB0P4wAaBoYDhQIGg4MP8AoPCgAZD+GFhYmAFQ4DBABlAo'
    'QEDQ0JjYmND9yGBYCJAISAGA/RAC8P2wAujQmEjI/vDYeGAAAAQCeAC4B2gGeAAXABsAHwAjAAABFhchNjcXBgchFSEHIREh'
    'ESE3ITUhJicTITUhESE1IREhNSEDwFhAARBIMLAwQAFI/cAoAfj7+AFoKP34ATAwOEAC4P0gAuD9IALg/SAGeGhwaHAwYEiQ'
    'gPwoA9iAkEhA/UiY/lCY/lCYAAEDGP9QB5gGUAAUAAABFwQFESEVIREjESEQAgcnNhIZASQHSFD+oP4oAzj++JD+YGBogGBQ'
    'AigGUIhIIP6QiPv4BAj+IP5ooGiQAagCKAHIKAAEA6j/SAdIBhgABwALAA8AEwAAAREjNSEVIxETIREhESERIREhESEHSJj9'
    'kJiYAnD9kAJw/ZACcP2QBhj5MLCwBtD+KAFI/OABSPzYAVAAAAUByP9IB6gGgAAFAC8AMwA3ADsAAAEWFwcmJwUVIRIXFTYT'
    'FwIDEjMyNjUXDgEjIgMGByc2NwIDIREQAyc2EhkBIQMzEwEhFSEXIREhNzMRIwa4WDiIMFgBOP6YECBYQIhokEhAGBiQGFhQ'
    'kGCAwFDoeEgQ/ZCokFhAAwgImAj9UAHQ/jAQAcD+QIiwsAaAUGBIWFDQkP5o6AjIARAw/mj++P6ogIAY+KABWLiYeMDgAUgC'
    'IP3I/ij+kFjYAVABAAKQARj+6P7gkJj92IgBGAACAngAiAeIBigAAwAgAAABIRUhAyEVIREUMxYzMjY3Fw4BISImNREjEAIH'
    'JzYSESEDCAPg/CBwBLj+iBgIEKg4CJgIcP74gFDIuPBQuKD+yAYomP7gmP2oMAg4kDDIYEBYAoj+iP6YcJBQATgBOAAABAJw'
    'AFAHiAaAABgAHAAgACYAAAEhNTMVIRUhFSERIREjEQIFJyQ3IREhNSETITUpARUhNQMWFwcmJwKoAhCYAhj96AHI/jiYuP7g'
    'cAEYoP7IAcj98NgBOP7IAdABMJDguHCw2AXgoKCQoP3o/bgCKP7gqJCI0AIYoP3Y+Pj4/jB4oHiocAADAEj/SAPQBngAHgAi'
    'ACYAABMhNTMVIRUhFSERIRUWFwcmJxEjEQIHJzYTIREhNSETMxEjIREzEYgBYJgBUP6wATj+yMCIaHBwmJCgcNCg/vABQP6g'
    'wKCgATigBbDIyJDI/dBAiIiQiGj+EAIg/vigeLgBOAIwyP2YARD+8AEQAAMCuP9IB5AGeAAXABsAHwAAATMVIRUhFSERIRUh'
    'FSERIxEhNSE1IREhAyE1IREhNSEEoJACKP3YAdj+aAIg/eCY/eACIP5gAWjQAqD9YAKg/WAGeIiQoP0YqJD+qAFYkKgC6P7I'
    'sP4oqAACAsD/SAeYBoAADwAfAAABIREzESMRITUhESE1IREpAREhFSERIRUhESMRMxEhFQLYATCYmP64AUj+4AEg/tADUAEg'
    '/uABcP6QmJgBQAU4AUj4yAGIkAFgkAFY/qiQ/qCQ/ngHOP64kAAAAgCQAkgHiAaAACMANwAAATMVIRUhFTY3FwYHFSM1Bgcn'
    'JTUhJzY3IzUzNxcHIRUhBgczARcGBRUhFSMRIxEjAgcnPgERNSQCUJABIP7gqJAYoLCQ0NgYAcD+iCBYQLD4QJgwAej92DhI'
    '0ATIUPj+uAJg0KDwEOB4cGgBiAUgkICIEBiAIBCYgBgQkCiYiFhwgKAggIBwYAGwiEAYoIj+MAHQ/qCQYEjoARjwIAAAAgHo'
    '/0gHkAZ4ACUAOgAAATM2NxcGByEVIQIHMxEzETMVIxU2NxcGBxEjEQYHJyU1ISc2EyMBFwYFESEVIxEjESMQAgcnNhIZASQC'
    'KNggGIgYIAFA/qBYcPCIoKBYUBhgYIjAoEgBqP6QIHhgsAUQUND+8AHoiJjIUGCAUEgBWAWAeIAYeGiA/uDYATj+yICoGBCI'
    'GBD+AAHgKBiISMCI0AEgAViISCj+kIj7+AQI/iD+aKhomAGgAigB0CgAAAQB+P9QB5gGgAAPABoALwA1AAABFhchFSEREAMn'
    'EhkBISYnAwYHJxITFwYHESMTIREzETMVIxEUBiMiLwEWMzI1ESEXFhcHJicFGEggAhj7iJiQkAJQKDiYKDBIuFCQKDiY0AGo'
    'mKioWIBwWCB4cED+WLhIOJAwSAaAcIiQ/bj+EP6QWAGAAcACoHBY+/hAQJABKAFIMIiI+8gEWAEQ/vCQ/QBwWBCgGEgC6ICY'
    'sEC4kAAGAkD/QAeYBngADQATABkAKAAuADQAAAEzEAcEBQckJQYFJyQSJRcGByc2JRcGByc2ATMRFAcSBQckAwIFJyQRJRcG'
    'Byc2JRcGByc2BNigOAFAAQhw/wD+4ID+iGgBYOAB4JhQcJhw/PCYQECgWAGAsBD4AVhQ/pDYqP5IYAJoAfiYWHiYiPzwqEBI'
    'qFgGeP7gsIi4iLiIsJCAcAFI6DDIqFCYqCjQkDCw/fj+wDgw/siAoKABGP74sJDgAVC4MOiYULiQKNiQMLAABgLQ/0gHoAZw'
    'AAUAGwAfACMAJwArAAABFhcHJiclFwYHIREhFSEVIREjESE1ITUhESE2ASE1KQEVITUBITUpARUhNQQ4WECYOFACWLBAYAEY'
    '/lgCGP3omP3gAiD+WAIYcP4QARD+8AGoARj9QAEQ/vABqAEYBnBgeEB4YEAomID8yLCQ/pABcJCwAzig/gjIyMj96MjIyAAE'
    'AyD/SAeoBoAAIAAkACgALAAABRUjEQYHJzYTFwYHFSEmJzcWFyEVIREhFSERIRUhESEVAREhEQERIREBESERBHigMDhQ2GCg'
    'OEgBQDBImFg4ATD+mAE4/sgBOP7IAXj80AEg/uABIP7gASAwiAUAODiQ+AEgOIiAEJh4OJiwmP74iP7wkP74kATI/vgBCP5w'
    '/vABEP5g/vgBCAABAID/SAeAAggACwAAATMVIRUhESMRITUhA7iYAzD80Jj8yAM4AgiokP54AYiQAAAEAJj/SAdoBPAADQAZ'
    'AB0AIQAAARYXIREjNSEVIxEhJicBESEVIREjNSEVIxETITUhESE1IQQAOCADEKD6cKADEBgoAwD7qATIoPvYoKADuPxIBCj7'
    '2ATwQFD+0KiwATg4MP6g/mBo/fhQYAQg/uiQ/VCoAAUC+P9YB6AGeAAJABoAHgAkACoAAAEhJic3FhchFSEXIREhERQGIyIv'
    'ARYzMjURITchESEDFwIHJzYlFhcHJicDSAHAGDCYQBgByPvQQAOQ/pBQaFhIIFBYOP54mAJg/aAoiICIgKADIJBYmFCIBZho'
    'UChwcJCo/cD9+HBQEJAQUAHokAEg/gBQ/siweNDg0OhY6NgAAAUDGP9IB6gGiAANABEAIgAoAC4AAAERIzUhFSMRISYnNxYX'
    'ASEVIQchFSERFAYjIi8BFjMyNREhHwECByc2JRYXByYnB3iY/RCYAbgYKJg4IP5oAnj9iNgESP4YSIBYSCBgYDD+OLiAcJho'
    'mALgkIiIcKAFmP6A8OgBeGhQOHCA/rCQyJD9qGhYIJAgSAJAcFj/AJCAoLig0IDQyAAABQKw/0AHsAZ4ACIAKAAsADAANgAA'
    'ASERMxQXIRUhEhc2ExcCAxIzMjY1FwIGIyIDBgcnNjcCAyEBFhcHJicBIREhNzMRIwEXBAUnJALgAniYCAGg/mAYKHhgiJCo'
    'UEAYIIgQYFCYaKDQUPiYSBj9gAPgUDCIMEj82AH4/giQ2NgBqBj+2P6QIAGQBUgBMKCQkP5Q8OgBIED+WP74/sCgmBj+6LgB'
    'YMCIkKjQAWgB8AG4WGhIYFj94P3oiAEI/jCIeFioSAAAAwOQ/0AHoAYwAAcAEQAiAAABESMRIREjEQEzEAoBByc2GgEXMxEU'
    'FjMyNjcXBgcGIyImNQcYoP4AoAEwoEjQoGCIuDiomBhAUCAIiBAoIKioSAYw+6gDyPw4BFj+wP1w/pD+sGCAWAEYAWCg/jgg'
    'IDi4KOg4MEBYAAACAmgAgAdgBngAHAAiAAABFwQFFSEVAgcWFwcmJwYFJyQ3JicCAyc2EjURJBM2NyEVFga4YP6I/hgDWHCg'
    'wKBgqNDQ/wBgAQCooLgooHhoSAIYSJBQ/WDwBniQaBjokP8AsIiYkKiQwIiIiJhoaP7Y/wBowAEguAIoEPyQqLBYeAAABAOI'
    '/5AHmAZ4ABYAHAAiACgAAAEhETMRIRUhFRYXByYnESMRAgcnNhMjAzMRIRUhARYXByYnJRcGByc2BHgBKJgBKP7YwJBocHiY'
    'gGiAsHDg8JgDePvwAUBYQIg4UAK4kEhYgGAD2AKg/WCQSJiQiJBw/ggCKP8AiGDYARgCyPoIiAZQmLhAwJg4MNCYSKgAAwLg'
    '/0AHmAaAACoALgAyAAABFhczNjcXBgchESEVIQIGIyIvARYzMjY3IREjEQIFJyQTIRMhNSE1MyYnASE1IQEHITUEkEgokFBA'
    'qEBIAQj+YAHwGGhwUGAgaEgwKAj+wJig/thoASiQ/sA4AYD+eNgoOAGoAQD/AP6AGAEABniQqJioOJB4/gjw/lDQGKAYaOj9'
    'eAJQ/qDIeNABGAIQ2JCQeP2Q2P6Y8PAAAAIDqP+AB4AGeAANACUAAAEWFyERIzUhFSMRISYnAzMRJCUXBAURFBYzMjc2ExcO'
    'AiEiJjUFiFAoAXig/XioAagoQLCgATgBAHD+sP6oOHDwKDAIoAhIkP7wyIAGeICY/oDw8AGAeGj9eP6IeMiA8Hj+wCAgMDAB'
    'ADDwoDhAYAAABQBo/0gHmAToAAUACwAdACIAJgAAARcGBSckJRYXByYnBxcGBwAFBycRIzUhFSMRBycAASEkJQYDIREhAsh4'
    'yP7waAEAAzj40HDY6OCgICgBiAHIYNig/ICg6FACeP8ABDj+0P744MADgPyABOhg2JCQcLiIwIjQmDAwKCj+4JigYP2AYGAC'
    'gHCQASD+6KDQ0P2gATgABABw/1AHkAFIAAUACwARABcAAAEWFwcmJyUXAgcnNiUWFwcmJyUWFwcmJwagkGCYUJj7SJB4eIiQ'
    'A9hwUKhIaP7YcCiwKGgBSMDgWODAQFD/AJB4qKigwEjIoCi4uDjQsAAGAvj/SAdoBngAIwApAC0AMQA2ADoAAAEXBgchFQYH'
    'IREUBiMiLwEWMzI1ESERIxEhAgcnEhkBBgcnJAU2NyEGBxMzNSMhFSE1ATM1IxUlFSE1BHigEBgBsDhAAUBQSEBgIGgwKP7w'
    'mP8AKHiQqBggaAEAAWhIMP7ISDAI8PABiAEQ/Wjw8AGIARAGeCgwOIhoUPtYWFgQmBAwARj+UAGw/ujQWAFQAXgBoBgYePCY'
    'WFiAMP6Q4ODg/ajogIDo6AADAED/SAOABnAAHQAjACkAAAEXBgcRIRUhFRYXByYnESMRBgcnNhMhNSERBgcnJB8BBgcnNiUW'
    'FwcmJwMYYIigATD+0Kh4YGBgoHiIcMig/sgBQHiQWAHY2HhASHhY/ihQMIAwSAZwcEAw/iiQOJiQiJBw/QgCqPiIeMgBeJAB'
    'uCAYiEjAKMiIQKBgeIg4kHAAAAUDOP+AB6AGCAADAAcACwAVABsAAAEhFSEXIREhNyERIQEXBgchFSE1ITYlFhcHJicDUAQo'
    '+9hQA4j8eKACSP24AjCwQHgBOPuYAoCA/fhgQJBAWAYImMj9gJgBUP3YOMjQmJjo2JCYQKCAAAMAcP84B1gDaAArADEANwAA'
    'ASU2NxcABSQlJic3FhcHJicEBREUBiMiLwEWMzI9AQQhJyQlBgcnNjcXBgcBBAUHJC0BFwYFJyQDAAFAgGiA/mD+SAJgAUhI'
    'UIDAuIgoOP8A/vhQkEBAGEhQOP6o/qgYATABKOjoGNiImFB4ArgBCAEAWP8A/vj9cGC4/qBAATgCuBBAUFj+6HAQMEBAWJDA'
    'aDgwGBD+6HBYCKAQSPgYmEiAEAhwQHgwQED+IFCwiLhYWGiQcJBQAAADANABoAMIBggAAwAHAAsAAAERIREBESERFREhEQMI'
    '/cgBoP74AQgGCPuYBGj+EAFo/piI/pgBaAAAAwNIAWAHSAYwABMAFwAbAAABIRAGIyIvARYzMjY3IQIFJyQ3IxMhESE3IREh'
    'A5ADuGiYUHAgeFhAIBD+cDj+yGABADDoKANY/KigAiD94AYw/kiwCJAQcOD+sJCIcOj96P3YiAEYAAADAvD/SAeQBoAAEAAY'
    'ABwAAAEXAgckJSYnNxYTBycEBSckAREjNSEVIxETIREhBLCouLgBKAFIUGCYyIigUP5g/iAwAQgDGKD9iKCgAnj9iAaAMP5Q'
    'sBAwiHhA+P7QSKhIGJjg/dD8uICAA0j90AGYAAADAGj/SARwBngADAASACEAAAECBycAExcGBxYTByYHFhcHJicDFzY3ITUh'
    'FQYHFhcHJiUCcKD4cAE4qJAQGOjYcLDoYDiIMGBw6JBY/ZADIHigaFh48P7YBWD+qOhwAUABqCgwMND++HjgSGh4UHho/VCA'
    'sLiQkPDQSEiI4JAAAAYAYP9IBAAGSAALABEAFQAmACoALgAAAREzESM1IRUjETMRATMRIRUhBTM1IwERFAYjIi8BFjMyPQEh'
    'ESMREyE1IREhNSEDgICI/XCIgAGQiP54AQD/AIiIAehYUDA4IFgoIP7YmJgBKP7YASj+2AZI/gj+6IiIARgB+P4IAXiA+Hj+'
    'cPzQYFgQiAhIWP7IA/D+6Jj+UJAAAQBQ/0gHgAaIAA8AAAEWFyEVIREQAycSGQEhJicEKDggAwD6ELCQqALQGCAGiDhAkP2A'
    '/eD+aFgBqAHgAugoIAAAAgMg/3gHmAZAAAcAGwAAARUhESEVIREBIRUhESEVIREhFSE1IREhNSERIQeY/CgD2PuIAQADAP7Y'
    'ARD+8AFY/LABWP7oARj+yAZAmPpomAbI/qCY/tiQ/tiQkAEokAEoAAACAID/QAd4BNgAGQAgAAATITY3FwYHIRUhAgcEBQcm'
    'JQQFJyQlJCUTKQEGBxYXNhOAAiBYQLBASAQY/nhAsAEwARhw6P6I/rj9yFAB+AEg/wD+2Lj+MAKQSFD46KhAA4CwqBCwmKD+'
    '2MCIkKCYqOhYoEioaHABOIhoWGCgAQgAAAEAUP9IB5ADAAAkAAAlBgcnJDchNSEnNxYXIRUhFhc2NxcGBxYFByQDBgcRNjcX'
    'BAcnAiCgwHABsPj9oALgMJAwIANA/PhIkLBoiICYwAEQWP1AwGCI0Lgo/vD4WJhgSIig0JhQMEBAmIh4aHhggFhgUJjQAchw'
    'aP7oOECAYEBQAAAEAuD/QAeoBmgACQAPABUAKQAAARYXIRUhNSEmJwMXBgcnNiUWFwcmJx8BBgcWFwckJwYFJyQ3Jic3Fhc2'
    'BVBAKAHI+9ABuCAwWICY2GjgAmi4mHCgsFCQaJDo+GD+8ODI/qhYAVCwmHCAaJCIBmh4gJiYaGD+UFDgiHiYkHCgiLB46GD4'
    'sNBYqIDQyIiQkLC44GDYqLgAAAQDcP9IB5AGeAAJAA8AFQApAAABISYnNxYXIRUhBRYXByYnJRcGByc2FxYXNjcXBgcWFwcm'
    'JwYFJyQ3JicDqAGgKDCQSCgBePxAAriYiHiAqP6wgICocLiIWHh4QIhYeMjQYODAqP7oYAEYoIhoBXBwaDB4kJBYiLh4sLBY'
    'WPCIeKC42Kiw0Fj4sNBYqIDIwIiYiLC44AAAAQB4/0AHgAaIAC8AAAEXBRUUFjMyPgE3Fw4BISImPQEFJyU1IREQAycSGQEh'
    'ETMVIRUhFSEVBgcnNjchFQXoEP4QQIjQcCgIkBCI/pjoeP64GAFg/mDAmLgCMKAC+P0IA4A4YIg4KP1IBBCIGFggGBA4YCig'
    'YEBIgBiIEIj96P44/rBYAWABoAJoAYiIkHCIeHhQUEiAAAAEAxD/aAewBoAAHgAkACgALAAAARcHIRUGByERIREUFjMyPgE3'
    'FwYHBiEgJjURBgcnEhchNjchBhcRMxETMxEjBFCYMAHgODgBIP0AYNDogCAQoBBYUP6A/tigKDBI4AgBeEgw/pBYKOiQ8PAG'
    'gDCAgJBg/WD+eBggEFB4ONA4MEhYA+gwMIgBINhweLDA/mgBmP5oAZgAAAMDAP9IB5gGgAAXAB0ANAAAARcGByEVBgcWFwck'
    'JwYFJyQ3JicGByc2FxYXNjchAxcHIREhNSE1MxUhFSERIRUhESMRIScEYKAQIAIocJDA4Ej+8ODg/uBYAQi4aFBIWHDweGiI'
    'kFD+UNCQYAGA/fACEKABOP7IAWD+oKD9+DgGgCg4QHjIgEgwmDh4iDiIOFhIYFhIcMAgcFBoiPywSLABGJiIiJj+6JD+wAFA'
    'gAAAAgOY/0gHoAZ4ABgAHQAAASERMxEhAzMVIRIFBwADAgEnABMhNSERKQERFTMTBAgBGKABiCh4/mh4ASh4/vCIWP7oiAEw'
    'QP64AWD+6AG4yBgFMAFI/rj9uKD+eOCYAQABiP6A/vhwASgBaKABsP64aAGwAAABAFj/qAPIBoAAIAAAARcHIRUhESEVIRE3'
    'ETMRIzUFETMRNxEhNSERIxUGByc2ASCQMAIo/sgBWP6oiJiY/bCgiP6YAWiAMEiAiAaAOJiY/pCY/WgYAej9WDBYAtD92BAC'
    'sJgBcAiAcGDgAAADAuD/QAeYBngADAAQACYAAAEXBwAFByYBAgUnNhIDIRUhByEVIQIHJCUmJzcWEwcmJwQFJzYTIQUIoCAB'
    'AAEQYPj++Lj+0HDQ8JACWP2ouAPo/eiYgAEIATBASIigcJgYIP54/nhAyID+2AZ4IEj+oKigsAFo/sDQeKABIP5gmNiY/pCI'
    'EEhwcEDo/vBISEhYEJjQATAAAAQDCAB4B0gGKAAKAA4AEgAeAAABESERNjcXBgcnERcVITUBFSE1ExcGBwUHAAE3Fhc2BvD8'
    'uJiIKNjAUKACsP1QArAwkHBwARB4/tj+eICIiIAGKP0Q/fAwMIhQOFgFWJCoqP7YqKj+mFCAWOCAARgBEFhYaGAAAAIAYP9w'
    'BAAGIAAVACcAABMhFSECBzY3Jic3FhMHJicEBSc2EyEBFwQFJzY3ESE1IREzESEVIRWIA3j+aHh4uMgwOJiAUKAQGP7g/sAw'
    'mHj+2ANYIP54/ihAyLj+yAE4oAFI/rgGIJj+wJgYOHhoQOD+8EhIQFAYmKgBQPsYkFhIqBggAQCQAQD/AJDoAAAEA5D/SAeA'
    'BngAFwAfACMAJwAAATMVJCUXBAUVFBYzIDY3NjcXDgEhIiY1AREjNSEVIxETITUhESE1IQOQoAFwAUBo/pD+WChgAWCQGBAQ'
    'oBDY/iC4cAOQmP2wmJgCUP2wAlD9sAZ4+FBoiHhIgCgYIDgYmDD4eEBg/uD8MHBwA9D+mNj9wNgAAwBgAsgHkAZ4AB4AJAAq'
    'AAABFwYHIRUGByc2NyEHEgUHJCcGBSckNjcjBw4BByc2JRYXByYnARcGBSckA7CYEBgDEDhYoEgw/tgQ0AGAWP6g0HD+YFgB'
    'KNgQ4DgQSCiI0P3IsJBwmKgBuDDg/uhIATgGeDAwMIiAcChgYHj/AFiYeODYgIhQ2LhgIEgoaMCwUGiIeFD+eJCAaKhgAAAC'
    'AFj/QAeQAuAAFwAdAAATITcXByEVIQYHBQckJQQFJyQlJCc2NyEBNjchBgdYAqBgqEgD2P6IaLgCYID+oP7I/rD92FgBsAEY'
    '/wDYoID92APA+Fj94GBgAliIIGiQ4HioiHhYmDigIFBAMICI/th4sHhYAAMAoANgB3AGeAAJABkAHwAAATMRIzUGByckNyUh'
    'NTMVIRUhFSEVITUhNSEBFhcHJicCqJCQ+MhIATjQARABkJgBkP5wAWD8qAFg/nD9gKCIcJCYBnj86NBwOJBYaLjo6IjwiIjw'
    'ATBggIiQYAAAAwMo/0gHaAZ4ABEAFwAdAAABMxEhESM1ITUhESE1IREhNSEBFhcHJiclFwIHJzYFAKABwKj8kANw/LgDSPyY'
    'AbD+uJBYmFCQA5ioYHCQeAZ4/Xj7WHCYATiYATiYAkDA2FjYwFA4/viwUNAAAgM4/0gHsAZwAAUAIwAAARYXByYnAyE2NxcG'
    'BzMVIREVIRUhEgUHJAMCAScAEyE1IREhBGCAWJBIgEACMGAwsEBY6P5oAdD+WLABEFj+8LiA/oBYAYBY/mABuP54BnCAmFCQ'
    'iP7AyMgoyKCY/vhQmP5oyLDgAbD+eP8AiAEIAXiYAVgABQGQ/0AHuAZQAB8AIwAnAC0AMwAAARUhByERIREUBiMiLwEWMzI2'
    'NREhESE3IREQAScSGQEBITUhESE1IQMXAgcnNiUWFwcmJweI/iBQAdD+mFBwWFggYGAgGP54ARBQ/hj/AIjoAcACWP2oAlj9'
    'qAiIgNB44ALIsHCQaLAGUJDI/RD+EHhgEKAQIEAByALwyP0g/iD+SGgBaAHIA3D9eKD+MKj+aCj+4KhgwMi4yFjIuAAAAQBo'
    'A5gHoAaAABQAABMhNjcXByEVIRYFByQDIwIFJyQ3IaACqDgwmEADaP3w0AFwWP5A+Pj4/ihgAXjY/egF6EhQOGCQsFCggAEg'
    '/uCgiIC4AAQCSP9QB2gGiAAWABwAIAAkAAABFwYHIRAHBiMiLwEWMzISEyEVBgcnEgERIRUjEQE1IR0CITUDeJggKAOgQCiY'
    'YIggkGg4MBD8uFhogNgCqP4gmAHg/rgBSAaIMGhg+2j4sBCYEAEIBAgIwIBgASD+6PyYiAPw/pjY2JDo6AAABANI/0gHqAaA'
    'ABcAHQAlACkAAAEXBgchFQYHFhcHJCcGBSc2NyYnBgcnNhcWFzY3IQERIzUhFSMREyERIQSQoBggAiB4sMjwSP7w4MD+0Dj4'
    'sGhYQEhg2GhogJhY/lACYJj94JiYAiD94AaAKFBIkPigeEiYUJiQWJBIeGiIUEBw4EiYcJio/Pj9IHBwAuD+IAFYAAICoADI'
    'B2gGYAAWABoAAAEXBgcRIRUhFSERIREhNSE1ITUGByckASERIQawaNjoAhD98AGI/CABsP3wAhDI4EgB+P7wApD9cAZggCgY'
    '/viQ6P2oAljokPAQGJAo+0ABOAAAAwBo/zgCcAT4AAUACwARAAABFhcHJicDFhcHJicBFwIDJxIBWJiAcICQGIhwcHiAAWiA'
    'eNCY4AT4YHCIiGD+6FBoiHhY/uBY/tD+4HABEAAEAEj/SAPIBmgACQAPABUAKQAAEyEmJzcWFyEVIQUWFwcmJyUXBgcnNhMW'
    'FzY3FwYHFhcHJicCBSckNyYnaAFQIDCYQCABYPyoAoiAWIhQiP7YgHCgaKBAgHA4MJA4SJiIaICIiP7gSAEAgICIBVh4aDCA'
    'kJAooLBQsKBIWPCQeKj++GBoiKBIwJiYsIiomP8AwJC48IhoAAIAaP9IA5gGWAAZAB0AAAEXBgcRIRUhESERIzUhFSMRIREh'
    'NSERBSckAyERIQNISJioAUj+uAEQoP6IoAEI/rgBSP74OAGIsAF4/ogGWIggGP7QmP64/MiAiANAAUiYARggmCD6SAGQAAAB'
    'AFj/SAQABngAHgAAARYXIRUhFAchEAIjIi8BFjMyNhMhAgMnABMhNSEmJwJAQCgBWP4QEAGweKhIYCBoSFBAEP7gQMiYARAI'
    '/vgBmCA4BniQqJiAgPzQ/tAgoCC4AnD94P5YWAIIAwCYkHgAAAEAiAK4B5gGeAAuAAATITY1MwYHISYnNxYXIRUhFTY3FwYF'
    'HgEzMjY3Fw4BISAmJwcnNjc1IwIFJyQTIZACEBigCBgCCCg4gGBAAWj9OMiQYLj/AAhIyNBoGJAomP7g/uiQENhQoIjoiP5g'
    'aAFweP4gBbBgaGhgODhQWGiQwEhYcGhgGBhIeDioaEBIOIAoKPD+YMiIoAFAAAABBMD/SAeIBhgAFgAAARUDFhUUBiMiLwEW'
    'MzI2NTQnEyERIxEHeNjoiIBIaCB4WDA4+OD+kKAGGJj+APjwqLAgqChgWOjgAiD5yAbQAAABAfj/SAegBngAJwAAAQYHJwAT'
    'ITUhJic3FhchFSESFzY3FwYHEgEHCAEDIwYHETY3FwQHJwNAaHhoAWi4/lgCIDBIqFgwAkD96CBAqIB4mNBwASh4/vD/AEAY'
    'UJDQsCj++PBQAlhwWIABGAGAmJBwOJComP7g0GiokKh4/vD+6JgBAAJAAhDIyPz4UFCIiFhQAAMDMP8oB4AGeAAPABoAIAAA'
    'ARUhESMRIREjESERMxUhFQEzEA4BByckEjU2ARYXByYnBYABmKD92KABMKAB6P2woFD44GABCNgIASCooICQwAU44PywAtD9'
    'MANQAiC4iP4A/kD44FCAYAEQ6Aj+4JjIiMjIAAADAFj/QALIBngAFgAcACIAABMzETMRMxUjFRYXByYnESMRBgcnEhMjExYX'
    'ByYnJRcGByc2cOiA0NCAYGBAQIBIWGCgWOBwKBhwECgB4HAoKHAwA+gCkP1wgLCgkIiIcP1IAqjIqHgBEAFoAoiw2DDgqDAo'
    '8KhAwAAJAIj/OAd4BFAAEwAXABsAHwAjACcAKwAxADcAAAEhESEVIRUhFSEVITUhNSE1ITUhEyE1KQEVITUBITUpARUhNQE1'
    'IR0BITUhAxcGBSckJQQFByQlAWAFMP8AAVj+qAHo+RAB2P6wAVD/AJABuP5IAlgBuPvwAbj+SAJYAbj/AP4AAgD+ACh48P6o'
    'YAE4AzgBGAE4UP64/tgEUP3oaHhoiIhoeGgBQGBgYP7YYGBg/sBoaOBo/vBgYEiIMEggYIhwMAAAAwOo/5gHmAZwAAkAEwAZ'
    'AAABISYnNxYXIRUhBRcCAyEVITUhEgESEwcCAwPYAXAgQJhAKAGI/GgCsJhocAFQ/BACCID+cHgwkDCABSCYgDiYuJhIMP3I'
    '/liYmAHwAfj+UP5QKAHQAZAAAAEC6P9IBHAGgAAKAAABBgcnEhMXBgcRIwOAIChQsFCIIECQAzhYSJgBkAHAMMjA+oAAAQKQ'
    '/4gHiAZAABYAAAEXBgURIRUhESEVITUhESE1IREGBycgBxBQ6P7gAjD90AII+1ACCP3YAijY8DgCKAZAkCgY/cCY/YiYmAJ4'
    'mAI4EAigAAIDkP9gB6gGiAAMACgAAAEXBgcSFwcmAwIHJwABIREUFjMgNjcXBgcGISImNREhAgYjIi8BMzI2BYCIECDg8FDo'
    '6LjYaAFQAXj+eCiIAShQCJgYSDD+ePBYArgIcIg4OCCAOCgGiFA4OP7ImJCoATD+4LCIATD9wP04KBBQyDjoSDg4cAN4/lDI'
    'CKBQAAACBAD/QAd4BngAFwAuAAABFwchFRQCBAcnJBMhBgcWFwcmJwYHJzYTFwYHIRUUAgAHJyQTIQcXByYnBgcnNgWQmEAB'
    'aMD+sNhAAgCQ/tgQSDg4YDBAKDBg8NiAGBgBQOD+mPBAAkiY/vBYeHAwQEBAWPgGeCCIiDD+wNg4kHABgBBYOEBoQEAgIGi4'
    '/ehIICiIOP6I/wBAmIgB0GCQaEhIODCAqAAAAgK4/0AHaAZ4ABUAKwAAARcGByEVAgUnJBMhBgcWFwcmJwcnJBMXBgchFQIF'
    'JyQTIQYHFhcHJicHJyQFEKAoOAHo4PzgQALIyP44KChISGhIWIhoAWD4iCAoAcj4/JBIAzjQ/lAoMFBQcFBg0FgBUAZ4IEhI'
    'kP4YmKBoAXgoGEBIcFBQSHC4/dhIKCiQ/ci4oIgByCgoQFhwWFCAiKgAAAMAoALIB3AGeAARABcAHQAAASMRIxEhNSEmJzcW'
    'FyEVIREjARcCByc2JRYXByYnBHDooP3AAxAgKKA4IAMA/aig/ViQkKiAuASo4JCYgOAFGP3gAiCYUEgwYGiY/eABuEj+8JBw'
    'qNC42FjQwAAAAQIw/zgHsAZ4ACkAAAERIxEhBgcSFzY3FwYHEgUHAAMGBxE2NxcGBycRBgcnABMhESMRIRMXBwd4oP6AICBQ'
    'aJBQiHiomAEAeP5o4ChQkHgo0LBQiKBQAbDI/oigAkhAmDAFeP5QASBYSP7wwIiQYLiI/vjIoAF4AohgeP2ASFCImGhYAlCI'
    'YJgBAAJY/tABwAEAOMgABAFQAigGuAaQAAcACwAPABMAAAEXByERIREhASE1IREhNSERITUhA1CwSAMA+pgBsP7wBCj72AQo'
    '+9gEKPvYBpA4cPxAA8D+4Ij+cIj+eIgAAAEAeP9IBJgGGAAZAAATIRUhBgchAgEnABMhBgcWFwcmJwYHJwATIZgEAP4AIDgB'
    '2FD9MGACYHj+mCBAiHBwaHA4QGgBEHj+mAYYmJiQ/GD+kIgBEALgUHBogIiIYFhQgAFgAdAAAAIFCAHoBxAGWAANABEAAAEz'
    'ERQGIyIvARYzMjY1ATMRIwZ4mFCAaFggYGgwIP6QoKAGWPxoeGAYqCAoOAMA/SAAAAIAgAIQBKAGMAAVABkAABMhFSMRMxUj'
    'ESMRIQIFJzY3ITUhESMBESERwAOwwPDwmP8AEP7oWNgQ/wABAMACWP8ABjCQ/uCQ/jgByP7gwJCQwJABIP7gASD+4AAAAwIg'
    '/1AHmAaAACMAKQAuAAABITUzFSEVIRUhESEGBwQFByQlBgUnJDcmJzcWFzY3IREhNSETITY9ASkBHQEhEQKIAjCgAkD9wAH4'
    '/fggWAEAAchQ/lD+2LD+sFABIJigaGBwoEAg/hgCAP3Q0AFYCP6gAgABWAXIuLiYuP2w2IiISKhQqLhAoDiIcHhoeGhooAJQ'
    'uP2QOECoqHgBIAADA2j/SAeYBoAADwAkACoAAAEhNTMVIRUhFSEVITUhNSEDITUzFTMVIxEUBiMiLwEWMzI1ESEXFhcHJicD'
    'wAF4oAF4/ogBuPvYAdD+iFACyKDAwFiIcFggcHhA/TjwaEiYQGgFkPDwkPCYmPD9kLCwmP4gcGAYqCBQAcBQgJhIoIAAAwM4'
    '/0gHmAaAAA8AJAAqAAABITUzFSEVIRUhFSE1ITUhAyE1MxUzFSMRFAYjIi8BFjMyNREhBRYXByYnA5gBiKABkP5wAdD7qAHo'
    '/nhYAuig0NBYiHBgIHh4QP0YAShQQJg4UAWQ8PCQ8JiY8P2QsLCY/iBwYBioIFABwFCAmEiggAAAAwLg/0gHmAaAAA8AJAAq'
    'AAABITUzFSEVIRUhFSE1ITUhAyE1MxUzFSMRFAYjIi8BFjMyNREhBRYXByYnA0gBsKABsP5QAfj7UAIY/lBYAyig4OBokHBw'
    'GIB4WPzYATBgQJg4YAWQ8PCQ8JiY8P2QsLCY/iB4WBioIFABwFCAmEiggAAAAgGA/0gGgAJQAAcACwAAAREjNSEVIxETIREh'
    'BoCg/ECgoAPA/EACUPz4cHADCP4AAWgAAAIAWP9ABxAGeAAPABMAAAEWFyERIRUQAycSGQEhJicBIRUhBEBAKAJo+qjwcMAC'
    '2CAwAtD7SAS4BnhYYP4QyP14/sCIARACcAJ4SED+6NAABgBg/0AD8AaAACMAKAAsADAANAA4AAABFwYHIRUGBzMRFAYjIi8B'
    'FjMyNREjESMRIwIHJzYZAQYHJzYHITY3IQMzNSMhFTM1ATM1IyEVMzUByJgYIAFYMDDQUEhIeCCIMCigkKAIYJhoICBQ+AgB'
    'IDgw/vhIoKABMKD+MKCgATCgBoAwODiIaFD7UFhYEJgQMAFA/uABIP6wuDjQAXgCeBggkPDgUGD96NjY2P3I2NjYAAUAoP9o'
    'B2ADAAAHAA8AEwAXABsAAAERIzUhFSMRBREhFSE1IREXITUhESE1IREhNSEHYJj6aJAFoAEQ+VABMJADUPywA1D8sANQ/LAD'
    'AP7IsLABOND9sHh4AlDAUP7oUP7oWAADAMADEAdIBmAAFAAqAEAAAAEhFQYHFhcHJicGBSc2Nyc3BTY3IQEhFQYHFhcHJicG'
    'Byc2Nyc3Fhc2NyElIRUGBxYXByYnBgcnNjcnNxYXNjchAdAEUGiIoJBIwPjo/oAowKDYKAHQmGj8gAJQAuBAYIBoSICooPAw'
    'iGigKKCIWDj92PywAthAWHhwSIiomPgwiGigKKCIWED92AZgcEA4GChgMDBAKHAQGCBQOCgo/shwSDggKGg4MEAocBAgIFgg'
    'ICgwaHBIOCAoYDAwQCh4EBgoUBgoMCgAAAIDGP9IB2AGeAAUACYAAAEXBgchEAIjIi8BFjMyNhMhBgcnEgEWFwcmJwQFJzYT'
    'FwIHNjcmJwRokCg4AsiIuEhgIGhIWFAQ/ZhYaIDoAZiQMKAQCP8A/uAwqHCgeIiwuChIBngwkID7mP54IKAg+APAuIhoATD9'
    '6PD4MDg4WCCQ4AGwMP5osBBQgHgABgBo/0AEUAZ4ABMAFwAbAB8AJQArAAATMzUzFSE1MxUzFSMRMxUhNTMRIwUhNSERITUh'
    'ESE1IQMXBgcnNiUWFwcmJ4CgoAFQoKCgmPwguKABQAFQ/rABUP6wAVD+sBiIiLB4uAHwaECAQGgFiPDw8PCQ/JiQkANoyMj9'
    '6Mj96Mj+gFjIeIh4mHiISIB4AAMD6P9IB1AGOAATABcAGwAAAREUBiMiLwEWMzI1ESECAycSGQETIREhESERIQdQYGBIeCiA'
    'SED+kCigkMCoAWD+oAFg/qAGOPn4cHAQqBhwAYD+kP7YaAFQAZgDoP4YAVD80AFQAAMAWP9AA8gGeAAWABwAIgAAEyERMxEh'
    'FSEVFhcHJicRIxEGBycSEyETFhcHJiclFwYHJzaYAUiQAUD+wMCIaHBwkHCwaPiA/siAQDh4OEgCuHhAWHhoA/ACiP14iJig'
    'mJiYgP0oAvDwyIABEAFgAoiw0DjYqDgo8KhAyAADAuD/SAewBngAGgAeACIAAAERIRE2NyYnNxYTBycEBScgJREhFSMRIREz'
    'EQEhESkBESERB0D+UJCIMECQiGCgMP5Q/dgoARABCP7woAGwmP5YARD+8AGoARAFMPzo/jAQIIBwQPj+4EiYUBigIAHgkAOo'
    'AUj+uP2AAej+GAHoAAMAqP8wB0gC4AAHAA8AFQAAAREjESERIxEFFwIABSckABcEBQckJQaIoPwooAJYoDj+cP5YUAGYAWD4'
    'AWgBSEj+oP6wAuD9oAHY/iACaNAg/tj+sEiYOAEYcFiAoJhYAAIEIP9IB5gGeAAPABMAAAEzESEVIREhESM1IRUjESEDIREh'
    'BUCgAbj+SAGImP3omAEgiAIY/egGeP6YkP6A/EiYmAO4/XACAAAAAgMQ/0gHsAZ4ABQAGgAAASE2ETMQByEVIRIBBwADAgEn'
    'ABMhARYXByYnA1ABmBCYCAIA/khgAYB4/rCAUP5IUAGgMP5wA1BgSIhAaARQ6AFA/sjwoP2g/oiQAWACSP2Q/siIATACsAJY'
    'eJBAiIAAAAIAUP9IAnAGeAAJAA8AAAEzESMRBgcnNjcDFhcHAicB0KCgmKBI2KjQUDiYOEgGePjQAtiAYKBwkAKg0PhIAQDQ'
    'AAIAUP9AAtAGcAAJAA8AAAEzESMRBgcnJDcBFhcHJicCMKCgwNBQARDQ/uh4WJhQgAZw+NACyLCIsJjAAnCQqEiwkAAAAQNQ'
    '/0gHaAZ4ABgAAAEzETMRIQoBIyIvARYzMjcSESECAScAEyMD+PigAdgIcIhoiBigYDAQMP7ACP44cAGYCPgFGAFg/qD7kP7A'
    'GKAYiAE4Arj8OP6QeAFYA2gAAAEASP8wA+AGeAAZAAATIREzESEQAgYjIi8BFjMyNzYRIQIBJwATIXgBIKABqDCIiFBYKGho'
    'YBgw/vAI/ohwAUgI/uAFEAFo/pj82P34kBCYEGDIA2j8KP6QeAFYA3gAAAECsP9IB2gGeAAYAAABIREzESEQBwYjIi8BFjMy'
    'NhMhAgEnABMhA4ABKKACIEAwwHCgIKhwUEgQ/oAI/fCAAfAI/tgFEAFo/pj8AOjAGJgY6AOQ/ED+kIABUANgAAABApAAmAeI'
    'BoAAFQAAASERMxEVIRUhBgcAAQcCAQIFJwATIQLAAdigAgD98AgYAXABEIjw/sCY/rBYAahQ/jgE2AGo/nggmFBI/sj+sIgB'
    'UAEY/pjwkAFAAcgAAAECcACQBvAGeAAcAAABITY3MwYHIRACBiMiLwEWMzI2EhEhCgEHJwATIQKQAZgQCKAIEAIoMHiQYGAo'
    'eHBAMCD+eCjQ0IgBeDD+eAUQoMjAqP2I/niAEKAQQAGAAYj+iP5AsHABMAJIAAABAzD/iAeYBggACwAAASEVIREhFSE1IREh'
    'A4AD8P5QAdj7mAHw/mAGCJj6sJiYBVAAAAEBwACYBhgFaAAaAAABIREzESEVIREUBiMiLwEWMzI2NRECAScAEyEB+AJ4oAEI'
    '/vhYgHBoGGhwMCDY/oBYAYCw/ggEYAEI/viY/ZhwWBiQGCgwAij+YP8AkAEIASgAAAEDGP9IB6AGMAAbAAABIRUGBxUhFSER'
    'FAYjIi8BFjMyNREhNSERNjchA5gDmLDQAfD+EFhgWFAYQFhQ/fgCCMCQ/SgGMKjQsLiY/SBISBCQEBgCyJgBCKCgAAIAgALg'
    'B5gGiAAaAB8AAAEXBgchFQYHBAUHJCUEBSckJSYnBgcnNjc1NhcWFzY3AsCoICgDWKjwAUABeFD+KP6w/qD+IGABsAEwqGiA'
    'mGj4iEA4eNjwiAaIKDg4iNCIYCigSIiQSJhAYGCYcFB4kJAIUOCgYHCQAAIAcAKQB3gGiAAXAB4AAAEGByc2ExcGByEVBgcW'
    'BQckJQQFJyQlJgMGBxYXNjcCCEBQaPh4oCAoA4CY8OAByEj+AP7Y/pj+GEgBqAEwuAgIEKj4+IgEoEhAeNABKChQSJDgiFBI'
    'mFCAmEioMGhgAQgQCJB4cLAAAAUBWP9ABpgCcAAHAAsADwATABcAAAERIzUhFSMREyE1KQEVITUBITUhBSE1IQaYmPvwmJgB'
    'uP5IAlABwPvwAbj+SAJQAcD+QAJw/NA4OAMw/sioqKj+KKioqAAAAQCo/0AGsAKoABgAAAEhNxcGByEQBiMiLwEWMzI2EyEC'
    'BSckEyEBGAIYIKAQCALYgMhwqCCogGBAGP2YiP3YUAHQgP4gAgCoIEhA/hDIGJgYcAEY/liAmGABMAACAID/UAMgBjgAFQAb'
    'AAATIQMzCgErAScyNzY3NhMhExcDMxMhARcGByc2mAJAOIAYcJBwIKgQGBAYCP4wKKAguDD+YAFYGJi4OMgGOPy4/XD+8JgQ'
    'GGioAUAC0Bj92ALA/BiQeFigWAAAAgCA/1ADSAY4ABUAGwAAEyEDMwoBKwEnMjc2NzYTIRMXAzMTIQEXBgcnNpgCYDiIGICQ'
    'eCCwECAQGAj+GECQKNA4/jgBaCCgyDjQBjj8uP1w/vCYECBomAFIAtAY/dgCwPwYkHhYoFAAAAICoP9AB5gGeAApAC0AAAER'
    'MxEhFRQDJzY3IREhAgMWFwcmJwYHJzY3Jic3Fhc2NyEVEAMnNhI1ERMzESMFCKABwGiYMCj+6AGIKPiY8HjYqLDoWOCYiGiA'
    'YIioKP2w+IiAaJjo6AV4AQD/AJA4/wAwgID+eP54/uh4aJhwmJhgmFCAmMhYwJDI4DD+IP6QWOABaPACoP3gAYgAAAEAmP9Q'
    'B2gEeAAJAAABMxEjNSERMxEhBsigoPnQoAWQBHD64HAEuPvgAAEC4P9oB5gGUAAgAAABMxEkExcAAREUFjMyNjUyNjcXAgcG'
    'ISMiJjURBgcnNjcEAKgBMPB4/uD+iDiQcHhYOAioKEho/rBQuGhwYFCAoAZQ/VjgAShg/oj/AP2QOCgICID4SP6AKDhYaAJI'
    'QDCIQGgAAAEDaP94B6gESAAcAAABEAIjIi8BFjMyNhMhERQWISA2NxcGBwYhICY1EQb4WMBQcCB4UFAoEP24QAEAAWBYCKAo'
    'UDj+UP6QcARI/fD+6BigGJABYPyoKBhYsDj4SDBIeAQQAAADAGD/YAPABgAABwARABcAAAERIxEhESMRATMQCgEHJzYaARMW'
    'FwcmJwOomP5YmAEokEDgqGCYwEDQgHh4aIgGAPs4BDD7yATQ/tD9kP6Y/shggFgBEAFI/pBwmHCQkAACAyj/UAeQBnAAGwAg'
    'AAABAgMnEhkBJCUXBAURIQIDFhcHJicGByc2NwIDMxIXNhMEeBCwkLABmAFQgP64/oACuCDAeMhQwJCQ2GDgiLBAkDiIcCAD'
    'qP2Q/lhgAaACqAGoMGCAYDD+2P4o/riwgJBwwMB4iHjIAUABUP746OABEAAAAgKI/1AHmAZwABsAIAAAAQIDJxIZASQlFwQF'
    'ESECAxYXByYnBgcnJDcCAzMSFzYTBBgQ8JDwAcABeHj+oP5QAwAg4KDgeNCYsPhgAQCg2ECgOKCQKAOo/XD+UGABqALAAbAw'
    'YIBoKP7Y/kj+oLiIiIDAyICQcMgBQAFQ/ujw6AEgAAECcACQB4AGaAASAAABFwQFESEVIREjESECAycSGQEkBtBg/oD+CAPI'
    '/rCo/jAYsICoAigGaJBgEP7YmPzoAxj+aP6wcAFoAYgB4AgAAAID8P+QB6AGMAALAA8AAAERIRUhESEVIREhEQERIREEkAMQ'
    '/FADiP0YAnD9kAHQAZD+mJgGoJj+kP1oAgj+kAFwAAEAWP8oA1gGGAAZAAATIRUhBgchCgEBJwATIwYHFhcHJicHJxITI5AC'
    'yP6wGCgBeBj4/vB4Abgw+CAoeFBYSGBIeLhY2AYYmKCI/nj9mP7AaAIAAjBwaDBAgEAwmHgBaAHQAAAFAagAaAZIBUgAAwAH'
    'AA8AGQAfAAABIREhNyE1IQERIxEhESMRBTMUBxAFJyQ2NQUWFwcmJwKAAxD88JAB8P4QAriQ/aCQAWigCP3AYAEw2AEI0MBw'
    'qOgFSP5oiIj+oP4QAWj+mAHwuLgI/uhoeDCYcKhAWHBYYAABAKAEmAdgBogADQAAARYXIREjNSEVIxEhJicECDAgAwiY+miQ'
    'AwgYIAaIQEj+mNjYAWgwKAACAIj/6APABngADwATAAABMxEhFSERIREjNSEVIxEhAyERIQGYoAGI/ngBUKD+QKABEHABwP5A'
    'Bnj+0JD+yPxocHADmP1wAfgAAAIDoP9AB5gGeAAiACgAAAEzEBclFwUSEzY3FwIHEjMyExcCIyImJwYHJyQ3AgMFJyUmJRYX'
    'ByYnBMioEAH4EP4AGECAaIiQqHBIIBCYKKA4oFDA8FABGKhgIP7QGAE4EAFokHhwcIgGeP7o4ECQSP74/wDA+Ej+sNj+4AEI'
    'KP5YuLDAeIiYuAFAAVAwkDDw6GB4gIhYAAIC4P9gB6AGeAALACIAAAECBScAExcHAAUHJAUzESQlFwQFERQWMyA2NxcGBwYh'
    'ICY1BTDI/tBYAXDIiCABAAEgWP74/YCgASgBAGj+2P6YUJABAFAQmCBQOP6w/vh4BWj+uOB4ATABkEhA/qiwmLCw/qCAoIiw'
    'gP7gKCBQoCjoQDBIYAAAAwJQ/0AHoAZ4ABAAFgAmAAABIRMzBgchFSEKAQcnNhITIQEWFwcmJwMzERQWMzI2NxcOASMiJjUC'
    'mAGwIKAIEAJg/ZAw8PCA2Ogo/mADSJiAaIiQYKAocHBACJggeLjIcASwAcj40Jj+KP3Y2HC4AgABsAIwYHiAkGD9iPzoKBhg'
    'sED4eFhoAAUAWP9QBAAGeAAJABoAHgAkACoAAAEWFyEVITUhJicDIREhERQGIyIvARYzMjURITchESEDFwYHJzYlFhcHJicC'
    'QDggAWj8iAFgGCjgAvD+0FBgUEAgSFAw/tiYAcD+QEiIaHBweAKAYECIOGAGeGhwmJhYUP4Y/cD+CHhgGKggYAHQkAEg/fBQ'
    '+JBoqMiIqEiYkAADA6j/SAeoBngADQATACQAAAEhETMRIRUhAgEnABMhARYXByYnAzMRFBcWMzI2NxcOASMiJjUECAEQmAHQ'
    '/igY/nBYAVAY/vgCkGhAgEBgSJgQCCBAKBCIGGCIeFgEqAHQ/jCY/Kj+kJABQAL4AhhgeEhwaP2I/NAoCAhAuDjocFBoAAAD'
    'AqD/UAeYBngAEQAXACcAAAEhNjczBgchFSEKAQcnNhITIQEWFwcmJwMzERQWMzI2ExcCBiMiJjUDOAEwEAigCBACSP2wKOjQ'
    'gMDYIP7gAsCQeGiAiEioIFhIOAioIGiouGgEsND4+NCY/jD92NBwsAIAAagCOGB4eIhY/aj8wCgYaAEIQP64iFhoAAED+P9I'
    'B3gGMAAnAAABIRUGBxYXByEVFAYHJzY3IxEUBiMiLwEWMzI1ESE1ISYnNxYXNjchBCADAGiQMCgwAShAMJg4KMhQcHhwIHh4'
    'OP6QAeCgqGhoWGhA/cAGMJjAqCgwQIgQ+HAwmKj9GHhgGKggYALAkLCIaEhQeIAAAAEDkP9wB7gGMAAYAAABIREjNSERFBYz'
    'IDYTFwIHBiEgJjURIREhA5ADmKD94FCYAVBoGJggeEj+eP7weALA/QgGMPyAaP1IKCiAAQAo/phQQFBoA4gB6AABBAD/cAe4'
    'BjAAGAAAASERIzUhERQWMyA2ExcCBwYhIiY1ESERIQQAAzig/hhQgAEQeBiYIGhI/pj4eAKI/WgGMPyAaP1IKChgASAo/phY'
    'OFBoA4gB6AAAAgBw/1AHqAZ4ACwAMgAAEyE1MxUhFSEVIQMzEyEVIRITNhMXAgMWMzI3Fw4BIyIDBgcnNjcCAyE1ITUhARYX'
    'ByYnuAGgoAGY/mgCKBCgEAHQ/jgQOGBImGCoQDhQEIgYcGCIaEhgWHhQUCD7SAHo/mAF4GhAmEBYBciwsIi4Aej+GJD+6P7g'
    'uAEQOP6Y/vjg+BjwoAEIUEiAYGgBKAHIkLgBIICgQKCAAAAFA5j/WAdABeAABwALAA8AEwAXAAAFFSMRIREjNRkBIxEDIxEz'
    'AREjEQERMxEEOKADqKDwkOjoAYDw/ojoCKAGiPl4oAM4Ahj96AIY/ej9WAIg/eACIP3gAiAAAAMCsP9IB6gGgAAiACcALAAA'
    'ARcGByEVBgchETMVIRIFByQDAgUnJBMhNTMRITY3IQYHJzYBESEGByM2NyERBFCYGCgBqEBIAXBo/iiAAWBY/nigYP5ogAFo'
    'aP5QYAHoUDj+uGB4cNgCsP7wECCwKBj+6AaAIFBIgJhw/eiY/th4qJgBoP644HC4ARCYAhiAeIBgcLD8sAGI4Kig6P54AAAD'
    'AFj/SATIBjgAJAAoACwAAAEhESEGByEQBiMiLwEWMzI2ESMCASckEyMCBSckNyMGByc2NyMTITUhESE1IQEYA1j9+CA4Arhw'
    'qEBQKIA4ODgwsP6IaAFIqICw/qBoATCggFhgYNBgqKACGP3oAhj96AY4/RBQUP2Q8BCoEKABiP5A/vCA+AFY/rDIgKjwWEBw'
    'mMABuKj+MKAAAwCYABgDKAXgAAcACwAPAAABESM1IRUjERMhESERIREhAyiY/qCYmAFg/qABYP6gBeD6eHCwBcj9wAGw/AgB'
    'uAAAAwFI/0gGwAIoAAcACwAPAAABESM1IRUjERMhNSERITUhBsCY+7CQkARQ+7AEUPuwAij9IFBQAuD++Ij+cIgAAAMAaAPA'
    'B5gGiAANABMAGQAAARYXIREjNSEVIxEhJicDFwYFJyQlBAUHJCUEICgYAwig+migAxgQGOCI0P5wYAF4A0gBUAEgcP7o/rgG'
    'iEBQ/sC4sAE4MDD++EjAiICAeGiQeJhgAAQBAP9IBugEeAANABEAJwAuAAABFwYHIREjNSEVIxEhNgEhESEFFwchFQYHFwcm'
    'JwYFJzY3JicGByc2BTY3IQYVFgNYsEBIA2ig+1igAcBY/ogEqPtYAaCYMAIIUICocGhwyP7wQNCgaGgoOGjQAXh4QP5QGJAE'
    'eDBYSPugYGAEYGj8IALwGChYgIhgYHhIQGAokBg4MCgoIHCQyEBYGAg4AAQBkABwBmAFeAAWABwAIgAoAAABFwchFQYHFhcH'
    'JCUGBSckNyYnBgcnNhcWFzY3IRMWFwcmJwcEBQcmJQMIkCACAGCI4PBQ/wD++Oj+wFABIMBgUEhYaOCIYIB4SP5oYODIQNjY'
    'YAF4AQBY+P6YBXggQICoaGgwiECAeDiAMGBAUFA4YJgIYFBYaP4gQFCQYDhQYIiAgGgAAQHYAIgGAAVgACUAAAEhNTMVIRUh'
    'FSEVIRUhAgYjIi8BFjMyNjchESMRITUhNSE1ITUhAegBmKAB2P4oAZj+aAHgCGiAKFgYYDgoIAj+wKD+WAGo/pgBaP5oBOCA'
    'gJCAmID+0KgYkBg4eP5oAZiYgJiAAAABA8j/QAdoBngAJQAAASE1ITUhNTMVIRUhFSEVIRUhEAYjIi8BFjMyNhMhESMRITUh'
    'NSEEAAEo/tgBKKABcP6QAVD+sAGgaHgwMBg4MDAYEP74oP6gAWD+2AQA8Jjw8JjwiPD+INgImAhAAUj9UAKwmPAAAAUCwP9I'
    'B6AGQAADAAcADwAZAB8AAAEhESE3ITUhAREjESERIxEBMxAHEAUnPgIFFhcHJicDoANY/KiQAjD90AMAmP1goAGQqAj9oGjw'
    '6FABKMjIeKjoBkD98JDw/fj9IAJQ/agC6P8A/vAI/ligiDiguIh4oHigoAAAAQCI/0ACmAYwABYAAAEVAxYVFAYjIi8BFjMy'
    'NjU0JxMjESMRApiwqHhwIDAYQCgoKLC44JgGMIj+MPjwmJgQkBBQUOjoAej5mAbwAAEAaAAYAtAGEAAWAAATIRUjETMVIxE2'
    'NxcEBSc2NxEjNTMRI3gCWODAwGhYGP8A/sAggHDIyOAGEJj+MJD+GCgwmIBYoCAoAhiQAdAAAAUDKP84B6AGeAALABEAFwAi'
    'ACgAAAEzESERIxEhESMRIQEXBgcnNiUWFwcmJwEzEAcGAAUnPgIFFhcHJicFKKABeKD9wKABaAGYmFBgkHD9oGBAmDBgAZCg'
    'GCj/AP8AaNjgUAEAuLiAoNgGeP3Y/JgC2P0gA3ABwDDAgFCQgHiYSJCI/Yj+WFi4/wBYgEjA8MCAqIiwoAAAAgBo/7ACyAZ4'
    'AAUAEAAAARYXByYnAyERNjcXBgcnESMBiHBImEBwkAF4QEBoYKhw6AZ4mKhYqJj+CPxwQFhgmIhoA4AAAAEA0P9IAzgGeAAM'
    'AAATMxE2NxEzESMRBgcn0KCoiJiYsNhIBiD7UCgwBLD40AHoODhIAAADAqj/SAeYBjgAEQAcACIAAAERIxEhESMRITY3ITUh'
    'FSEGBwMzEAcQAAUnNiQSFxYXByYlBzCg/XCYAWAQCP44BFj+EAgQaJgI/tD+sGj4AQhY2ODgeMD/AAUI+/ADgPx4BBhQUJCQ'
    'UFD+yP6YEP7g/oh4iFDgAQD4iLiAuLAAAAEAmAQIB2gGiAANAAABFhchESM1IRUjESEmJwQIWDAC2Kj6gKgDQDBQBoh4kP6I'
    '4OABeHBgAAEB6P+IBzgEMAAXAAABMxEkJRcEBREUFiEgPgE3Fw4CISAmNQHosAJQATBw/nD9oHgBQAFoiEAIsBBo0P5g/mDI'
    'BDD+QHiQeMBg/pggICBgsDjYmDhYYAABBMj/UAdYBngACQAAATMRABcHAicRIwTIoAEg0HC4yKAGeP2I/wDwoAEAyPwYAAAD'
    'AtD/aAegBoAAFAAnACsAAAEXBgchEAIjIi8BFjMyNhEhBgcnEgURIREUFjMgNjcXBgcGISAmNRETMxEjA/iIEBgC0GCAICAo'
    'SCAgIP2QYHB4yAI4/oBA+AEoSAigIEA4/oD+oHig4OAGgCBgWPyY/sgImAjgApDwkHABAPD9sP54KBBImDjIQDhAcAP4/kAB'
    'KAAAAQBI/0ADsAZwAB8AAAEXBgcWFwcmJxEjEQYHJyQTITUhJic3FhczFQYHFRc2AyiIWFhgUGiAgJiIgGABaOD+GAEoOEiQ'
    'WEDAeHhYUAPAUJBYYGCQuJD8wAN4iEiQyAGokGBYQHCIkOCoMEhoAAACArD/SATABngABwANAAABMxEQAScAEQMXAgMnEgQo'
    'mP5wgAF4yJAYSIhABnj8qP2g/ohoAWACEAHIGP6Y/tg4ARgAAAMFAP9IB4AGgAAJAB8AJQAAATMmJzcWFzMVIRMjNSE2NxcG'
    'BzMVIRUzFSMRIxEjNTMDFhcHJicFCOAYKJA4IOj9kNjgAWAwGIgYKJD/ANjYoLi4IDgQiBAoBZBoWDBwgJD98IiwsCCwkIjY'
    'iP24AkiIArBwkDCYcAAAAwBY/1AC6AaAAAkAIwApAAATMyYnNxYXMxUhBRcGBzMVIxQHMxUjAgcnNhMjNTM2NSE1ITYnFhcH'
    'Jidw4CAomDgg6P2QAaCIICiY8AjI2CD4cNAowNAI/vgBaDDQMBiIGCgFkGhYMHCAkCggsJCIeGCI/oDAiJgBIIhgeIiwoHCQ'
    'MJhwAAABA2D/OAdYBhgAFwAAASECBwYjIi8BFjMyNxIRIRACByc2EhEjA+ADeAhAMJhoiBCQaDgQOP6QqNhwiMjQBhj60Oiw'
    'IJggiAFQA8D9AP2o8ICQAggDMAAAAQBoAEADoAXIAA4AABMhFSERNjcXBAUnNjcRIYACyP7owJgY/pj+UCCgiP7wBciY/BAw'
    'OJCAWJggIAQYAAABAqD/OAeoBngAEAAAAQIBJyQSETMUDwEUGgEXBwAFMFD+MHABOPioCBCw4LiI/qgCgP4o/pCA6AKYA0Dw'
    '4Mg4/fD+yJCAATgAAAMAaP9IA6gGeAAbAB8AIwAAEyE1MxUhFSEVIREhFSEVIREjESE1ITUhESE1IRMhNSERITUhaAFYkAFY'
    '/qgBOP7IAVj+qJD+qAFY/ugBGP6o0AHA/kABwP5ABciwsIi4/SiwiP7QATCIsALYuP4YqP44qAAAAgBo//ADEAZ4ABYAHAAA'
    'ARcCAzY3FwQFJzYTBgcnNhMXAgc2NzYTFwQFJyQCgJDI8MCYKP8A/tAwqJiIiCCocJhooHhYSHAg/wD+0EABSAUwOP5A/vgw'
    'OHhoOICwAQAYEJDoAXgw/qDICBB4/ICQaEioSAABA4ACOAeYBngADQAAATMREgUHJAMCBSc+AgUYkIABcHj+2HhY/rBYoLhA'
    'Bnj+YP6QwHCwARj+2JBwSNDwAAEAaP+AB5ACGAAPAAABMxUhFSEVIRUhNSE1ITUhA7CoArD9UAM4+NgDSP1QArACGLiQuJiY'
    'uJAAAQD4AiADsAZQABYAAAEVAxYVFAYjIi8BFjMyNjU0JxMhESMRA7CwsIiASGggeFgwONjA/piYBlCQ/wCIkIB4GJggODCA'
    'cAEo/GAEMAAAAwLY/0gHmAY4AA8AGwAhAAABESMRIREjESE3ITUhFSEHAzMQBwYABSckABE2ExYXByYnBzCY/aCYAUAg/kgE'
    'KP4wIGiYGCj+6P7wcAE4AQAI4NDQeLjwBQj78AOA/HgEGKCQkKD+yP4waMD+0GCIaAFIARAI/nCIuIC4sAAAAgBg/8AD0AYo'
    'ABAAHAAAAQYHJyQTITUhFRQGBxYXByYFIRUhESUXBSclESECOKjgUAGwmP4YApBwQKCQSKj96ALA/vABMBD86BgBUP7wA+iQ'
    'QICAAYiIgBDwSFBgmIDQkP6AMJCYmEABoAAAAwBo/6ADGAZ4AAkAFgAcAAATISYnNxYXIRUhBRcCAzY3FwQFJzY3EgMSEwcC'
    'A3ABACAwkEAoAQD9WAHgkDh4cFgY/uj+qDigmHjwQBiIGDAFOJh4MJCwkGAw/kD+aCAogIhgmCgwAcgBsP6Q/oAoAZgBYAAC'
    'AyD/QAeYBngACwAtAAABMxEhETMRIREzESEHIRUhBgchERQGIyIvARYzMjURIxEjESMRIxEjESMRITchA1ioAQigARCg/AA4'
    'BHj9+BAgAghQSCAwIDAYKJCQkJCQmAFYMP4wBgD+0AGo/lgBMP5IoIhYSP1oUFgIkAgwAfj9sAJQ/agCWP1QAzigAAUAYP9A'
    'BEAGeAAZAB8AJQArADEAAAEWFyEVIwYHMxUhERADJxIZATMmJyM1ISYnEzM2NyEWARcGBSckHwEGBSckBRcABSckAmBAKAFQ'
    'YCA4yP04eIhwsCgwcAFoIDhQuDAY/qg4AUhYmP7IQAEQ6GC4/pA4ATgBKGD++P54UAGYBnhgcIiYeIj+QP6Q/uhQARgBYAII'
    'kICIWEj9yIiIgP7IaLiIgHBoaMiQgHAwaP74iHiYAAEAcP9IA2AGKAAkAAATIRUGBxchFQYHJzY3IxEUBiMiLwEWMzI1ESE1'
    'ISYnNxYXNjchgAKocJhAAQBAWIBAKKhAYEhAIEhIIP8AAThwgHBQQHhI/ggGKJDYwFCQqKBIeID9EIBgEKAQYALQmHhgcEBI'
    'mJAAAwMw/0gHsAY4ABEAHAAiAAABESMRIREjESE2NyE1IRUhBgcDMxAHBgAFJz4BEhcWFwcmJwdIoP3gmAEoEAj+aAP4/kAI'
    'EGiQECj++P74aODoWNjIwHio6AUI+/ADgPx4BBhQUJCQUFD+yP4waMD+0GCIUOABAPiIuIC4sAAAAQBo/1ADGAYgABAAABMh'
    'FSERFAYjIi8BFjMyNREhaAKw/wBAcHBgIHh4EP7wBiCY+pBwWBiYGEgFWAAABQLQ/4gHmAYgABMAFwAbAB8AIwAAASERIRUh'
    'FSEVIRUhNSE1ITUhNSETITUpARUhNQEhNSkBFSE1A0AD8P5YAaj+WAIQ+zgCGP5YAaj+WJgBEP7wAbABEP1AARD+8AGwARAG'
    'IPxo6JjomJjomOgCEPDw8P2Y6OjoAAAEAmD/SAeoBoAACwAkACoAMAAAARcHAAUHJAECBScAByEVIxUhFSERFAYjIi8BFjMy'
    'NREhNSE1IwMXAgcnNiUWFwcmJwTYmCABEAE4YP7Y/vDI/thwAXggAkjgAfD+EGCAWEggYGBA/fgCCMhQiKCoiMgDOMiAkHjI'
    'BoAwQP7YoKCoATj+0MBwARD4kNiY/fh4WBCoGFAB6JjY/kBQ/tioeMjQ0OhQ4NgAAAIAUP94ArAGeAAKAB8AAAEXBgchFSEG'
    'Byc2EyM1IRUjETMVIxE2NxcGBycRIzUzASiQGCABMP6YOGBgiIhgAZCYuLhYSBhwmEjY2AZ4MGhgkJB4aNj+iIiI/tCQ/lAw'
    'MJBYQEgCMJAAAwCA/1AC0ASAAAUACwARAAABFhcHJicDFhcHJicBFwYFJyQBeMCYcKCwKLiQcJioAbCAkP74kAEIBIBokIio'
    'cP7oYHiIkGD+2Fjo2GjQAAACAFD/iANgBfgAEwAXAAATIRUhAgchESM1IxUjEQYHJxITIwEzESOAAuD+uEhQAZCYuJBIOGDA'
    'aPgBQLi4BfiY/ujI/HBQuAM4kEiAASgB0PtwAiAAAAEAaAAYAxgGEAAVAAATIRUjETMVIxE2NxcEBSc3ESM1MxEjaAKI8ODg'
    'iHgY/tj+mCD44OD4BhCY/jCY/ig4OJCYaKBIAhCYAdAAAQGQ/0gEcAZwAB4AAAEWFzMVIQMhEAIjIi8BFjMyNhMjAgMnNhIT'
    'IzUzJicDMEgg2P64EAFIcJgwQCBIOEAwELgg4ICAcBCA2CA4BnCIoJj+0Pzw/ugImBC4AlD9oP64cLgB8AJQmIhwAAEEkP9Y'
    'B5AEUAAbAAABIRUGBxUhFSERFAYjIi8BFjMyNREhNSE1NjchBTACKGh4ARj+6GBoWFggSGBY/rABUGhY/pAEUKiYiDCY/ihI'
    'SBCYGCABuJiAcHAAAAEEaAQgB5AGcAAJAAABFwchFSEGByc2BViYQAHg/eA4UICoBnAwqJCAaGDoAAAGAGj/SAPoBkAADwAT'
    'ACAAKAAtADEAABMhFSEVMxEjNSEVIxEzNSEFNSMVAyE1IyImNREjFRAHJwERFDMWOwERATYRNSMRITUhaAOA/uDokP4AiOj+'
    '6AHoUOACAAiASFCYSAGoGBAoCP4AYGACAP4ABkCQyPpggIAFoMjIyMj8oKhIaAF4aP6g2DgCaP6wOAgBkP3osAEAaPv4sAAE'
    'Aqj/SAegBoAAHwAjACcAKwAABRUjEQYHJxITFwYHISYnNxYXIRUhESEVIREhFSERIRUBESERAREhEQERIREECKA4OFDgYKAw'
    'OAFYMEiYWDABcP5oAWj+mAFo/pgBqPxoAVj+qAFY/qgBWDCIBIhYQKABQAFoOJCImHg4mLCY/viI/vCQ/viQBMj++AEI/nD+'
    '8AEQ/mD++AEIAAAEAfj/SAegBoAAHwAjACcAKwAABRUjEQYHJwATFwYHISYnNxYXIRUhESEVIREhFSERIRUBESERAREhEQER'
    'IREDmKBYWFABGHigKEgBaChQoFgwAcD+SAGA/oABgP6AAcj7+AGo/lgBqP5YAagwiASAgGigAWgBmDiQiJh4OJiwmP74iP7w'
    'kP74kATI/vgBCP5w/vABEP5g/vgBCAABAij/QAeoBngAHQAAASERMxEhFSESAQcAAxEhFSERIxEhNSERAgEnABMhAogCCKAC'
    'KP5AyAFIWP6w0AEg/uCg/ugBGLj+wHABSLj+YAUYAWD+oJj9qP7osAFIAoj9GIj+gAGAiALo/aD+kJABaAIoAAADAmD/UAeA'
    'BPAAHgAkACoAAAERNjcXBgcnESQlFwYHFBchFSEaATMyNjcXAiMiAAMBESEmJwYTFhcHJicDAGhgKKiYUAKoATiAoNgYAdD+'
    'SDDAMBBIGHhIqHD+8ED+MAG4EAi4wFgokChQAhj+CCAoiEgoWASQIHiAQCDQmJD/AP7gkIAw/ngBYAFoAbj+2JiwGPzwkLAw'
    'sJgAAwLw/0AHoAZ4ACAAJgAsAAABETcXBgcnESQlFwYHEhchFSESExYzMjY3FwIGIyInAgMBESEmJwYTFhcHJicDkLgooJBQ'
    'AogBIICY2AgQAaj+aCBoSDgYIAiIGGBQgGiQOP5oAZAQCKi4WDCQMFADSPzAQJA4IFgGSBhgiDAg/wDAmP5g/viouLAg/ri4'
    'yAEQAjACKP5wwOgQ+1iQsCiokAAABAJI/0gHmAZ4ABMAQwBHAEwAAAEhNTMVITUzFSEVIRUjNSEVIzUhFyEVIRUhERQGIyIv'
    'ARYzMj0BByYnBgcnNhMjFRQHFhcHJicGByc2ETUjESMRITUpARUzNRMWFxEjAkgBWKABWKABYP6goP6ooP6oKAUQ/oABYHBo'
    'OFAocDhIWEhYOGh4sAj4CFBIaCAoOGh4sNCYAWj+gAII+IBocMgF2KCgoKCQkJCQkMiQkPyoYGAQkAhQ6EBYYNB4YOABUCBQ'
    'QEhYUDAwwHhY2AEoIPxwBBiQkJD+MGB4AZAAAwQo/0gHmAY4ABEAGwAhAAABESMRIREjETM2NyE1IRUhBgcDMxACBgcnPgES'
    'FxYXByYnB0iY/mCg+BAI/rgDQP6oCBBwmEi4oGiQqDjYmJB4eKgFCPvwA4D8eAQYUFCQkFBQ/sj+AP7I+FiISOABCPiIwHi4'
    'uAAAAwNw/0gHmAY4AA8AGQAfAAABESMRIREjESE3ITUhFSEHAzMQCgEHJz4BEhcWFwcmJwc4oP4goAEQIP6IA6j+aBB4oFD4'
    '2GjI2EjgsLB4mNAFCPvwA4D8eAQYoJCQoP7I/fj+4P74WIhQ2AEI+Ii4gLiwAAACAFD/eAM4BngACgAfAAABFwYHIRUhBgcn'
    'EhMjNSEVIxEhFSERNjcXBgcnESE1IQF4kCAoAXD+SEhwcMiQiAHo0AEA/wB4YBiAuEj+8AEQBngwaGCQkHhoAQD+YIiI/tCQ'
    '/kgwOJBYQEgCMJAAAAIAUP94AvgGeAAJAB4AAAEXByEVIQYHJzYTIzUhFSMRMxUjETY3FwYHJxEjNTMBUJBAAVD+cEBgcKCQ'
    'eAHAsODgaFAYeKhI8PAGeDDIkJB4aOj+eIiI/tCQ/kgwOJBQSEgCMJAAAAIAUP94AygGeAAKAB8AAAEXBgchFSEGByc2EyM1'
    'IRUjESEVIRE2NxcGBycRITUhAWiYICgBcP5QUGhwwIB4AeDQAQD/AHBgGIiwSP8AAQAGeDBoYJCQeHD4/liQkP7YkP5IMDiQ'
    'UEhQAiiQAAQAWP9oBMAEOAAfACMAJwArAAABFwYHMyYnNxYXIRUhFSEVIRUhFSEVIRUhFSMRBgcnNgU1IRUBNSEVESE1IQGI'
    'kBgg+BgokDggAUD+mAFA/sABQP7AAWD88JgoMGDIAaj+4AEg/uABIP7gBCggQEBIQChQYIiAkICIgIh4AugwKHCwmICA/vCA'
    'gP74gAACAHD/SAegBoAALAAyAAATITUzFSEVIRUhAzMTIRUhEhc2ExcCBxYzMjcXDgEjIgMGByc2NwIDITUhNSElFhcHJie4'
    'AaCgAaD+YAIAEKAQAgD+CCA4cFCQeKBQSEAQiBhoWJhocKBYuHBgKPtwAej+YAXQcEiYQGgF+IiIiJABoP5gkP5Y8OABQDD+'
    'MPDo+Bj4mAEAkHh4kKgBOAIgkJD4eIBIkHAAAgBo//ADOAZ4ABUAGwAAARcCATY3FwQFJzYTBgcnNhMXAgc2NxMXBAUnJAKo'
    'kMj/AMioKP7w/rAwsKCImCC4eJhwqIBo6CD+4P6gQAF4BTg4/lj+4DA4gGg4iKgBACAQmOABgDD+sNgIEP0AkGhQqEgAAgBo'
    '/7ADKAZ4AAUADwAAARYXByYnAyERNxcGBycRIQGYiFiYUIigAbCoaHDAeP7oBnigsFiwoP4I/GC4YJiYaAOAAAACAGj/sALQ'
    'BngABQAPAAABFhcHJicDIRE3FwYHJxEhAZCAUJhIgJgBoGhgWJB4/vgGeKCwWLCg/gj8kJBYqJhoA4AAAAQBEAS4BuAGUAAD'
    'AAcACwAPAAABIREhNyE1KQEVITUzFSE1ARAF0PowmAEw/tABwAEokAEwBlD+aICYmJiYmAAEARAD8AboBkAAAwAHAAsADwAA'
    'ASERITchESkBESERMxEhEQEQBdj6KKABIP7gAbgBKJgBIAZA/bCIATj+yAE4/sgBOAAAAgJA//gE2AZoABMAFwAAATMRIRUh'
    'ETMRIzUhFSMRMxEhNSETESERA0CYAQD/AOCg/vCg2P8AAQDY/vAGaP6YkP6Q/UhYqAMIAXCQ/CgBSP64AAEAaP9IA1gGeAAk'
    'AAATITY3FwYHIRUhAgczETMRMxUjFTcXBgcRIxEFJzY3ESEnNhMjaAEAKCCQGCABQP6QUHDgkMjIuBhgcJD+kCDYuP6QIHhY'
    '0AV4eIggeGiY/vjAAQD/AIj4MJAgGP5IAZhAoCAgARCIyAEAAAYDGP8gB7AGOAADAAcAGQAdACEAJgAAASERITchNSEBIRUj'
    'ETcXBgcRIxEEBSc3ESMFITUhESE1IREkNzUhA9ADIPzgmAHw/hD+yARAkLgYaGiQ/oj+WBiwmAEwAfD+EAHw/hABCOj+EAY4'
    '/jCA0P5IiP1IEIAQCP7oAQgoIJAQAvigoP5ImP4wEBiIAAACAqD/WAeQBiAABQAXAAABFhcHJicRIREeASkBByEiJicHJic3'
    'ESMDgEAokChIARBI0AFIAThA/njg2EjAMDjQiAYgkKgwsIj9yPzQUECgYHDQUEiAArgAAwCI/1AHcALwABUAGwAhAAATITUz'
    'FSEVIREUBiMiLwEWMzI2NREhBRcCByckJRYXByYliAM4oAMQ/PBYgEhAIEhIKCj8yAG4kNDggAEAA/Do4IDI/vgCcICAmP5Q'
    'eGAIoAggQAGIUFD++JBwsLiQwIDAuAABBNAAqAdQBoAAGAAAATMRMxEhEAcGIyIvARYzMjYRIwIDJxITIwUQkJABIDAoiDAw'
    'IEBAKCCICOhwwAiIBVgBKP7Y/KC4mBCQCLAC0P0Y/tBoARACoAAAAQIQ/0gHqAaAAB4AAAEzEzMUByERFBYzIDY3Fw4CISAm'
    'NREjCgEHJxITIwKgeAiQCAEQQJABOEAQmBhAaP6g/wBggBiIgHjoGHAFEAFwyKj7eFgwMIAoeIAYYKAEAP3Y/cjQaAGIA0AA'
    'AAQAqAIAB1gGgAAiACgALgA0AAABFwYHIREzFSMVFAYjIi8BFjMyPQEhBgcnNjcjNSE2NREhNgEhESEVFCUWFwcmJxMWFwcm'
    'JwNoqCAgArDY2GBgOFgoYDhA/Eg4gIh4KOABABABaDD++AOY/HgBcGBQcEhoSGhgeFBwBoA4SCj+QIiwaHAImAhwgOCwaJiQ'
    'iFBQASBQ/fABMJBQwEBYWFBQ/ohIYGBYWAAAAQCoAmgHWAaAAB8AAAEXBgchFSEVIRUhFSEVITUhNSE1ITUhNSEmJzcWFyE2'
    'BWiwUFABqP0wApD9cAMI+VADAP1wApD9KAG4OFCIeFABcGAGeDB4WJiomKiQkKiYqJhYWFiAiHgAAwMA/2gHoAaAABQAJwAr'
    'AAABFwYHIRACIyIvATMyNzYRIQYHJxIFESERFBYzIDY3FwYHBiEgJjUREzMRIwQAmBAYAsBwmCAgKGg4ECD9qFhoeLACMP6o'
    'OOgBEEAIoCA4OP6Y/rBwoMDABoAoWFj8kP7ACJBIoAKY6JhwAQDw/bD+eCgQSJg4yEA4QHAD+P5AASgAAAEDaP9AB3AGiAAj'
    'AAABFwYHIRUhESERFAYjIi8BFjMyNREjESMRIxEjESERIwYHJzYEgJAYKAKg/nABkGhoKEAgWChA+JjwmAGIuEhoeMAGiChY'
    'WJD+wP0QYGAImAhQAjD7+AQI/NgDwAFAmHhg6AADA0j/QAdoBpAAFgAaAB4AAAERFAYjIi8BFjMyNREhESMRITY3FwYHAyER'
    'ITczESMHaHhwWGgokFBg/QCQARBIKKgoOKAB2P4okLCwBWD6wGBoEKAQUASA+ngGIICwKKBo/rj8mIACaAAAAgMA/0AHqAZw'
    'ACIAPgAAARcFFhc2NxcGBxYzMjY1Fw4BIyInBgcnNjcmJwUnJSc3FhcBIRUhERQWMzI2NRcOASMiJjURIwoBByc+ATchBvgQ'
    '/iAoKMB4WIioeFggKJAQYGCwsOjQWOjQQCD+6BgBECCgCBD+CARw/qggOFgooAhYwJBYqBC40GC4kBD+wAYQmGh4QGBwcHho'
    'aFhYILCAwHBAkEhgcGhAmDjgEHBY/NCY/lAgGCigMMhgSFAB4P7w/tBgkFjwyAACAyD/QAeoBngAKwAxAAABFwUTJRcFFhc2'
    'NxcGBxYzMhMXDgEjIgMGBSckNyYnBSclJicFJyUmNTMUFxMWFwcmJwcIEP4wEAIYEP3wGDiIcJCQsIBIKBCgKGhIkLDY/vBY'
    'ATDASCj+aBgBoBAI/tAYAUAIoAjYUFh4SGgFGJhQ/wBwmHCYmICoSOigyAEQSOiYASCQYKBoiJjgWJhYeJAwmDDQ+PC4AaBY'
    'eGBwaAADAEj/UAQABnAAFAAaAB4AAAEXBgchEAIjIi8BFjMyNhMhBgcnEgERIRUjERMzESMBcJAgKAJIcIBIaCBwUCgwEP4Y'
    'OJBwyAHY/riQkLi4BnAoeHD7WP6YGJgY4AQAsLhoASj+wP1IeAMw/dABsAAAAgBw/4ACmAYYAAUACwAAARYXByYnARcCAycA'
    'ASDAoHiguAFYkJD4oAEABhiQyJDYmP1YYP5o/oB4AWgAAgIY/0gHqAaIAA8AHgAAARcGByEVBgcnNjchBgcnEgUXFAcSAAUH'
    'AAMCASckAAPgmCAwAvhYeIhgQP2QaIh44AEomBhoASABCJD+cKh4/ih4AVgBGAaIKIiIkLi4SJCQ+LCAAUCYGKCI/tj+kJCI'
    'AQABqP5g/viAwAHgAAIAwP9IB0AGOAAHAAsAAAERIzUhFSMREyERIQdAmPqwmJgFUPqwBjj5EEhIBvD56AWIAAACBKj/SAeY'
    'BngAFAAaAAABIREzETMVIxEUBiMiLwEWMzI1ESEXFhMHAicEqAHIoIiIUHhYSChYWED+OKB4UJhAeATYAaD+YJj74HhgEKAQ'
    'YAP4iPD+6FgBGPgAAAEAgAUYB4gGeAATAAATITUzFSE1MxUhFSEVIzUhFSM1IYAB2KgCCKAB4P4goP34qP4oBhhgYGBgiHh4'
    'eHgAAgBwBMgHkAaIABAAIAAAARcGByEVIRYXByYnIwYHJzYlFwchFSEWFwcmJyMGByc2AbigGCAB4P74KBiYIDiQYHhw2AOw'
    'kDACOP7AMCCQMEiQQGCAuAaIIDgwgEBAMGBQaFB4iMAoYIBAQDBgUGhQaJAAAwJ4/5gHmAaAAAkAEwAZAAABISYnNxYXIRUh'
    'BRcCAyEVITUhEgESEwcCAwK4AgAwSKhQMAH4+1gDkLiQmAHA+uACsKj9+IAosCiABSCgiDigwJhIOP3I/mCYmAHwAfj+WP5Q'
    'MAHIAZAAAAIDiP9IB7AGeAAJACAAAAEhJic3FhchFSEFERQzMjY3Fw4BIyImNREhERAHJzYZAQPAAYgoQKBIKAGQ/EAC+DAg'
    'GAiICEiIeED+yOh40AU4kIAwkLCY2PxoSECgKMhwQGADMP6Y/ljggLgBqAGgAAAEAEj/cAeoAiAABQALAB8AJQAAARYXByYn'
    'JRYTBwInJTMRFBYzMjcyNjcXAgcGISMiJjUDFwIHJzYEGHhQmFBwAyiYYKhYkPwooDCImJh4OBCgMFBw/mBIqGj4iICIgKAC'
    'IJCwQLCIENj/AEgBCNBA/oAwKAhYmEj/ACAoWGABoFj+0LBw0AAABwK4/0gHsAZ4AA4AEwAgADEANQA5AD0AAAEXBwQFByYn'
    'FSE1BgcnAAchJicGATMRFAYjIi8BFjMyNQERFAYjIi8BFjMyPQEjESMREzM1IxEzNSMBMxEjBPCYIAEIAUBYcGj9eHCAUAGQ'
    'IAIgaMhoAeiQSGBgUCBgWDD+mFhgIDAgSCA48IiI8PDw8AHwgIAGeDAw+JCYOEhgYGBQgAEQsEDIkP6I/GhwUBCQEFgDaPxg'
    'WFgIiAhIsP54BFj+2KD+QJgBaP0gAAABAGj/SALYBoAAJQAAEzM2NxcGBzMVIQIHMxEzETMVIxU3FwYHESMRBgcnNjcRISc2'
    'EyNo4CAgkBgY6P7wSGCQkKCgiBhQUJCImCCwkP7gIGhQuAV4eJAggGiY/vjAAQD/AIjoIJAgEP5AAZgoGLAYIAEIiMgBAAAJ'
    'AGD/UAR4BkAAFQAZAB8AIwApAC8ANQA7AEEAABMhESEVIRUhFTY3FwQFJyU1ITUhNSE3MxEjFxYXByYnJREzEQcXBgcnNgEW'
    'FwcmLwEWFwcmLwEWFwcmLwEXBgcnNqADYP6QAVD+sMiYGP5o/hAYAZj+qAFY/qCA4OCIKBBoCCgBSOCAaCgoWCgBIFAwgDhI'
    'aEAYkBgwaCgQkAggyIA4QIhQBkD9QIiImBgYgEgoiCioiIiIAbhQkJAgoIho/kgBuEgguIAwmPxQoLA4uJAImLAwuJgIoKgo'
    'uJgYMMiQSKAAAgLY/0gHsAYYAAMAHwAAASEVIQMhFSERFBYzMjY3Fw4BIyImNREjCgEFJzYSEyEDqAOA/IBYBEj+wBgwSCgQ'
    'kBhokJBYwAi4/vhY4JgI/vgGGJj+cJj82CgYQJA40GBQaANI/ij+aKCIkAFgAZgAAAEAqP9AA1AGOAAWAAABFQMWFRQGIyIv'
    'ARYzMjY1NCcTIREjEQNQ2KiIiDBIIFhAODjA4P6gmAY4oP5AyNCgqBCoGFhQwMAB2PmoBvgAAAQASP9IA8AGgAAbAB8AIwAn'
    'AAABFwYHIREUBiMiLwEWMzI1EQAFJyQ3ITUzETM2AyE1IREhNSERITUhAdigGCgBiICAQFAoeDho/wD+gFgBkMj9yGDIMFgB'
    'uP5IAbj+SAG4/kgGgCBIQPowYGAQmBBQAVD+yLiIyOiQA4BY/niY/kCg/jigAAABAEj/OAegBngAKAAAEyE1MxUhFSERIRUh'
    'ESEVIREWKQEHISAkJwYHJxITFwYHFhcRITUhESHgASCgARj+6AFQ/tABAP8AqAKIAbAw/oD9oP5IkDBIiJBAkBggWGD+eAFg'
    '/uAFgPj4kP8AkP8AkP54SKCQsNiQgAEgAggYyKiAQALIkAEAAAEASP84B6AGeAAoAAATITUzFSEVIREhFSERMxUjERYpAQch'
    'ICQnBgcnEhMXBgcWFxEhNSERIdABCKABCP74AUD+8ODgmAKwAbAw/oD9oP5IkDBIiJBAkBggUFD+iAFA/vgFgPj4kP8AkP7o'
    'kP6YUKCQsNiQgAEgAggYyKhoQAKwkAEAAAEEOACYB3gGAAAYAAABESE1IREhERQWMzI2NxcCBwYhIiciJjURBmj90ALI/dgo'
    'sMhYEJggKEj+yPAIODgD6AGQiP1Y/hgoGDDYQP8AKDgIWFACoAAAAQBI/0ADaAZwACAAABMhJic3FhczFQYHFRYXNjcXBgcW'
    'FwcmJxEjEQYHJyQTIaABCDBAkEg4sGhwICBQMIhYUDgwaFBQmHhoYAFA0P5IBXhgWEBwiJDgqEggGGBoSIhQMDiIeFj82ANo'
    'gECQyAGoAAMAWP9IAzgGeAAWABwAIgAAEyERMxEhFSEVFhcHJicRIxEGBycSEyMTFhcHJiclFwYHJzaIAQiQAQD/AJhwcEhQ'
    'kFh4aMhg+IAwIHggOAI4eDhIcFAD8AKI/XiIqJiQmJBw/UgCwNi4gAEQAWACiLDQONioOCjwqEDAAAADAFj/QANwBngAFgAc'
    'ACIAABMhETMRIRUhFRYXByYnESMRBgcnEhMhExYXByYnJRcGByc2kAEgkAEY/uioeGhYYJBgkGjYcP7wgDgoeChAAmh4OECA'
    'UAPwAoj9eIigoJCYkHj9OALY4MCAAQgBaAKIsNA42Kg4KPCoQMgAAQBY/1gDSAZ4ACAAAAEXBgchFSMGBzMVIwYHFhcHJicC'
    'BycAEyE1IRMjBgcnNgE4mBgoAXCwCBDo8AgQsIBwcHBI0IABCCj+4AE4EFhIUHCYBngocHCY2LCYWFCooJioiP7Y4HABIAHQ'
    'mAGIqHh46AAAAQBY/0gC8AaAACQAAAEXBgcSERACIyIvARYzMhIRNCcGByc2EyYnBgcnNjcmJzcWFzYCaIhQiIiIiEiAKIBw'
    'ODgIkMBQ4KgYIJBgYICAWICIaFBoBoBQoKD+4P5Q/pD+mCioKAEYARhISPiQmKABOHhokDh4WJCQgEhoeHgAAQBQ/0gHqAaI'
    'ABcAAAEXBxIABQckAAMGBxEjEQcREAMnEhkBJAPIWHgYAYgCYEj9kP5AIDhAmIi4cJABsAaIiDD8mP3oWLBoAmgDkBAI+bgG'
    'MBD9gP4Q/lhoAZABoAMIEAADBGgBsAewBigAEQAVABkAAAERFBYzMjY3Fw4BISAmNREhEQEjETsCESME+DDA8DgImCBo/sD+'
    '4GAC8P5AoKCIoKADiP7wKBAoaDigSEBwA8j9YAIY/nABkAABAFD/SAIgBngACQAAARcGBxEjEQcnEgGAoDBImHBQ0AZ4MMDA'
    '+oAEEMigAZAAAwPY/0AHqAY4ABIAIwAoAAABERQ7ARUjIiY1ESECBgcnPgERAyECAxYXByYnBgUnNjcmAyMzFhc2NwbIOHig'
    'WFj/AAhYYGhYOHgDGBjQaPhYwMCo/wBQ4KCwQFDoSIh4KAY4/iBYiFBYAYD+2OBYeFjYAVD84P6I/wBYaKBQmJBYmEiAyAEg'
    '4Jio0AADBKD/SAdwBlgAFAAYAB0AAAERFAYjIi8BFjMyNREhAgMnGgEZARMzESMRMxEjFQdwUEhQeCCIOCj/ACCIkGBQkPj4'
    '+PgGWPmwWFgYmBgwAej+gP7AWAEIAZABIAMA/iABUPzQAVDAAAMDyP9AB1AGWAATABcAGwAAAQIDJxIZASERFAYjIi8BFjMy'
    'NREBESERAREhEQUQKKCAwALIWFhQeCB4UDj+aAGY/mgBmAII/oD+uGgBaAHIA4D54GhwCJgIcAGgA8D+sAFQ/iD+sAFQAAAC'
    'A3D/UAeQBngAFQAbAAABIREzETMVIxEUBiMiLwEWMzI2NREhFxYTBwInA3ACkKDw8FhwgHgggIAgIP1w6JhooGCQBNgBoP5g'
    'mPvoeGAgqCggQAPwiPj+4EgBMPAAAwKwAFgHkAZ4ACcAKwAvAAABITUzFSERMxUjESEVIRUhFSEVIRUjNSE1ITUhNSE1ITUh'
    'NSE1ITUpARUhNQEVITUDYAFgmAG4gID+SAHI/jgCOP3ImP3wAhD+UAGw/pgBaP4IAfj+oAH4ASD+4AEgBeiQkP7wkP7wiIiQ'
    'mKiomJCIiIiIkIiIiP7oiIgAAAICQP9AB6AGeAAqAC4AAAERMxEhFRQGByc2NyERIQIBFgUHJicGBSc2NyYnNxYXNjchFRAB'
    'JzYSNRETIREhBOigAeBQKJg4KP7QAaAo/vioAQB48LjA/wBQ8KiYcHhwmLgw/Xj+8JCYeJABCP74BXgBAP8AkAjYWDCAgP54'
    '/oD+4HhomHCYmGCYUICQ0FjIiMDoMP4o/ohY4AFg+AKg/eABiAAAAgMA/0gHmAYYAA0AEwAAASEVIQcRIxECAycAEyEBFhMH'
    'AgMDOARY/kAwoLDQgAFA8P4IAwCwsHiYwAYYmJj6YAQw/qD/AHgBcAKA/ljw/rh4ATgBKAAFAoD/SAeYBjAAAwAHAAsAJAAq'
    'AAABIREhEyE1IREhNSEBIRUjFSEVIREUBiMiLwEWMzI1ESE1ITUhExYXByYnAzgDyPw4mAKY/WgCmP1o/vAEsOABCP74SHBw'
    'WBhwcBj8kANw/NDogEiISHgGMP14AYCA/oCI/miIkJD+oHBYGJgYSAFIkJD+oICIUIiAAAABAIj/SAM4BngAGAAAAREUBiMi'
    'LwEWMzI1ESMRIxEjESMRIREzEQM4WFgQGCAwECiIiICQARCIBUj8YFhYCJAISALg+pgFaPw4BGABMP7QAAcCaP9IB7gGUAAD'
    'AAcACwAPABMAFwAtAAABIREhNyE1IQEhESE3MzUjJSERITczNSMBITUzFSEVIRYFByQDESMRBgUnJDchA2ADWPyooAIY/ej+'
    'yAII/fiY2NgB8AII/fiY2Nj80AIYmAIw/ijIATBQ/tjYmMD+wGgBONj+QAZQ/mCIkP54/kiIsID+SIiw/jBgYIjoaJiIAQj+'
    'OAHA4JiAgNgABwKA/zgHmAaAABMAFwAbAB8AIwApAC8AAAEhNxcHIRUhByERMxUhNTMRITchATUhHQIhNRUhFSEVIRUhBxYX'
    'ByYnJRcGBSc2AxgB6BioGAHA/iAYAbB4+0hwAXgY/jgDaP1wApD9cAKQ/XACkJjQyFjI2P6wgMD+6GDwBfCQGHiIgPxIiIgD'
    'uID+iHBweHBw6HCAcLBAeJCQQHhogFiIQAAAAgMw/0gHmAYIAAMAFAAAASEVIQMhFSERFAYjIi8BFjMyNREhA4ADyPw4UARo'
    '/thYkIBoIICIQP1oBgiY/pCY/LBwYBigGFADMAABAoj/SAdABhgAFwAAASEQAgYjIi8BFjMyNhIRIREQAScAGQEjA4gDuDig'
    'oEhAKFhYWFAo/lj+IIgByMgGGPyY/VCgELAQYAKAApD+CP1g/mBwAZACQAH4AAABBNj/SAdYBgAADwAAASERIxEhERQGIyIv'
    'ARcyNQa4/sCgAoBQUFB4KMAwBWj54Aa4+whYWAiYCDgAAgBo/3ACGAZAAAUACwAAARYXByYnARcCAycSARiYaJhYoAEIiGCw'
    'oLgGQLjgWNjA/NBY/nj+mHgBWAAAAQCYBIgHaAYwAAcAAAERIxEhESMRB2ig+nCgBjD+WAEg/uABqAABAFD/SAJIBngACgAA'
    'ARcGBxEjEQYHJxIBqKAwSJhIUFDwBngwuLD6aARIkHCgAZAAAAQCeP9IB5gGeAAXACgALAAwAAABITUzFSEVIRUhFSEVIRUh'
    'NSE1ITUhNSEBERQGIyIvARYzMj0BIREjERMhNSERITUhAsAB6KACGP3oAdj+KAJQ+uACMP5oAZj+GARAcGhIWCiAQED9SKCg'
    'Arj9SAK4/UgGAHh4iICIgIiIgIiA/XD9IGBgEJgQUDj+4AOg/wCA/oCAAAEAcAVgB5AGgAAJAAABFhchFSE1ISYnBCBAIAMQ'
    '+OADUBgoBoBIUIiIODAAAQBwBRgHkAaAAAkAAAEWFyEVITUhJicEGEAgAxj44ANAGCgGgGBwmJhYQAACAFD/aALwBhgAFAAY'
    'AAATIREjFTMVIxE3FwQFJzcRMxE3ESM3IREhsAJAuKiomBj+8P6wOGCYYPiYARD+8AYY/YD4kP6IMIh4YKAYAsD9aCADMJAB'
    'YAAABAOA/0gHqAaAABcAHQAlACkAAAEXBgchFQYHFhcHJCcGBSc2NyYnBgcnNhcWFzY3IQERIzUhFSMREyERIQSwoBggAghw'
    'qMDgSP8A0Lj+4DjoqGBQOEhg0GBgeJBQ/nACQJj+AJCQAgD+AAaAKFBIkPigeEiYUJiQWJBIeGiASEBw4EiQcJCo/Pj9IHBw'
    'AuD+IAFYAAIAUP9oA5gGGAAUABgAABMhESMVMxUjESUXBAUnNxEzETcRITchESHIApDY2NgBABj+oP5QOHiYkP7YmAFY/qgG'
    'GP2A+JD+eECIeGCgGALA/WAgAziQAWAAAAEAaP94A1gGGAAVAAATIQIDFhcHJicCByc2EwIDNxYXNhMhgAKYIHBwYIBIUJDo'
    'YPh4oLB4kIg4GP4YBhj96P54wNB4oJj+oNCI2AGQARABAFjI0NABcAADA5j/UAeoBkgAGAAcACAAAAERIRYXNjcXBgcWFwck'
    'AAMjETY3FwYFJxEXFSE1ARUhNQcI/ngoSIhwgGi4eOh4/vD/ADiwwJggwP7wSKACMP3QAjAGSPxwwIBgiGiQeICImKgBeAFI'
    '/VA4QJhYQEgGsJjo6P6A4OAAAAEAUP9IA2AGcAAfAAABFhchFSEDIRAHBiMiLwEWMzI2EyMCAyc2EhMjNSEmJwHoQDABCP5g'
    'CAGASDCYOEAgSEBAKCj4GMiAaGAImAEoKDgGcIigmP74/RjYoBigGIgCoP2A/rhwsAHYAnCYiHAABAIw/0AHoAaAABsAIwAz'
    'ADcAAAEWFyEVIQIHJCUmJzcWFwcmJwQFJzYTITUhJicDFwoBByc2EgEzERQzMjc2NxcOASMiJjUBMxEjBOBQOAIQ/WCImAEw'
    'AUg4QIiwaJAgKP5Y/iAowJj+kAIAKEDgmAigsICoiAKAmCBACCAImBhgkHBI/sCYmAaAaICQ/viAEDhYUFjQ6FBIQEAYgJAB'
    'CJBgWPxgIP6o/pCIgIABMAEg/aBAEBiAQLBQSHACePzAAAABAEj/SAKYBngAFQAAEzMRMxEzFSMVFhcHJxEjEQYHJxITI3Dg'
    'kJCQaFBoUJBAWHCwOMAFAAF4/oiQcIBwkKj8IAOw+KhwATgBcAAAAgQw/0AHoAaAABIAGAAAASERMxEhFSESAQcCAwIHJwAT'
    'IQEWFwcmJwRgASCYAVD+0FABGHDQcFD4eAEwGP7oAnhgQIg4YARQAjD90Jj9gP6QiAEoAcj+CPhwATgC0AKAgJhIkIAAAgNY'
    '/0gHYAZwABYAHAAAARcGByEQBwYjIi8BFjMyNzYRIQYHJxITFhcHJicEuKAoQAJwSDjQaJAoyFhgGDD96GBwePCweFCYUHgG'
    'cCCYkPvg+MggqCBw2ANYqHBwAQj+aLDYSOCwAAAEAuD/SAewBngAKAAsADAANAAAASE1MxUhNTMVIRUhFTMRIQYHIRUhFgUH'
    'JAMCBSckNyE1ITY3IREzNSEFITUhAyE1IREhNSEDIAEYmAEYmAEY/ui4/mgIEAIQ/kiIAUhY/pCYiP5YQAF4YP5gAdAYCP54'
    'uP7oAbABGP7ouAKI/XgCiP14BeCYmJiYkJj9cEhIkNBQoHgBKP64UIhg0JBAUAKQmJiY/mCA/oCIAAADAGj/SAPQBoAADwAa'
    'ACAAAAEzFTMVIxEhFSE1MxEzETMHMxE2NxcCBSc2NwMXAgcnNgIQmODgASj8uICYcBCYYDiYyP3gQNCQ4JBYaIh4BoD4iP8A'
    'iIgB6P4Y8P5IiLg4/bjQiEiIAkAw/uC4SOAABgMQ/zgHaAaAAA8AEwAqAC4AMgA2AAABERADJzYZASEmJzcWFyERARUhNRMR'
    'FAYjJzI3NjURIxEjESMRIxEjESMREzM1IxczNSMXMzUjBABYmGABmCAwoEAgAYj8wAKwuHCYIIgIGGhwaHhogIBoaOBoaNho'
    'aAO4/kj+OP8AOPAB0AN4WEg4aHD+EAFo4OD9+PzQaDiACAgwARj+4AEg/tABMP4oA9D+kPj4+Pj4AAACA+D/QAeoBngAFwAg'
    'AAABIRUjAgMWFwcmJwYHJzY3JicHJxITFwYTIQYHEhc2EzUFWAIYWDCwkOB4uKCg6HDwoHBgQIDIWKAg+P64CDBgeGgwBSiY'
    '/dD+4MCgmJjQ2JiQkOjA8IhgAagCADCY/uAokP7g0OABQAgAAAIEwP9QB6AGcAAYAB8AAAEXBgchFSMCBwMWFwcmJwYHJzY3'
    'JgMHJxIXEhc2EyMUBaCQGCABoFgYKFhgmHB4YGiYaKhoUEgweKBgOFBIGNgGcDCQiJj+6OD+wNCokJDI0IiIkPjQARB4WAGQ'
    'cP7Q4PgBaAgAAwRA/1AHqAZoAAUACwARAAABFwIFJyQTFwIFJyQFFwABJwAGoJDQ/oBoAYDImMj+eGgBYAEQmP74/ghoAegG'
    'aFD+sOCI+P7oWP7I2IjQ8Fj+cP7oiAEgAAQDIP9IB6gGeAAXAB0AIwApAAABFwYHIRUCBxYXByQnBgUnJDcmJwYHJyQXFhc2'
    'NyEDBAUHJCUHBAUHJCUEsKAYKAHgaKDg4Fj++NjY/uBYARC4eFhAQHgBCFBoeJBQ/ogYASABAEj+8P7wmAH4AVhg/rD+GAZ4'
    'IFBQkP7wqIhAmGCQqFCQSIhocEA4cOBggGiQwP0YWHCgiFCIkLiQuJAAAAEAWP9IA2AGaAAdAAABFwYHESEVIRUWFwcmJxEj'
    'EQYHJxITITUhEQYHJyQC8Eh4iAEo/tiIYGhAQJBgeHjwUP7oASh4eDgBUAZoiCAY/rCQOJCIkHhg/IgC+PCYeAEYAYCQATAY'
    'EJgoAAAEAyj/kAeoBjAABwALAA8AEwAAAREzFSE1MxETIREhESERIREhESEHEJj7gLCYAgj9+AII/fgCCP34BjD5+JiYBgj9'
    '+AF4/IgBePyIAXAAAAEAaAAYAvgGEAAWAAATIRUjETMVIxE2NxcEBSc2NxEjNTMRI2gCaODQ0IBwGP7o/qggeHjg4PAGEJj+'
    'MJj+KDg4kJhooCAoAhCYAdAAAAEAaP9IA1gGeAAUAAABMxEzETMRMxUhESERIxEjAgMnEhEBAJDYmFj+OAGAmOgYkICYBlD+'
    'GAIQ/fCQ/rj8uAK4/lD/AGABIAGgAAADAGj/SALQBnAABQALABEAAAEWFwcmJxMWFwcmJwEXAgMnEgFQ0LBwuMgQwKhwqMAB'
    'aIiA8JjwBnBoiIiYcP6QYICIkGj+aGj+iP6gcAFYAAEAYP9IAlgGgAAeAAATMxEzETMVIxE3FwcRFAYjIi8BFjMyNREGByc2'
    'NxEjaNCQkJBwGIhAcEg4GEhQIFBQOHBo0AUoAVj+qJj+yECIaP1QYFAQiBBAAkAwKKAwOAGQAAIAWP9QAvgGeAATABkAAAEz'
    'ETY3FwYHERUWFwcmJwIDJwARAxcCByc2AWCQWDCAcJhwWGBAQDjQeAEIsIAQUHhABnj+OFhgYJhw/wB4WFiIUED+cP8AYAFQ'
    'AgAB6CD+uPhI8AAGAoD/SAe4BkAAHwAjACcAKwAvAFQAAAEhESMVIRUhFSEVIRYXByYnIQYFJzY3ITUhNSE1ITUjEyE1IREh'
    'NSEBNSEdASE1IRMzFRc2NxcGBwUHJicVFAYjIi8BFjMyPQEGByc2NyYnNxYXNjcDSAOouAEg/uABYP7YeNBo+Ij+sKD/AGCw'
    'qP6oAXD+4AEgqJACgP2AAoD9gAHQ/tgBKP7YWJBQOCh4MDABCGiwuEhwODAgQEgo0Pg4qJAgMHgwICgoBkD96Hh4eIiAcICo'
    'yPCIgFCoiHh4eAFIYP7IaP6weHjweP6w2CA4OEhAKKCAkHCgYEgIiAg4cHBgiDhAODhIOEgQGAAAAwNA/2AHqAYgABIAFgAa'
    'AAABIREhERQWISA2ExcCBwYhICY1ASERITMhESEDQAP4/KiIAQgBGGgYoCBoSP6Y/oCwAbD+8AEQmAEQ/vAGIPyA/bgoKGAB'
    'CDD+qFA4WGgFaP2wAlAAAQSA/1gHqAK4ABUAAAEzESQ3FwQFFRQWMzI2NxcOASMgJjUEgJgBGPBg/uj+sFjYeEAQmCB4yP7Y'
    'oAK4/uhIaIhwSPAgGEigQNBoUGAAAQSAAwgHiAZIABUAAAEzESQ3FwQFFRQWMzI2NxcOASMgJjUEgJgBCOhY/vj+wFDQaEgQ'
    'kCB4uP7gmAZI/vBQWIBwSNggIFCQQMhgUFgAAwDw/0gD0APQABAAFAAYAAABERQGIyIvARYzMj0BIREjERMhNSERITUhA9Bo'
    'YFh4IJhQMP5goKABoP5gAaD+YAPQ/EBYYBCQEEiw/mgEiP7AsP4gsAABAIgEEARQBoAAEQAAARYXByYnBAUnNhMXAgc2NyYn'
    'A0igaIgYIP6o/ngo6KCgmIDQ2DhABfjA2FA4ODgYiJgBMDD+6GgQKFBQAAIAUP9IAwgGeAAUABoAAAEzETY3FwYHFRQHFhcH'
    'JicCBycAEQMXAgcnNgGAkFAweGCYKJhwaGBgWKCAATDIkBhQiEgGeP5gYGhgoIBQ6NComJiwiP6o2GgBqAJ4ARgg/rj4UOgA'
    'AAEDAP+QB5gGGAAYAAABIRUBBhUUFiEzMjY3FwIGKwEgJjU0EwEhAyAD8P0oiGgBMJioUBioIKjw0P64yMgCcPzoBhiA/CDA'
    'YEAwcOAw/tCIeJCAASADSAADAGD/UAJwBmgABQALABEAAAEWFwcmJxMWFwcmJwEXAgMnEgEgmIBwiJAgoIhwiKABiIiA6Jjo'
    'BmhQcIB4WP6AWHCIiFj+iFj+gP6YcAFYAAEAaAOYB5gGeAAXAAATITUzFSEVIRUhFSEVIRUhNSE1ITUhNSHwArigAvD9EAKw'
    '/VADUPjQA0D9iAJ4/UgGCHBwiHCAcIiIcIBwAAABAFD/SAdoBoAAEAAAARYXIRUhERADJzYSGQEhJicEUDAgAsj6UNCYcFgC'
    '2BgoBoBIYJD9kP4A/nBg6AF4AQgCyEA4AAMCKP9IB7AGgAAnACsALwAAASE1MxUhETMVIxEhFSEVIRUhFSERIxEhNSE1ITUh'
    'NSE1ITUhNSE1KQEVITUBFSE1AsABwJgB8JiY/hACOP3IApj9aJj9qAJY/igB2P44Acj9yAI4/kACWAFY/qgBWAXgoKD+yIj+'
    'wKCIoJD+wAFAkKCIoJioiKCgoP7YqKgAAAQDCP9IB1gGOAAUACQAKAAsAAABERQGIyIvARYzMjURIREQAycSGQETMzUzFTMV'
    'IxUzFSE1MzUjEyERITczNSMHWFhYWIggiFg4/Uh4iHDguJi4uNj9yMi4EAHw/hCQ0NAGOPngYGgQkBBoBWD9aP3Y/mBQAaAC'
    'CAL4/nioqIioiIio/lD+GIjYAAMCwP9IB1gGeAAPABMAFwAAAREjNSERIxEhFSMRIREzEQEhESkBESERB1ig/qCg/qigAfig'
    '/ggBWP6oAfgBYAUI/GCQ/VACsJADoAFw/pD9iAHg/iAB4AABAvD/cAegBngALQAAARACIyIvARYzMjYTBREjEQcRFBYzIDc2'
    'NxcOAiEgJy4BNREHJzcRMxE3ETMRBzhwcChQEEAoKCgI/wCguDjwATBAGBigIEjA/uj+2BBISGhAqKC4oAUg/Vj+4BCgCMgB'
    'gGD9CALAQPzYKBgoGOhI6GgoCAhQUAMQIJA4Ahj+IEgCIP4YAAEAWAB4AqgGWAASAAATMxEzETMVIxE2NxcGBSc2NxEjcMiY'
    '2NhoUBj4/tAgeGjIBKABuP5ImP2IKCiQgFigICgCqAAAAQBYAHgC2AZYABEAABMzETMRMxUjETcXBAUnNjcRI3DomOjoyBj+'
    '8P64IIh46ASgAbj+SJj9iFCQgFigICgCqAAABABQ/3AHqAHgAAUACwAfACUAAAEWFwcmJyUXAgcnNiUzERQWMzI3PgE3FwYH'
    'BiEjIiY1ARYXByYnA8iwkHCYoP3oiHiAiJgBWKA4gJiYiCgQoDBQcP5gSKhoBFCocKBgqAHgYIiImHAwUP7goHjA0P64OCAI'
    'CEh4QOAgIFBYAYjA6FDg0AABAFD/SALgBngAFgAAEzMRMxEzFSMVFhcHJicRIxEGBycSEyOQ2JjQ0IBgaDhAmEBocMhAyAUI'
    'AXD+kJhouKiYmHj8KANI2MBwAVgBsAABAGj/SAPoBhAAFQAAEyECAxYXByYnAgUnJBMCAzcWFzYTIYgDACCIkHiAYHCo/thg'
    'ASiYwNh4uKhIIP24BhD96P540NCAuKj+eOCQ4AGgARgBAGDY4MgBkAACA5j/QAeoBhAAEAAVAAABIQIDEhcHJgMCBSckEwID'
    'IyESExITA9ADeDD4mPBY6Kio/uhoASig2FhgAQBAsKAwBhD9cP4g/wDAoKgBGP8AuJC4ARgBoAIo/mD+iAFgAbgAAAIFWP9I'
    'B1gGcAAMABAAAAEzERQGIyIvARYzMjUBMxEjBrigWGiQgCCQiDj+oKCgBnD5qHhYIKAoYAVg+3gAAQBg/0gHWAOQACIAABMh'
    'FSERIRUhERQGIyIvARYzMjURIwAFJyQTISc3FwYHIREh6AYw/pABsP5QWJCIcCCQiEjA/tj9iEgCMPj9yDiIkCgwAzD74AOQ'
    'iP74kP6QaFAgmChIAVD+gKiYkAEAgMgoSEgBCAADAKgDyAdYBogADQATABkAAAERIzUhFSMRISYnNxYfAQQXByYnJRcGBSck'
    'B1io+pigAxggKKBAIFABANhw0Pj+0GjI/tBYAUAF2P6g0MABUEg4MFBgwFiAeIBYeHCIUIhQAAECcAKgB4gGgAAaAAABMxUh'
    'ERQzMjY3Fw4BIyImNREjAgUnJBMhNSEEEJgBgGBAKAiQEGiAmGjwKP5IUAFoKP7gATAGgND96DBImCDYeDhAAdD+QMCIoAFY'
    'kAAAAwCYAngCuAaAAAUACwARAAABFhcHJicHFhcHJicFFwYHJzYBcKiQQKCYWJiISIiQAbBwmOhw6AaASGCQeECYQFiYeDiI'
    'UNjAcMAAAAEAYP9AB6AC4AAVAAATITUzFSEVIQAFByQBESMRAAUnJAEhiAMgoAMo/UgBKAHAWP4g/uCg/vD+MGgBuAEY/VgC'
    'SJiYkP7wgKiwAVD9wAJA/sjAiKABCAADALgDcAdABmgAAwAJAA8AAAEzESMBFwIHJzYBEhMHAgMDqKio/liQoLiAyAR4yICY'
    'cMgGaP0wAlhI/pDIcPABIP8A/uBYASABAAAAAQBo/0gHmAMgABQAABMhNjcXBgchFSESBQckAwIFJyQTIXgDEBgQqAgYA1D9'
    'CNgCMGD9wPiw/WBIAliY/SACcFBgGFBImP6ogLigAcD+MJCocAF4AAABAoj/kAegBhAAEwAAASEVIREhFSERIRUhNTMRMxEh'
    'ESEDEARo/jABkP5wAfj66MCgASD+CAYQmP2gmP2omJgD6PwYBVAAAgBo/0ADSAZ4ABYAHQAAARcDIQIDFhcHJicGByc2NyYn'
    'EhMjNTMTEhMjAgcWAZiQOAE4GKBwaIhIWLCoYLiQeJBQOMjwoHAYsEBAWAZ4IP64/aD+kICIaHho+HiIgPCQgAEQASCY/LgB'
    'CAGo/ujoWAAAAQBg/0gC2AZ4AB8AAAEXBgcRFAYjIi8BFjMyNREGByc2NxEjNTMRMxEzFSMRArgYYHBIYFhYIFhgIGBgQIh4'
    '4OCg2NgDKJA4MP3weGAYqCBgAaAgKKgoMAHwmAFQ/rCY/kgAAAEAeANIB4gGgAAVAAATITUzFSEVIQAFByQBESMRAAUnJCUh'
    '8ALAoALA/bgBGAGoUP5A/tig/uj+SGgBsAEA/cgF6JiYkP8AcJigATD+WAGo/tiwiJD4AAABA8D/UAeYBlgAFAAAARcEBREh'
    'FSMRIxEhCgEHJzYSGQEkB0BQ/vj+mAJ4wJD+2AhocIBoYAGwBliISCj+kIj7+AQI/iD+aKBokAGoAigByCgABABY/0gEMAaI'
    'ACgALgA0ADoAABMhJic3FhchFSMGBzMVIRUhFSERFAYjIi8BFjMyNREhNSE1ITUhJicjATM2NyEWAxcGByc2JRYXByYnsAFg'
    'IDiQQDABaFhAUPj+eAFQ/rBQeFBAIFhYKP6gAWD+eAEQKEB4AXCIQDj+oDi4gHCIcJACaHBIgEBwBchQSChYaIi4kIjIiP3o'
    'cFAYmCBIAgCIyIiwmP64mLCY/SBA+IBgmLiAkEiQgAAAAwLY/0gHqAZ4ABkAHwAuAAABISY1MxQXIRUhEhMWMzI2NRcCBiMi'
    'JwIDIQEWFwcmJwEhFSMRNjcXBAUnNjcRIwMYAjAIoAgBsP5YEGg4ICAgqBhoWHhQkCj9yAOYWDiIMFj86AIIuIhwGP7g/qAg'
    'gHi4BRiouMCgmP3A/qDgqKg4/ui42AF4AugB8GhwUHBo/TiI/fAoKJBwSJggGAI4AAUCaP+QB5AGcAATABcAGwAfACMAAAEh'
    'NTMVIRUhFSERMxUhNTMRITUhASE1IREhNSERITUhESE1IQLQAfCgAfj+CAGYmPrY4AF4/hABGAJw/ZACcP2QAnD9kAJw/ZAF'
    'uLi4kLj7qIiIBFi4/iiY/lCg/lCY/liYAAEAoP9IAvgGMAAWAAABFQMWFRQGIyIvARYzMjY1NCcTIREjEQL4wKh4eDBAIFg4'
    'MDCwuP7YkAYwkP4g4NigoBCgGFhQ0NAB+PmoBugAAAMCcACoB3AGKAAJABMAHQAAARcCAxITBwIDEgEXAgMSEwcCAxIBFwID'
    'EhMHAgMSA5CYeJCYcJhwsKgCCJhwkKh4mHjAoAIQmHiIqHiYgLigBig4/pD++P7Q/rBQAYABSAFAAXg4/pj++P7Q/rhQAXgB'
    'QAFAAXg4/pj+8P7Q/rBQAYABSAFAAAABApD/OAeYBngACwAAASERMxEhFSERIxEhApACOKACMP3QoP3IBAgCcP2QmPvIBDgA'
    'AAEAsP9AB1ACsAAhAAATIRUhByERFAYjIi8BFjMyNjURIREjESERIxEhESMRITchsAag/MAwAyhoaDBIIEAoSBj+0KD+0KD+'
    '2KACSCj9QAKwiIj+SFBYCIgIGDABEP5YAaj+WAGo/jACUIgAAAEAmARYB2gGiAANAAABFhchESM1IRUjESEmJwQQOCADAKD6'
    'cKADICgoBohYaP6Q4OABcFBAAAIB0P9IB4gESAAjACgAAAEWFyE2NxcGByEVIREhFSERIxEhAgUnJDchNSE2PQEhNSEmJwER'
    'IR0BA2BoSAFgQDCoMDgBMP7AAXj+iKD+eEj+gFABIFD+wAFgCP7AASgwSAKY/pAESHCAeHgwaFiQ/viY/iAB4P6IWKBA8JhI'
    'UHCQWEj9yAEIcJgAAAIAUP9AB1gGSAAKAA4AAAEREAMnNhIZASERAyEVIQGwyJhoWAZIoPr4BQgEQP7g/dD+UGD4AYgBKAMA'
    '/fgBgPAAAAIAUP9AB1gGSAAKAA4AAAEREAMnNhIZASERAyEVIQGwyJhoWAZIoPr4BQgEeP6o/dD+UGD4AYgBKAMA/jABSLgA'
    'AAIDCP9IB6AGeAAjACkAAAEXBRYXNjcXAgceATMyExcCIyImJwYFJzY/AQIDBSclJhEzGwEWFwcmJwdgEP3wGDiQcJiQ0ECA'
    'IDAQmCiwQMBY6P7QUNiwoFAo/ogYAYgQoBC4oIBwgJAE0JhQ+OCo8DD+wNigsAEIKP5Y0NDIiJBggIgBAAFAOJg48AEg/ggB'
    'wGB4gIhYAAEAUP9IA0gGeAAdAAATIREzETMVIxE3FwURFAYjIi8BFjMyNREFJzY3ESFoASig+Pj4IP7oUGCAcCB4gCj++Dio'
    'mP7YBSgBUP6wmP5gaJCA/dh4YBioIGABwGCoMDgB2AAAAQOY/0gHmAYgAA8AAAEhFSERIRUhESMRITUhESEDuAOw/ngBuP5I'
    'mP5QAbD+cAYgmP24mPygA2CYAkgAAgBo/0ADeAZ4ABYAHAAAARcDIQIDFhcHJicGByc2NyYnEhMjNSETEhMjAgcBuJBAAUgg'
    'qHh4iFBgsMhgwKCAmFBI4AEAqHggwEBIBngg/rj9gP6wgIhoeHD4gIiA+IiAAQgBKJj8uAEAAbD+6OgAAAECOP9wB5AGaAAt'
    'AAABEAYjIi8BFjMyNhMFESMRBREUFiEyNz4BNxcCBwYhIyAmNREHJzcRMxElETMRBxhYYEhQIEhIGCgI/riQ/uBwATiIkGBA'
    'EJgoUGj+gID+8KiYKMCQASCQBPD9SOgQqBC4AXhQ/RACyEj8+DAoCAhIsED+8CAwWGADICiAOAHQ/lhIAiD+CAACBAD/UAeY'
    'BngAFAAaAAABIREzETMVIxEUBiMiLwEWMzI1ESEXFhcHJicEAAIwoMjIUHiIcCCAgED90MiIWJhQiATYAaD+YKD78IBYEKAQ'
    'YAPooMjgWODIAAABAFD/SAMQBngAFgAAEzMRMxEzFSMVFhcHJicRIxECBycSEyOQ8Jjg4JBoaEhImFBwcNhI4AUIAXD+kJhg'
    'uLCYoHj8IANg/viocAFQAbgAAAUAaP9IB5gDgAAQABQAGAAcADMAABMhFSERNxcHFSM1BAUnNxEjBSE1IREhNSERJTUhJRYX'
    'NjchNSEVBgcWFwcmJwYHJzY3JidoBzD8OGgYgJj+wP6IGKCgAUABkP5wAZD+cAGQ/nADCGiQgED98ALAYJCoyEjguJDIOJh4'
    'eGADgID9sBCQENjAMCCYEAKgiIj+eJD+YDBw2KhwkKiQkPCgWDiYQHhwSIg4WHCYAAMBWAPwBqgGQAADAAcACwAAASERIRMh'
    'NSERITUhAVgFUPqwoAQY++gEGPvoBkD9sAFoaP64aAAAAgWI/0gHYAZ4AAwAEAAAATMRFAYjIi8BFjMyNQEzESMGyJhIaIBo'
    'IHCAMP7AmJgGePmoeGAgqChgBWD7cAACAFD/SAJoBngABQAQAAABFwIHJzYfAQYHESMRBgcnAAG4iJDoYOCYiEBgmEg4YAEQ'
    'BnhI/sDIgNDASKCg/BgDEFg4iAEgAAACAFj/SAJYBngABQAQAAABFwIHJzYTFwYHESMRBgcnJAG4iJDoYOCIiDhYmEA4YAEA'
    'BnhI/sDIgND+6Eh4gPwoAyhIKIDgAAABAsj/QAe4BngAIwAAARcGBxoBEwcKAQMGBxE2NyYnNxYTBycGBycRBxEQAycSGQEk'
    'BqB4UFgYmJhwoKggUFhQQCgweHBQiDB4iEiguIioAcAGeIgQGP24/XD+2IgBIALQAoAYCPrAGCB4aDjw/uBAwDgwQAWQEP6o'
    '/Qj+KFgBuALgAcAoAAIFsP9IB1gGeAAMABAAAAEzERQGIyIvARYzMjUBMxEjBsCYWIhgSCBgaEj+8JCQBnj5mHBYGKAgUAVw'
    '+3gAAgBY/0gEgAYoABcAGwAAEyEVIxEzFSMRIxEhFRABJwARNSM1MxEjAREhEaADyMDY2KD+8P7ggAEA8PC4Amj+8AYomP2g'
    'mPywA1AY/gj+wHABGAGwGJgCYP2gAmD9oAAAAQB4BNgHiAZ4ABMAABMhNTMVITUzFSEVIRUjNSEVIzUheAHgqAIIoAHg/iCg'
    '/fio/iAF6JCQkJCQgICAgAABAED/SAMQBngAHwAAARcHERQGIyIvARYzMjURBgcnNjcRITUhETMRMxUjETYC+BjoUGBwYCBo'
    'cCiAkDiwmP74AQig4OBoA6CQgP2QeGAYqCBgAfg4OKhAQAGYmAFQ/rCY/qg4AAABAEj/SAMoBngAFgAAEyERMxEzFSMVFhcH'
    'JicRIxECBycSEyOIAQCY8PCYcGhQUJhYeHDoSPAFCAFw/pCYYLiwmKiA/BADaP74sHABWAGwAAECgP9QB6gGEAAXAAABERQz'
    'MjY3Fw4BIyImNREhERACBycAGQEGeEAoGAioCGCYkED+kLDIcAFIBhD6WFA4mDDIeEh4BTj9yP6Y/ji4iAEgApACiAAAAQAw'
    '/0gDeAZ4ABYAABMhETMRIRUhFRYXByYnESMRAgcnABMhgAEooAEY/uiwgGhoYKBgqHABCGD+6AUIAXD+kJhQwLiYsIj8AAOI'
    '/vDIcAFIAcAAAgTg/0gHMAZ4AAwAEAAAATMRFAYjIi8BFjMyNQEzESMGkKBgkIBwIIiIUP5QoKAGePmgeFgoqDBQBWj7eAAD'
    'AGj/SAQABngAGwAfACMAABMhNTMVIRUhFSERIRUhFSERIxEhNSE1IREhNSETITUhESE1IYABYKABYP6gATD+0AGA/oCg/ogB'
    'eP7QATD+oMgB0P4wAdD+MAXIsLCQqP0gsJD+2AEokLAC4Kj+KKj+MKAAAAQCqP9IB6gGOAAPABMAFwBAAAABESERNjcnNxYX'
    'BycGBycRFxEzGQEjETMBIRUjAgczFSEHMxEUMzI2NxcOASMiJjURAgcnABMjJzY3FwYHMzYTIQSo/qBoWFCAcEiIIJi4UKDA'
    'wMABCAJguBAY8P8AIFgoKBgIgBBQaHBQcNiAAVA46ChIKIggOIgYEP7wBjj8OP5AQEiQOLDIQGh4aFAGGJD++AEI/mj+8AM4'
    'kP6w8Iiw/eg4OKAw0GBIYAFI/tjYcAE4AfCImPAg2JDwAVAAAAICyP9IB5gGgAAbACgAAAE2NzY3FwAFJyQ3BgcnNjchNSEm'
    'JzcWFyEVIQYFFwIHFhcHJicEBScAA+jwsEg4oP7o/aBYAXjQ8PggsID+sAIAKECoSDAB4P1weAJIoJDAyLBwuND+8P6ASALY'
    'A2gQIGiAQP2w8ICg8CgQiJjgmHBoOICQmNjIOP7wwJi4gMiY4JiIASAAAAEAeP+ABBgGcAAYAAABFwYHIRUUAgAHJyQTIQYH'
    'FhcHJicGBycAAgiYICgBwNj+iPhIAliQ/rBAMIBwaGhoMDiIARAGcDCAgJhY/XD+MHCo+AOIqGBgeIB4WFhQaAGQAAIB0P9I'
    'B5gGMAAZACIAAAEhFQMhAgMWFwcmJwYFJyQ3JgMCASc2EhMjARITNhMhJxMhAxgDeIABYFjwoNB4wKi4/vBgARCosJBA/pCI'
    'uPgokAEQoPCwSP7gMID+aAYwiP5w/gj+yJB4kICgqHiQeJDAARj98P6YcKgCCAM4/mD+aP744AFIgAGYAAIAaP9YBAAGeAAP'
    'ACIAABMhETMRIRUhESEVITUhESERITUzFSEVIRE2NxcEBSc2NxEhqAE4oAEw/tABePxwAXj+yAEwoAFA/sDIoCD+cP4YIMio'
    '/tAFeAEA/wCY/wCYmAEA/TjIyJD+4DAwmIBYsCAgAUAAAgIo/3gHqAZ4AA8AHwAAASERMxEhFSERIRUhNSERIRMhETMRIRUh'
    'ESEVITUhESECqAHooAHo/hgCSPrYAkD+GBAB6KAB4P4gAmj6gAJ4/hgFaAEQ/vCY/vCYmAEQ/PABIP7gmP7omJgBGAAAAQLY'
    '/2AHgAZ4ACEAAAEXBgchCgEjIi8BFjMyNxITIwIBJwATIwIBJwATIwYHJxIEOJggMAMAEJDQYIgYmGBwIEAIaEj9mGACMECQ'
    'OP4gWAGoOHhokHDwBnggeHj7eP6AEJgQuAFwAsD8mP5AgAGYAxD9iP64eAEoAiDYkHABCAABAEj/SAMIBngAHgAAExcGBzMR'
    'MxEzFSMRNjcXBgcRIxEGByc2NxEjBgcnEtiQEBhoqKCgUFAYWGCogIhAsJiAKDiAaAYgMICAAYj+eJj+QDA4mEg4/WACSEg4'
    'oEBQAhjImGgBQAAEAGj/QAeoAOgABQALABEAFwAAJRcGByc2JRYXByYnJRYXByYnJRYXByYnAVCQeHiIkAPwaEigQFgCWJhY'
    'mFiI/QhoILAYYOhY0IB4kJigsEjAkECYqFiomEioqDC4mAABAIAEqAeIBngAEwAAEyE1MxUhNTMVIRUhFSM1IRUjNSGAAdio'
    'AgigAeD+IKD9+Kj+KAXQqKioqJiQkJCQAAEAgAUIB4gGeAATAAATITUzFSE1MxUhFSEVIzUhFSM1IYAB2KgCCKAB4P4goP34'
    'qP4oBghwcHBwkGhocHAAAQCABPgHiAZ4ABMAABMhNTMVITUzFSEVIRUjNSEVIzUhgAHYqAIIoAHg/iCg/fio/igGCHBwcHCQ'
    'YGCAgAACAFD/SANIBngACQAPAAABMxEWFwcmJxEjAxcCAycSAaCYoHBoUFiY8JgYUJBQBnj+0HhwkGhY+rgFoCD+yP8ASAEI'
    'AAQAaP9gB6ABOAAFAAsAEQAlAAABFhcHJiclFhcHJiclFwYHJzYlMxUUFjMyNzY3NjcXBgcGISAmNQbIgFigUHj96DggkCBA'
    '/dCAeIB4kAEwoEjQwAiwEBgQoBhAKP4w/rhwATio0EjYqEBgaDBwWCBI6IhwmJjIMCAICAggiFiwMCBIcAAAAQRY/0gHUAYA'
    'ABAAAAEhESMRIREUBiMiLwEWMzI1BrD+SKAC+FBQaKgguEgwBWj54Aa4+wBYWBiYGDAABQCAAWgHiAaQABMAGQAdACEAJQAA'
    'ARYXIRUhBgchFSE1ISYnITUhJicDITY3IRYBIREhEyE1IREhNSEEGEAYApj++CBIAfD4+AHYKED/AAK4GCBoAdg4KP1wOP5o'
    'BUj6uKAECPv4BAj7+AaQSFCISHiIiGBgiDgw/lBYaGD+sP2oAWBw/rB4AAEDAP9IB5gGgAAWAAABAgcnEhMXBgchFSERIRUh'
    'ESEVIREjEQRIaGh4uFigGCgDKP2QAgj9+AIw/dCgBMj+6JiAATABuCiIeJD+0JD+0JD+AAWAAAMBWAL4BqgGMAADAAcACwAA'
    'ASERIRMhNSERITUhAVgFUPqwoAQQ+/AEEPvwBjD8yAHgwP34wAAAAgJg/0gHsAZ4ABoAIAAAASE2NREhNSERMxEhETMVIRIF'
    'BwADAgEnABMhJREhERQHArgB0Aj+wAFAoAG4sP3gsAGIeP6AwID+eJABqGD+UAOQ/ugIAug4MAFImAFI/rj9uKD+cNiYAQAB'
    'qP5g/vhwASABcKABsP64MDgAAAIAUP9IA0AGeAAJAA8AAAEzERYXByYnESMDFwIDJxIBoJiYcGhQUJjwmBhQkFAGeP54qJiI'
    'kHj7GAWgIP7I/wBIAQgAAgBY/0gC4AZ4AAkADwAAAREjETMRFhcHJiUXAgMnEgIAkJCAYGBA/mCIEDiIOASI+sAHMP7QcHCI'
    'WLAg/sj/AEABEAAEAFD/SAOQBjgAEAAUABgAHAAAEyEVIxE3FwcRIxEGBSc3ESMBIREhESERIRElNSFoAyh4QCBgoOj++DiA'
    'aAEIAQj++AEI/vgBCP74BjiY/FggiDD96AHQYFCoIARw/wABAP1wAQD9UGDAAAACA8j/WAeoBiAAIAAmAAABIRUhAyECFRQz'
    'MjY3Fw4BKwEiJjU0EyEDNjcXBgcnEyMBFhcHJicDyAOA/cggAehYOCggEJgYYFhAYFhQ/qhwgIgY2KhAsLABwDAQiBAwBiCY'
    '/uj7+FAwMHAwoGBIUEgDoPwYGDCIQBhoBcj9iMjQKOC4AAABAGj/gAOYBmgAGwAAEzMRMxEhNSE1MxUhFSERMxEzESERNxcG'
    'BycRIZiQkP6wAVCYAUj+uJCQ/uDoQJjAaP7gBFD96ALImNDQmP04Ahj9WP6QkHhwYGAByAAEAGD/SANoBogAHQAhACcALQAA'
    'ARcGByERFAYjIi8BFzI1ESEVEAcnNhE1IzUzETM2AyERIRcWFwcmJxMWFQc0JwHwqCAoARhQSEiAIMAo/pBwkHBoaNgweAFw'
    '/pCoWEB4OFigKJAgBoggeGD6gFhYCJgIMAJwoP5I+DjoAchomAJggP0gAdA4iJBAiIj9wLjIENCoAAABAJD/cAM4BggADgAA'
    'EyERIREkNxcGBScRIREhkAKo/iABAMgY8P64UAHg/gAGCPzw/ThYWJh4YFAD0AHgAAIDaP9AB6gGeAAYAB4AAAEXBgchFSMC'
    'AxYXByYnBgUnJDcmAwYHJxIXEhcSEyEEiKAYKAKogDjIqPB42Kiw/vhwARCokHgoKIDAYHigmDD+WAZ4MJCQmP3o/rjAmJiY'
    '0NiQiJDgyAEQWEhgAYhw/rjgASABsAACA7D/QAegBngAGAAeAAABFwYHIRUjAgMWFwcmJwYHJzY3JgMGBycSFxIXEhMhBMiY'
    'GCgCcGgwwJjQgLCYmOBo4JiIcCAogMhYaJiIKP54BngwmIiY/ej+sLiYmJDI0IiQiNjYARhQSGABoID+qOgBGAGwAAEAYP9I'
    'AuAGeAAeAAATMxEzETMVIxE3FwYHERQGIyIvARYzMjY1EQcnJREjcPigoKC4IGhwUHhgUCBYYCAgyEABCPgFKAFQ/rCY/nhY'
    'kEA4/dCAYCCgICg4AchQqGAByAAAAQBY/0gDEAZ4AB4AABMhETMRMxUjETY3FwYHERQGIyIvARYzMjURByclESGAAQig4OBo'
    'aBhweFBgcGAgaHAo+DgBMP74BSgBUP6wmP5wKDCQQDj90HhgGKggYAHAYKhoAdgAAAIAeP9wAfAGQAAFAAsAAAEWFwcmJxMX'
    'AgMnEgEggFCYSHjQiEiQoJgGQLjgWNjA/NBY/nj+mHgBWAABAIj/UALIBjAAFQAAAREhNSERIQMhEAYjIi8BFjMyNhMhEwIw'
    '/mgCMP6QIAGIWJBYcCCAWCgoCP5oQARoATCY/aj+wP2g6BiYGIgBmAJgAAQAaP9wB5gByAAHAAsADwATAAABETMVITUzERMh'
    'ESEBIREhASERIQbYwPjQwKABGP7oAbABEP7wAagBGP7oAcj+QJiYAcD+QAEw/tABMP7QATAAAAEAUP9IApgGeAAKAAABFwYH'
    'ESMRBgcnAAH4oEBQoGBoUAEoBngwuLj6cARgmICgAZAAAQBQ/0gCOAZ4AAkAAAEXBgcRIxEHJxIBoJg4WJhwUOgGeDDg2Pq4'
    'BAC4oAGQAAEAUP9IAoAGeAAKAAABFwYHESMRBgcnAAHgoEhgoEhQUAEQBngw4Nj6uAQYcGCgAZAAAQBQ/0gC2AZ4AAoAAAEX'
    'BgcRIxEGBycAAjigWHigYGhQAVgGeDDo4PrIBDiAcKABkAACAGgEmAeQBogADwAfAAABFwchFSEWFwcmJyMGByc2JRcGByEV'
    'IRcHJicjBgcnNgG4oDAB0P8AQDiQQFiAYICA8AOgmBAYAij+wEiQMECIUGiIyAaIMFiIQEBQaGiAYGC42DAoMIhYUFBYcFhg'
    'qAAAAgBoBJgHkAaIAA8AIAAAARcHIRUhFhcHJicjBgcnNiUXBgchFSEXByYnIxUGByc2AbigMAHQ/wBAOJBAWIBggIDwA6CY'
    'EBgCKP7AcIhIWJBYcIDYBogwWIhAQFBoaIBgYLjYMCgwiIBQaGgIgFBgsAAABAMY/0AHqAZgAAUANQA6AEAAAAEXBAUnIAUW'
    'FyE2NxcGBzMVIQchFSEGByEVBgcWFwcmJwYHJzY3JicGBycSEyM1ITchNTMmJwEWFzY3ARYXByYnByhQ/nD9uDAB4P7oYDgB'
    'SGgwqDhgqP3QGAJ4/WgQGAJASICQyFDgqMD4SOCYcFBgkIDwWPgBGBD/AKAwQAE4UIBwQP74SDB4KEgGYIhQGJC4cICgqDCQ'
    'iIiYkFBAiMh4SDCYQHB4OJgoWGiAyKhgASgBUJCYiFhI/JiIYFiQA9BQWEhYUAABAjD/SAeYBngAFgAAARcGByEVIREhFSER'
    'IRUhESMRIwYHJxIDoKggMAOg/UACQP3AAlj9qKCAaLBw8AZ4KIBwmP7IkP7ImP4YBYD4yIABMAAAAgBg/0AC2AZ4AAUAEAAA'
    'ARcCBSckHwEGBxEjEQYHJwACCIiY/thgARjIiFCImGBIYAFABnhI/tjYgNjYSKCo/CADQGA4gAEAAAACAlj/mAeYBngABQAZ'
    'AAABFhcHJicBIRUhESEVIREhFSE1IREhNSERIQS4eEiISHj+YATo/dgB4P4gAkj6wAJY/iAB4P3gBnhwiFCAcP7YmP4wkP4w'
    'mJgB0JAB0AAABQCIA1gHeAZgABMAFwAbAB8AIwAAEyEVIRUhESM1IREjESEVIxEhNSETIRUhJSEVIRUhFSElIRUh4AZA/TAD'
    'KKD9eKD9eKADKP0wmAHo/hgDIAH4/ggB8P4Q/NgB6P4YBmCIYP6Q6P6IAXjgAWhg/sh4eHhQgHh4AAAFAIgDCAd4BlgAEwAX'
    'ABsAHwAjAAATIRUhFSERIxEhESMRIRUjESE1IRMhFSElIRUhBSEVISUhFSHgBkD9MAMooP14oP14oAMo/TCYAej+GAMoAej+'
    'GPzQAej+GAMoAej+GAZYiHj+eAEA/jgByPgBgHj+oICAgGB4eHgABQCIAuAHeAZYABMAFwAbAB8AIwAAASE1IRUhFSERIxEh'
    'ESMRIRUjESEBIRUhJSEVIQUhFSElIRUhA7D9MAZA/TADKKD9eKD9eKADKP3IAej+GAMoAej+GPzQAej+GAM4Aej+GAXQiIh4'
    '/ngBAP4gAeD4AYD/AICAgHiAgIAAAgKY/0gHqAZ4ABgAHAAAARcFESEVIREhESM1IRUjESERITUhEQUnJAEhESEG6Ej+QAI4'
    '/cgBwKD9IKABwP3IAjj+eEACGP6QAuD9IAZ4iHD+sJj+0PzgcHADIAEwmAEwQKBA+lABiAACAEj/UANoBngAFAAaAAABMxE2'
    'NxcGBxUUBxYXByYnAgcnABEDFwIDJzYBoJB4SHh4wBCogGhweGDAiAFQ6JgYYJBYBnj+aHB4YLiQ6JCQ2MiY2LD+uNBoAXAC'
    'EAHYIP6g/vhY+AADAxD/SAdYBkgABwALAB4AAAERIzUhFSMREyERIRMhETMRIRUhFAcBBwMCBycAEyEHWJj86JiYAxj86DgB'
    'AJgBEP7wCAEwcOhgqHABCAj/AAZI+QB4eAcA+hAFWP6wARD+8JhISP4wiAGQ/uigcAEIAZgAAAMAWP9IAmAGaAAFAAsAEQAA'
    'ARYXByYnExYXByYnARcCAycSASCwkGigqCCgiHCIoAEoiGC4oMAGaGCIiJho/oBYcIiIWP54YP6I/qBwAVAAAQA4/0gDWAaA'
    'ABwAABMhEQYHJyQlFwURIRUhFRYXByYnESMRBgcnEhMhaAE4eIA4AWgBKEj+8AEg/uCgeGhYWJhgmHDgcP7gBGABCCAYkECA'
    'iGD+yJAoqKiQmHj8cAMg8MiIASABeAAAAAEAAAVYAMIAJwEFABgAAQAAAAAAAAAAAAAAAAAFAAEAAAAAAAAAKAA+AHoA2QE5'
    'AbEBwAHiAgQCKAJAAlkCZgKGApYC1QL0AysDewOnA+cEPwRSBLwFEgVLBX4FkwWnBbwGEAaiBswHEgdJB3UHjQeiB+QH+wgT'
    'CDQIUAhfCI4IuQj4CSIJbwmfCegJ+gohCj4KhQqjCroK0QrkCvMLBQsaCygLcQu2C+YMLAxoDJMNFA08DVsNjw2wDbwN+w4h'
    'DlIOmQ7fDwUPUQ9+D6cPyRAVEDMQahCBELsQyBEEETkRcxGUEdUSJhKKEpwSwRLSEuIS7xMLEyMTQRNxE58T3BQQFGEUihS2'
    'FP8VKxVfFZgV4hYGFmoWlRbIFtMXJBdGF1EXXBeeF6kXtxfCF80X2BglGDAYOxhGGFEYXBi0GL8YyhjVGOAY7hj5GQQZDxka'
    'GSUZMBk7GUkZVBlfGWoZthoAGlwaiRrLGw4bUhuWG+McVhyRHN4c6Rz0HP8dCh0VHUQdcR2iHa0d9R4AHgseFh4hHiweNx5C'
    'Hk0eWB63HsIezR7YHwkfFB8fHyofNR9AH4IfuB/QH/UgKyBkIJog5iE6IWMhbiGGIZEhnCGnIhYiISJ8Ioci6yL2IwEjGyNK'
    'I3sjtiP7JDEkPCR4JKwk7SUkJVolZSVwJXslhiXCJg0mXiZpJnQmgiaNJwUnECcqJzUnXSdoJ3MnfieJJ80n2CfjKC4oOShH'
    'KFIoqyi5KMQozyjaKOUo8ClCKU0pqim1Kg4qGSpDKnYqrirxKzUreiuFK5ArmyumK9Ur4CwwLDssRixRLJ4s6CzzLP4tCS0U'
    'LR8tUC1bLWYtcS18LYctuS3uLfkuBC40LnouhS6QLpsupi8LLxYvSS97L74wFTAgMHcwgjCQMK4w4zEnMUkxVDFfMWoxdTGA'
    'MYsxljHMMh0yKDIzMj4ySTJ/MooylTKgMqsytjLBMswy1zMdMygzMzM+M0kzVDNfM2oz0TQ1NEA0SzRWNGE0bDSpNNk05DTv'
    'NPo1ZTVwNXs1iTWUNZ81qjW1NcA1yzXWNeE17DX3NgI2DTYYNiM2LjY5NkQ2TzZaNmU2cDZ7NoY2kTacNqc26zb2NwE3DDcX'
    'NyI3LTc4N0M3hDe3N8I3zTfYOBI4HThbOHw4hziSONU5HjkpOTQ5iDmTOdo55TnwOfs6NTpuOqk68jr9Owg7TjtZO6Y7sTu8'
    'O8c70jwfPCo8ODxDPE48WTxkPG88ejyFPJA8mzymPLE8vDzHPNI88D0TPVg9lz3zPkg+Uz5ePmk+0z8RP1c/Yj9tP3g/gz+O'
    'P5k/pD+yP70/yD/TP94/6T/0P/9AEEAbQCZAMUA8QHxAh0CSQJ1AqEC2QMFAz0DaQOVA8ED7QQZBEUEcQSpBNUFAQUtBVkFh'
    'QZZB4kIZQlxCZ0K6QsVC9EL/QwpDFUM9Q3tDhkPVRCtEjETIRNNE3kUdRZlFpEWvRbpFxUXQRdtF5kYaRiVGMEY7RkZGUUZc'
    'RmdGckZ9RohGlkcGRxFHHEcnRzJHPUdIR1NHXkdpR3RHf0eKR5VHoEerR7ZHwUfMR9dINkhBSExIV0ixSOhI80j+SQ9JQElL'
    'SVZJYUlsSbxJyknYSeNJ8Un8SgdKW0pmSnFKfEqHSpJKnUreSulK9Er/SwpLa0t2S4FLjEuXS6JLrUu4S8NLzkvZS+RL70v6'
    'TAVMEEwbTGhMc0x+TIlMlEzXTOJM7Uz4TTRNP01KTVVNYE2wTelN9E3/TgpOFU4gTitONk5ETnJOfU6ITpNOnk6pTrROv07K'
    'TtVO4E8zTz5PSU9UT19Pak91T4BPi0+WT6FPrE+3T8JPzU/YUBZQbVB4UNFQ3FDnUPJQ/VEIUUFRblF5UYRRj1GdUahRs1G+'
    'UclR11HiUe1R+FIDUg5ST1JaUqJSrVK4UsNSzlLZUuRS71MfUypTNVNAU0tTlVQFVBBULlRLVGhUelSPVKlU3FU8VYBVsVXO'
    'VjJWdVaoVv5XVleSV8tX91gqWFtYk1jjWRhZYlmdWc9aE1poWpVbGVtlW6Fb31wRXHBcs1z3XS9dYV2mXgdeO15cXq1e2l9F'
    'X7Rf9mBPYIpgtmDsYTNhoWHrYjZiaGKlYuFjE2M9Y4FjrGQzZIhk5GUpZVZlg2W+ZeRmDWYnZnBmmWbOZxhnRWeQZ6xnzGf3'
    'aDFoZ2i/aRJpRGljaahp92pRanpqtGsAazhrYmuPa8xsP2yJbLps6m1hbbpt4m4fbk9ukm7fbxFvbm/ncCpwmXDRcQtxNnGK'
    'cdhyHHJJcnJylHK2cuVzAHNJc6t0D3RBdG50iXSxdNp1D3U9dYV1yHXcdiJ2PnZYdnJ2rXbedyV3Z3eBd8F4BXhBeJh44Xj4'
    'eRB5KHlAeVp5fHnJef96MXpferJ64nsme1N7knvifB98ZnyNfMN9C31Hfal93H4yfmp+q38Ff2d/ln/6gFCAr4DdgQ+BNIGQ'
    'gdaCFIJpgrSC84Mlg2OD5YQHhEeEiISwhPeFO4VxhamF74Yghm2GzocSh3CHn4e+h/SIKIhhiIqIwokDiUWJmonNijWKpIrd'
    'iy6LU4uGi9OMH4xPjKaM5o0sjW+NwI4IjkeOkI7PjviPII+Ij8CQA5BDkHiQrZEEkWORvJIhkm2Su5LTkw2TWJOnlAqUR5SI'
    'lNCVJpVmlbGV4pZClouWwZcml0OXd5ewl/CYPJhdmI6YzpkPmVuZp5nzmj+al5rRmwebU5uPm9acGpxpnKOc2p0QnVKdrJ3V'
    'nhWeX56QnrifBJ85n3CfvZ/koC2gaKCkoQahO6FUoX2hxKIXomeinqLpoxKjRaNmo5Sj46QkpGakqKTCpOqlQ6V1peKmKKZv'
    'pqKm4Kcgp1Cndaetp86n8KgfqE+ofqisqOGo+qkqqVepk6nPqf2qK6pgqpWq46r4qzGrY6uTq9SsFaw8rF2sj6zLrOatC61W'
    'rZmt3a4nrmmur67urxqvRq+br8mwGbBmsIewp7DasSuxd7GxseuyKLJOsnWywbLksv6zPrNZs4WznbPntB60QLR9tMC07LUL'
    'tTC1arWktcO137YGtkW2e7a1tvu3VbePt8637LgpuH64srjauQW5KrlfuYy5o7nxuj+6jbrGuxO7ZLvTvA+8SbyAvLO86b0w'
    'vYO9vL3evgC+IL5Dvmy+qL7vvxu/Vb+Bv7bAC8A+wIjAwMD1wVnBsMHowgbCRMJewozCq8LkwxnDUcOVw/nENcSmxN7FBcVJ'
    'xYzFzsX5xjHGb8atxubHJcdWx4PHmsfgyBTISch4yL/JEck8yYTJrMn+yk/KdMqhyr7K3MrvywjLU8tpy3/Lq8v1zCLMTsyL'
    'zMLNI81JzXzNsM4Hzj/Ol87Uzw7POs+Lz8DP6NAP0DXQXdCN0L/RQtF10ZzRw9Hu0hPSRtJy0prSwNLi0yrTb9Ob0+TUBtQn'
    '1GrUkdS+1O/VDtVI1XnVp9XN1fnWH9ZK1m3WptbY1wTXLdeK19rYFtg92IHYmtjQ2OvZMNlR2XLZvdnu2gzaRNqO2rva49s6'
    '21bbdduZ273cANwf3E/cbtyh3Mnc9N0e3T3dd93g3iveW96g3trfEN9Q34Pfs9/S3/HgEOAy4HXgk+DX4QHhHeFb4X3hn+HV'
    '4hfiROKP4q7i6eMj41TjhuOj48vj9eQO5CXkPuRX5I/kyOU15V7lg+Wy5e/mLeZs5qDm0+cN5zXnaQAAAAEAAAAAMzNkpbp1'
    'Xw889QI/CAAAAAAAxj/GoQAAAADGP8ah+4n91QlaCHMAAAAIAAAAAAAAAAAIAAJYAhQAAAInAJMDNwCFBSsAMwRoAHsGmgBm'
    'BZ4AbQHPAIUCaABSAmgAPQRoAFIEaABmAgAAPwKTAFICJQCTAvwAFARoAGIEaACyBGgAYARoAFIEaAAXBGgAgwRoAHEEaABa'
    'BGgAagRoAGoCJQCTAiUAPwRoAGYEaABmBGgAZgNoACUG7gBtBN0AAAT4AMcE0wB9BXkAxwQ5AMcD7gDHBYUAfQWcAMcCtgBS'
    'Aiv/SASiAMcD7gDHBvYAxwXVAMcF8AB9BJwAxwXuAH0EuADHBCcAaAQnABQFlgC4BIsAAAcSABQEYAAABDcAAARQAFICbQCk'
    'AvwAFwJtADMEQgApA0r//AQ/AF4EsACuA7QAcQSwAHEESABxAqIAHQQlACUEtgCuAhIAoAIS/7wD+ACuAhIArgcrAK4EtgCu'
    'BJ4AcQSwAK4EsABxAzEArgOcAFoCtgAhBLYApAPVAAAF+AAUBAAAIwPpAAoDhwBSAtUAPQRoAekC1QAzBGgAZgNtAHsEaACN'
    'BGgAZgRoAD8EaABmCAAAMAAwBAAB4ACoAKAAoACQAFgAoACQAHgAiABgAOAAsAB4AHgAcAB4ANgAaACAAHgAaABgAFgAWABQ'
    'AQgAUABQAFAAUABQAGgAUABQAFAAUABQAGgAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAcACQAGgAcABoAFgAkACI'
    'AHgAaABoAPAAYACIAGgAaABoAHgAaADYAIAAmABwAGgAeABgALAASACQAGAAaAA4AIgAWABwAHgAgABoAEgAcABoAFAAcADQ'
    'AHgAiACAAHgAWACIAGgAmADQAFAAUABQAFAAYABoAFAAaACYAKAAoAFIAHgAaACoAGAAWABwAFAAyABgAFAA4ABgAHAAWACg'
    'AGgAWABgAKAAoACgAKgAWACoALgAuADgALgAuAC4AMAAQABYAFgAUABYAGgAWACAAGgAWABYAFgAWABoAHAAcACgAHgAgABI'
    'AFgAcABYAGAAaABwAGgAaABoAFgAeACIAFgAaACYAIAAeABwAIgAgABoAHAAWACAAGgAmABoAEgAUACAAGgAaABYAGAAYABQ'
    'AFAAUABQAFAAYABoAMAAWACQAIgAmACIAGAAmACAAHAASABQAEgAUABQAFAAUAB4AHgAkACIAIgAiACIAPgAgABYAGgAYABg'
    'AFgAYABQAHAAUABQAEgAWABQAGgAaABQAHgAiABYAGgAWABYAGgAoABQAFgAUABYAGAAWABgAFAAUABYAFgAYABgAGAAUABQ'
    'AEAAUABAAGAAQABYAEAAWABgAGAAYABgAGAAWABgAGAAWACIANAAkABYAGgASABoAHgAaABQAMAAqABoAFgAgABQAHABYACY'
    'ALgAaABQAHAAkABoAGgAeAB4AGgAaABYAFgAWACQADAAMABYAIAAUABIAEgAMAAwAGgAYABgAHgASABIAEgASABQAEgASABI'
    'AFAASABIAFAAcABoAGgAWACAAHAASABYAEgAiACQAQgAeABYAGgAWABYAGgAWABYAFgAWABYAFgAWABgAFgAYABYAFgAWABY'
    'AGAAaABIAEgAcABQAGAASABoAFgAUABoAEgASABQAFgAcABoAGgAaABoAFAAgABYAQAAeACAAGAA6ACoAKgAaABoAVAAkAAw'
    'AGgAeABoAHgAWABQAGgAkAA4ADgAOABYAJgAYABoAGgAgABoAGAAaABoAHAAaABYAFgAWABYAGgAaABwAGgAaABoAGgAaABo'
    'AGgAaABoAGgAaABoAGgAaABoAGgAWADIAKAAeACIAFAAcABQAJAAiAEgAGAAYABgAGAAaACAAGgAcABoAHgAYABQAGAASABQ'
    'AGgAQABYAJgAaABoAEgAaABAAGAAYABYAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAkABgAGAAYABIAGgASABIAEgAcABQ'
    'AFAAUABQAGAAaABoAGgAaABwAGgAaABoAFgAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABo'
    'AHgAKABoAEAAiABwAFgAYABQAFAAUABQAFAAcADQANAAqACoAKAAqACgAKgAiACIAKAAiACAAIgAaABoAGgAaABoAFAAaABw'
    'AGAAaABgAJAASACAAIAAYABwAGAAYAOAAxACIAFQAagBiABoAIAD6AM4ApACKAKAAmAC0AJIAngCmAJYApAC2ACAA/AD2AQQ'
    'AGgAoABoAGABmABwAnAAkAB4AKAAaABoAGABAACwAOgAoABgATgAeABwAHgAeANoAbACEABoAIgAiAG4AYgBiAH4AhAAYAIQ'
    'AVgBwAEwAFgAcACAAIgAaACIAIgAaAF4AogBkAGYAegBgACIAIACeABYA3gDeAMQA0AC0ANoBQAAYALwAhgDSAKAAtgAaABY'
    'AGAAaAKgAyAAiANQAfgCoABYAzAAoABAAlgAWAKQAFgAuAIYAjgCYAFgAvACkAB4AEgBMACAAIAAgANAAvgCaALYAKgAmACA'
    'AcAAaAMAATgCwAL4AGgAcACAAUABWABwANADoABYBHgDYAJgAogCWAK4AKAAoACoAKgAoABoA0gDoABoAQgDIABIAFAAUAKo'
    'AvgCiACoAvACyAJQAIgCCANYAsgCsAM4AGgC6ANYAsACSALIBAAAaACQAHgDoACQAwgDUACwAGACEAI4AGgDCAIIBWgAKAB4'
    'AqACSALQAhACYALIAxAC8AIwALgDWAKgAHgAqACAA2gCoAJQAvgAcAJoBDADSALQAIADwAJQAEgCCAJIAjADiAKAAjgAOABo'
    'AngDGAOoAcgCeAJwAEgCuALAAJAB6AH4AkAC0AMgAIAAmAL4AxgCsAOQAmgDiALgA6gAaABwAvgAQAM4AHAA0ANIAvAAaABg'
    'AFADIACAAFAC4ANwAHgDEAMAA5gAWALgAwgAYAOQAGAAWACgAygDOAGQAGgCSANIAqAAaABIAGgAWACIBMAB+AMwAFgAiAOo'
    'AugCkAOQBAACuACgAjABUAB4BQgAgAIgA2gDOALgAYAAWABgAKAAwAMYAGgD6ABYAuAAqAQgAxAAUABQA1AASAKwApACcAMw'
    'AcADGACAAHABWACoAIAAgAKgAJgC4ANoAGADKAKIAnAD8ABYAagAoACIA6AC4AJQAFgDqAKgA/gDkAQAAHADmAKwAFgAmAFI'
    'AGgBAAGQAdgDyALAAIgAaAMoAGgA0AKoAJgB6ATIAtAASAKwBQAAWANgAGgCoABoAGgDgABoAPgC2ABgAGgDIABgAHADMABo'
    'AtACYABQAIAAUABoAZAEkARoAGgCqAH4AigCYALwAkgEKANwAFAAUABQAFgAcABoAGgAaAEQARACQABoAxgCoACIBNACEACo'
    'AKgDAANoA0gDAAMgAEgAcAIYAMAEqACAAHACeAOIAEgCuABoAGAC2ACoAEgASABIBDgASABYAFgAWABYAFAEaABQA9gEoAPI'
    'A3ACsAJAAwACgACIAmgCgAMwAogE2ABoAJgAUAJ4AHAAcABQA4AAUABoA5gAUAIwAEgEMANYAuAAaAMQA+AEwARAAyAAWAMo'
    'AGgAaABoAGAAWAKAA0AEgASAAPAAiABQAwAAYABoAFACKAMIAsAC8ABYAFgAUABQAGgDmAVYAGAAqAJwAJgAYAC4AGgCiABo'
    'AGAAeAPAAFgC2AJoAKACcAKQALAAmAHQAFAAUAMIAFADmABoAjgEAABQAGgBWAWIAFAAWALIBbAAWAB4AEAASAKAADAE4ABo'
    'AqgCyAB4AdAAaAIoAtgASABoAIAAgACAAFAAaARYAIADAAFYAmAAUABYAFADyABoAGAAkANoA7AAYABYAHgAiABoAFAAUABQ'
    'AFAAaABoAxgCMABgAlgAiACIAIgCmABIAxAAWAA4AAAAAQAAB37+HQAACWT7iflACVoAAQAAAAAAAAAAAAAAAAAAAGUAAwWT'
    'AZAABQAIBZoFMwAAAR4FmgUzAAAD0ABmAfIAAAILBgYDCAQCAgQAAAADCAEAQgAAABAAAAAAV1FZRgBAACD/GwYf/hQAhAd+'
    'AeMAEAAAAAAAAARKBbYAAAAgAAIAAAACAAAAAwAAABQAAwABAAAAFAAEEcAAAARsBAAACQBsAF8AfgCwANcA9yCsIkgwAjAN'
    'TgBOC04OThNOFk4cTipOLU47TkVOS05fToZOi06OTpFOm06kTrpOzk7WTuVO6k7wTvZO+08YTxpPKk9PT1NPWU9cT3NPf0+d'
    'T6dPv0/dT+FP71ANUDxQT1BaUFxQz1FFUUlRTVFlUWhRbFFxUXNRdlF8UYVRjVGZUbNRxlHPUeBR+1H9UgdSF1IaUh1SJFIw'
    'UjdSTVJUUmpSm1KhUqhTF1M6U0FTQ1NHU0pTU1NVU1dTYVNzU4ZTi1OfU8JTzFPRU9hT4FPjU+pT8FPzVARUCFQOVBFUJlQr'
    'VC9UOFRKVGhUfVSsVM1U6lW3VmhWalbbVt5W4lb0Vv5XBlcoVzBXOldQV1dXYVeCV4tX31gGWGtYg1jwWQRZB1kNWRZZGlkf'
    'WSdZKlkuWTFZNFlXWX1Zy1n/W1BbWFtmW4NbiVuMW5pbnlu2W7lbvVvfW/lb/FwBXARcBlwPXBFcFlwxXDpcPlxAXEJcT1xV'
    'XeFd5l3yXgNeJ144XkVeVV5zXnZej16VXqde0176XwBfD18gXydfOl9TX1VfYl9xX4Vfi1+XX7dfw1/GX+tgAWAnYG9hD2IQ'
    'YhZiGGIqYkFiR2JLYk1ia2JwYn9iimKVYptipWKsYsli1mLfYuJjAWMHYwljIWNfY2JjiWOSY6BjomOlY6hj0GRHZHhknmTN'
    'ZS9lNmU5ZT5lRWVIZUxlcGV0ZYdll2WtZbBluWXLZeBl5WX2Zg5mH2YvZj5mgmb0ZwBnCWcbZx1nH2csZzVnOmdGZ19nYWdl'
    'Z39nhGeQZ5xntmfTZ+Vn8WgHaCFoPGhGaGNor2jAaPFpgmohaiprIWtma3tri2u1a8Frz2vUbDRsiWyhbLls1WzibTttQW1L'
    'bVNtbm2IbeFuBW4QbjJuOG6QbtFu2m7hcGtwrnC5cN9w7XEwcWdyBnIsckhyaXJ5crZy7HOHc6lzr3QDdAZ09nUfdSh1MXU7'
    'dUV1THVZdn52hHbWdth27nb0dvh3AXcfd0B34nfteG55Onm7edJ58Hn7egt6enp/epd6y3rWeu97LHtJe5d7oXutfJJ8l3y+'
    'fMp8+30gfS9+on6mfqp+v37Gfsh+037Vfth+3X7ffud+6X7tfxN/KX86f1F/V39uf/yAAYAMgFSAzID9geqB9IIqgjGCNYJy'
    'gwOEPYTshYSGWohMiGiIcIiriK2IwYjFiYGJwonEicaJyYnSieOJ5otmi6GLpIuwi76LwYvNi9WL4ovli/GL94v7jAONH40l'
    'jTSNRI1WjXCNd42FjYqNs43Rjd2N744qjquPZo9sj26PdI99j4OPkY+Tj6iPuY++j8eP0Y/Uj9mP3I/9kACQApAPkBqQIJA7'
    'kFOQbpB/kLuQ6JD9kU2RypHPlK6U+pUBlSWVLpV/leiV9JYyljuWRJZGlk2WUJZklo+WlJb3lv6XAJdgl2KX6ZfzmHaYe5h/'
    'mISYiJiRmJyY3plwmoyal5q4mtie0Z7Y/wH/Cf8M/xv//wAAACAAYQCwANcA9yCsIkgwATAMTgBOCU4NThNOFk4cTipOLU46'
    'TkVOS05fToZOi06OTpFOm06kTrpOzk7WTuVO6k7wTvZO+08YTxpPKk9NT1NPWU9cT3NPf0+dT6dPv0/dT+FP71ANUDxQT1Ba'
    'UFxQz1FFUUhRTVFlUWhRbFFxUXNRdlF8UYVRjVGZUbJRxlHPUeBR+lH9UgZSF1IZUh1SJFIwUjZSTVJUUmlSm1KfUqhTFlM6'
    'U0FTQ1NHU0pTU1NVU1dTYVNzU4ZTi1OfU8JTzFPRU9ZT4FPjU+pT71PyVARUCFQMVBFUJlQrVC9UOFRKVGhUfVSsVM1U6lW3'
    'VmhWalbbVt5W4lb0Vv5XBlcoVzBXOldQV1dXYFeCV4tX31gGWGtYg1jwWQRZB1kNWRZZGlkfWSdZKVkuWTFZNFlXWX1Zy1n/'
    'W1BbV1tmW4NbiVuMW5pbnlu2W7lbvVvfW/hb/FwBXARcBlwPXBFcFlwxXDpcPVxAXEJcT1xVXeFd5l3yXgNeJl44XkVeVV5y'
    'XnZej16UXqZe0176XwBfD18gXydfOV9TX1VfYl9xX4Rfi1+XX7dfw1/GX+tgAWAnYG9hD2IPYhZiGGIqYkBiR2JLYk1ia2Jw'
    'Yn5iimKVYptipGKsYsli1mLfYuJjAWMHYwljIWNfY2JjiWOSY6BjomOlY6djz2RHZHhknmTNZS9lNmU5ZT5lRWVIZUxlcGV0'
    'ZYdll2WtZa9luWXLZeBl5WX2Zg5mH2YvZj5mgmb0ZwBnCWcbZx1nH2cqZzVnOmdGZ19nYWdlZ35nhGeQZ5xntmfTZ+Vn8WgH'
    'aCFoPGhGaGNor2jAaPFpgmohaiprIWtia3tri2u1a8Frz2vUbDRsiWyhbLls1WzibTttQW1LbVNtbm2IbeFuBW4QbjJuOG6Q'
    'btFu2m7hcGtwrnC4cN9w7XEwcWdyBnIsckhyaXJ5crZy7HOHc6lzr3QDdAZ09nUfdSh1MXU7dUV1THVZdn52hHbWdth27nb0'
    'dvh3AXcfd0B34nfteG55Onm7edJ58Hn7egt6enp/epd6y3rWeu97LHtJe5d7oXutfJJ8l3y+fMp8+30gfS9+on6mfqp+v37G'
    'fsh+037Vfth+3X7ffud+6X7tfxN/KX86f1F/V39uf/yAAYAMgFSAzID9geqB9IIqgjGCNYJygwOEPYTshYSGWohMiGiIcIir'
    'iK2IwYjFiYGJwYnEicaJyYnSieOJ5otmi6GLpIuwi76LwYvNi9WL4ovli/GL94v7jAONH40ljTSNRI1WjXCNd42FjYqNs43R'
    'jd2N744qjquPZo9sj26PdI99j4OPkY+Tj6iPuY++j8eP0I/Uj9iP24/9kACQApAPkBqQH5A7kFOQbpB/kLuQ6JD9kU2RypHM'
    'lK6U+pUBlSWVLpV/leiV9JYyljuWRJZGlk2WUJZklo+WlJb3lv6XAJdgl2KX6ZfzmHaYe5h/mISYiJiRmJyY3plwmoyal5q4'
    'mtie0Z7Y/wH/CP8M/xr////h/+D/r/+J/2rftt4b0GPQWrJosmCyX7JbslmyVLJHskWyObIwsiuyGLHyse6x7LHqseGx2bHE'
    'sbGxqrGcsZixk7GOsYqxbrFtsV6xPLE5sTSxMrEcsRGw9LDrsNSwt7C0sKewirBcsEqwQLA/r82vWK9Wr1OvPK86rzevM68y'
    'rzCvK68jrxyvEa75rueu367Prrauta6trp6una6brpWuiq6FrnCuaq5WriauI64drbCtjq2IrYethK2CrXqtea14rW+tXq1N'
    'rUmtNq0UrQutB60DrPys+qz0rPCs76zfrNys2azXrMOsv6y8rLSso6yGrHKsRKwkrAirPKqMqouqHKoaqheqBqn9qfap1anO'
    'qcWpsKmqqaKpgql6qSepAaidqIaoGqgHqAWoAKf4p/Wn8afqp+mn5qfkp+KnwKebp06nG6XLpcWluKWcpZellaWIpYWlbqVs'
    'pWmlSKUwpS6lKqUopSelH6UepRqlAKT4pPak9aT0pOik46NYo1SjSaM5oxejB6L7ouyi0KLOoreis6KjoniiUqJNoj+iL6Ip'
    'ohiiAKH/ofOh5aHToc6hw6GkoZmhl6FzoV6hOaDyoFOfVJ9Pn06fPZ8onyOfIJ8fnwKe/p7xnuee3Z7YntCeyp6unqKemp6Y'
    'nnqedZ50nl2eIJ4enfid8J3jneKd4J3fnbmdQ50TnO6cwJxfnFmcV5xTnE2cS5xInCWcIpwQnAGb7Jvrm+Ob0pu+m7qbqpuT'
    'm4ObdJtmmyOaspqnmp+ajpqNmoyagpp6mnaaa5pTmlKaT5o3mjOaKJodmgSZ6JnXmcyZt5memYSZe5lfmRSZBJjUmESXppee'
    'lqiWaJZUlkWWHJYRlgSWAJWhlU2VNpUflQSU+JSglJuUkpSLlHGUWJQAk92T05Oyk62TVpMWkw6TCJF/kT2RNJEPkQKQwJCK'
    'j+yPx4+sj4yPfY9BjwyOco5RjkyN+Y33jQiM4IzYjNCMx4y+jLiMrIuIi4OLMosxixyLF4sUiwyK74rPii6KJImkiNmIWYhD'
    'iCaIHIgNh5+Hm4eEh1GHR4cvhvOG14aKhoGGdoWShY6FaIVdhS2FCYT7g4mDhoODg2+DaYNog16DXYNbg1eDVoNPg06DS4Mm'
    'gxGDAYLrguaC0IJDgj+CNYHugXeBR4BbgFKAHYAXgBR/2H9Ifg99YXzKe/V6BHnpeeJ5qHmneZR5kXjWeJd4lniVeJN4i3h7'
    'eHl2+nbAdr52s3amdqR2mXaSdoZ2hHZ5dnR2cXZqdU91SnU8dS11HHUDdP108HTsdMR0p3ScdIt0UXPRcxdzEnMRcwxzBHL/'
    'cvJy8XLdcs5yynLCcrpyuHK1crRylHKScpFyhXJ7cndyXXJGcixyHHHhcbVxoXFScNZw1W33baxtpm2DbXttK2zDbLhse2xz'
    'bGtsamxkbGJsT2wlbCFrv2u5a7hrWWtYatJqyWpHakNqQGo8ajlqMWonaeZpVWg6aDBoEGfxY/lj8wPLA8UDwwO2AAEAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwBaAAMAAQQJAAABFgAAAAMAAQQJ'
    'AAEAJgEWAAMAAQQJAAIADgE8AAMAAQQJAAMAKgFKAAMAAQQJAAQAJgEWAAMAAQQJAAUAJAF0AAMAAQQJAAYAIgGYAEQAaQBn'
    'AGkAdABpAHoAZQBkACAAZABhAHQAYQAgAGMAbwBwAHkAcgBpAGcAaAB0ACAAqQAgADIAMAAwADcALAAgAEcAbwBvAGcAbABl'
    'ACAAQwBvAHIAcABvAHIAYQB0AGkAbwBuAC4ACgBDAG8AcAB5AHIAaQBnAGgAdAAgAKkAIAAyADAAMAA4AC0AMgAwADAAOQAg'
    'AFcAZQBuAFEAdQBhAG4AWQBpACAAQgBvAGEAcgBkACAAbwBmACAAVAByAHUAcwB0AGUAZQBzACAAKABoAHQAdABwADoALwAv'
    'AHcAZQBuAHEALgBvAHIAZwAvACkAIABhAG4AZAAgAFEAaQBhAG4AcQBpAGEAbgAgAEYAYQBuAGcAVwBlAG4AUQB1AGEAbgBZ'
    'AGkAIABNAGkAYwByAG8AIABIAGUAaQBSAGUAZwB1AGwAYQByAFcAZQBuAFEAdQBhAG4AWQBpACAALQAgAE0AaQBjAHIAbwAg'
    'AEgAZQBpAFYAZQByAHMAaQBvAG4AIAAwAC4AMgAuADAALQBiAGUAdABhAFcAZQBuAFEAdQBhAG4AWQBpAE0AaQBjAHIAbwBI'
    'AGUAaQADAAAAAAAA/wAAZgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAFAAL//wADAAEAAAAMAAAAAAAAAAIABQAAANEAAQDT'
    'APUAAQD3AUQAAQFGAoUAAQKHAtEAAQAAAAEAAAAKAAwADgAAAAAAAAABAAAACgAWABgAAWxhdG4ACAAAAAAAAAAAAAAIAAW4'
    'AAAFtgW2BbYGEgXLBc0FtgW2BbYGFASiAO4CeQD6BbYFzQW2BcsFywW+BbYFywW2Bc0FywRmBGYE3QPpBN0FywW2BbwFtgXL'
    'BbYFtgW2BcsFtgW2BbYFtgW2BbYFtgXNBbYFzQW2BcsFtgW4BbYFtgW2BbYFtgW2BbYFtgXB/0gEXgYUBF4GFAReBh8EXgYU'
    'BeUF5QYUBhQEXgReBF4EXgReBF4EXgVGBEoESgRKBEoESgRKBbYGFAW2A1oFywR7BKwFywQlATABOAZgAuADgAXgBlgGCAYY'
    'BngGeAaABngGeAaABngGcAaIBngGeAYQBngGAAXwBngGgAZQBoAGeAZ4BngGeAZ4BngGeAaIBngGgAZ4BngGeAaABngGeAaA'
    'BngGeAZ4BngGeAaABoAGeAaABngGiAaABoAGeAZ4BoAGeAaIBigGcAaABnAGiAaABiAGMAZ4BngGgAaABhAGeAZ4BigGcAZ4'
    'BngGeAZwBnAGeAZ4BngGcAaQBnAGeAaABnAGeAZ4BogGeAZ4BmgGOAZ4BlAGeAaABngGiAZ4BngGAAY4BjgGOAY4BoAGEAZw'
    'BjgGeAZ4BmAF4AYIBggGgAZ4BngGiAaQBjgGeAZoBoAGOAaABoAGMAZ4BkAGkAZoBpAGKAaABkAGUAY4BjgGCAY4BjgGOAY4'
    'BoAGeAZYBoAGeAZ4BngGYAZYBngGgAaABogGgAaABogGgAZ4BogGeAZwBhgGgAZ4BngGeAaABngGgAZ4BjAGiAaABogGiAaI'
    'BpAGiAaIBogGiAaIBogGeAZ4BjgGeAaABpAGeAZwBmgGeAYYBkAGSAZIBkgGSAZABkgGeAYIBogGgAZ4BngGeAZ4BfAGKAaI'
    'BoAGgAaABoAGgAaABogGeAYgBngGaAZ4BnAGQAaABkgGaAZoBngGgAaABngGeAZgBngGeAZ4BngGkAaQBngGeAaABngGgAZg'
    'BngGeAaABngGeAZ4BngGOAZ4BngGgAZ4BngGgAaABoAGeAZ4BoAGeAZ4BngGeAaABngGgAZ4BngGeAZ4BoAGeAZ4BngGeAaA'
    'BngGeAZ4BngGeAZ4BngGeAZ4BoAGcAZ4BngGeAaIBoAGeAYYBiAGeAZIBkgGUAYwBoAGOAZABoAGiAZ4BngGeAZ4BoAGQAZ4'
    'BngGeAaIBngGeAZ4BngGeAYwBoAGgAaABngGeAZ4BoAGeAZ4BoAGeAZ4BngGeAZ4BogGeAYQBnAGgAZ4BfAGeAZ4BngGgAZg'
    'BngGaAZwBngGeAZ4BngGgAZ4BngGgAaABngGeAZ4BngGcAZYBmgGgAZ4BngGgAaABngGeAaABngGMAZ4BogGeAZ4BoAGeAaA'
    'BoAGGAYYBngGIAaIBngGGAZ4BjAGgAY4BngGEAZ4BoAGgAYgBngGeAZ4BngGiAZ4BngGeAYIBpAGgAaABoAGaAaIBogGiAaA'
    'BngGeAaIBogGiAaIBogGeAZ4BngGeAZoBngGSAZ4BngGeAZ4BngGeAZ4BngGeAaABngGeAZ4BngGeAaABoAGKAZABlAGYAZ4'
    'BigGcAZ4BoAGgAZ4BogGiAaIBoAGeAZ4BngGeAaIBngGeAaABngGeAZ4BngGQAYgBjAGeAaIBogGoAaABoAGgAZ4BngGeAZ4'
    'BngGeAZ4BogGgAaIBngGeAZ4BngGeAZ4BngGeAZ4BngGeAaABjAGgAYwBoAGiAaIBoAGgAZ4BngGeAZ4BngGgAaABkgGeAaA'
    'BnAGSAZoBngGSAaABnAGSAaABkgGYAZgBkgGgAZ4BkgGeAaABngGeAaABngGQAZwBjgGWAYwBlAGeAaQBngGgAZ4BnAGkAaQ'
    'BngGOAaABoAGgAZIBoAGcAYwBlgGYAZYBoAGKAZ4BogGOAZIBmgGOAY4BoAGeAX4BogGYAaABnAGiAZABoAFuAW4BbgBMAQg'
    'BCAGgAPABnAGgARoBoAGSAZ4BkgGYAZwBoAGIAZABnAD4AaABigGIAPQBkAD4ATgAigFOATYBngE6APABLgEmAR4BngEyAZ4'
    'BZAGgAZ4BogCsAaABnAGUANIAyAGSAZ4A2gFYAT4BRAESASwBSgDkAOQBAgGOAUwBNgEmATQA7gEcASYA5AF6AJIBYgFCAUw'
    'BigFMAVgBkAGgAYgBoAGaAaQBpAGeAZ4BiAGeAaABmAGeAZ4BjgGgAY4BoAGeAZ4AvgGOAaABoAGWAZQBogDQAYgBngGiAaA'
    'BmAGeAZ4BhgDSAaABngEmAaIBkgCcANAAxgFqAZABogGeAKQAngGSAIIBngGgAJwBjgGeAGoBngGgAKgAggGgAYABjgGIAXQ'
    'BoAGgAZ4BoAGOAXIBcAFwAXIBcgCGAZ4BngGeALYBmAGgAaIBkgGEAZ4BjgGeAZ4BngGOAZ4BngGMAZ4BngGeAZIBngGeAaA'
    'BngGeAYYBegBgAaABngGeAZ4BngGIAYQBngGgAZ4BkgGKAYYBngGgAZ4BjgGgAYIBngGeAZwBngGeAXgBkgGcAYQBngGgAYw'
    'BjgGeAXoBngFOAZ4BjAGeANABnAGMAZ4BjgGeAZQBjgGgAaIBjAGeAZ4BlAGGAaABigGgAZ4BngGgAaABngGgAZ4BnAGgAII'
    'BPAGeAaIBngGMAZ4BngGgAZ4BOgBSAZ4BnAGCANoBggGMAaABngGSAaIBkAE2AMABmgGeAaIBoAGgAZ4BoAGeAYoBiAGeAZ4'
    'AuAGeAZ4BnAGUAaABogGgAZgBPgGaAZYBngGeAYYBngGeAZ4BFAGcAaABkAGiAZ4BngGeAZ4BpAGGAZYBjAGgAaABoAGgAJQ'
    'BngGgAMABmAGeAZ4BjgGeAZ4AuAGeAZ4BngGcAZ4BngGeAaABngGCAVoBjAGiAaIAnACqAY4BjgGeAR4BlAESAYABnAGcAZo'
    'BjAGGAVIBogGeAZ4BngGeAZ4BngGeAYwBjAGMAZ4BeAGgAY4BeACKAaIBHgFeAVgBngGQAYwBhAGeAZ4BngGOAaIBDAGeAaA'
    'BnAGeAaABoAGGAXIBngGeAZ4BngCGAZQBjgGKAZ4BngGeAYoBjgGIAYgBoAGeASABfgGEAZwBFAGcAZABoAGgAZ4BPAGeAZ4'
    'BjgGOAZ4BngGeAQ4BoAGeAZ4BngGUAZABmgGeAY4BiAC8AaABoAGgAaABoAGiAaQBnAGeAZwBhgGiAY4BngGeAaIBoAGeAIg'
    'BngGgAZABhgGOAaABngGeAYABnAGeAZ4BngGgAaIBigGeAY4BlgGWAZ4BngGeAYYBjAGeAZQBoAGCAYYBgAGQAYwBngGeAaA'
    'BoAGGAaABhgGGAZIBnAGgAZ4BoAGcAZ4BoAGgAZ4BnAGaAZ4BmgGMAYQBngGcAaABngGQAYgArgGSAPQBoAGeAYYBmgGeAaA'
    'BoAGOAZ4BngGWAZYAeAGeAYQBhAGcAOQBogGgAaAAuAGaAMgBhAGeAZ4BoAGWAaIBngGcAYwBigGeAKwBogESAZIBkgGeAZ4'
    'BiAGeAZoBngGeAOABkAGeAZ4BngGeAZ4BigGeAZ4BngGEAZ4BngGeAY4BoAGcAYwBngGeAZ4BngA6AZ4BngGeAZ4ATgGAAaQ'
    'BoAGMAZ4BngGeAY4BiAGaAaIBggGeAZ4BngGeAZABjAByAZ4BngGeAZ4BogGiAZgBngGeAZ4BmAGWAZYBngGeAZIBmgGgAAA'
    'AAEQAAVa94kAAAgA/dX/jQhzAAAAAQAAAAAAAAAAAAAAAAAB'
)
# ----8<---- 内嵌字体结束 ----

_FONT_CACHE = {}
_TEXT_CACHE = {}
_TEXT_CACHE_MAX = 3000

_FONT_PATHS = [
    '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
    '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
    '/System/Library/Fonts/PingFang.ttc',
    'C:/Windows/Fonts/msyh.ttc',
    'C:/Windows/Fonts/simhei.ttf',
]

# 文件名里含这些词的大概率是中文字体，优先试
_CJK_HINT = ('cjk', 'noto', 'wqy', 'han', '_sc', '_tc', 'sc-', 'hei',
             'song', 'yahei', 'pingfang', 'hiragino', 'micro', 'zenhei',
             'droidsansfallback', 'sourcehan')

_CJK_PATH = None
_CJK_DONE = False


def _font_dirs():
    dirs = []
    pref = os.environ.get('PREFIX', '')
    cands = [
        os.path.join(pref, 'share/fonts') if pref else '',
        '/data/data/com.termux/files/usr/share/fonts',
        '/usr/share/fonts',
        '/usr/local/share/fonts',
        'C:/Windows/Fonts',
        '/System/Library/Fonts',
        '/Library/Fonts',
        os.path.expanduser('~/.fonts'),
        os.path.expanduser('~/.local/share/fonts'),
    ]
    for d in cands:
        if d and os.path.isdir(d) and d not in dirs:
            dirs.append(d)
    return dirs


def _scan_font_files(limit=240):
    exts = ('.ttf', '.otf', '.ttc', '.otc')
    found = []
    for root in _font_dirs():
        try:
            walker = os.walk(root)
        except Exception:
            continue
        for dirpath, dirnames, filenames in walker:
            if dirpath[len(root):].count(os.sep) > 3:
                dirnames[:] = []
                continue
            for fn in filenames:
                low = fn.lower()
                if not low.endswith(exts):
                    continue
                score = sum(1 for k in _CJK_HINT if k in low)
                found.append((-score, os.path.join(dirpath, fn)))
                if len(found) >= limit:
                    return found
    return found


def _font_supports_cjk(path):
    """metrics() 对缺失字形返回 None，用它判断字体是否含中日韩字"""
    for idx in range(4):
        try:
            try:
                f = pygame.font.Font(path, 20, font_index=idx)
            except TypeError:
                if idx:
                    return False
                f = pygame.font.Font(path, 20)
        except Exception:
            continue
        try:
            m = f.metrics('中')
            if m and m[0] is not None:
                return True
        except Exception:
            pass
    return False


_EMBED_FONT_BYTES = None


def _embedded_font_bytes():
    """取出内嵌字体的二进制（只解码一次，之后复用）"""
    global _EMBED_FONT_BYTES
    if _EMBED_FONT_BYTES is None:
        try:
            _EMBED_FONT_BYTES = base64.b64decode(_EMBED_FONT_B64)
        except Exception:
            _EMBED_FONT_BYTES = b''
    return _EMBED_FONT_BYTES


def find_cjk_font(verbose=False):
    """找能渲染中文的字体。

    优先级：内嵌子集 > 已知路径 > 扫描系统目录。
    内嵌字体是游戏用字的子集（约 130 KB），手机上百分百可用，
    不依赖系统装没装中文字体，所以放在最前面。
    """
    global _CJK_PATH, _CJK_DONE
    if _CJK_DONE:
        return _CJK_PATH
    _CJK_DONE = True
    t0 = time.time()

    blob = _embedded_font_bytes()
    if blob:
        try:
            f = pygame.font.Font(io.BytesIO(blob), 20)
            m = f.metrics('中')
            if m and m[0] is not None:
                _CJK_PATH = '<embedded>'
                if verbose:
                    print('[font] 内嵌中文字体子集 (%d 字节, %.2fs)'
                          % (len(blob), time.time() - t0))
                return _CJK_PATH
        except Exception:
            pass

    for p in _FONT_PATHS:
        if os.path.exists(p) and _font_supports_cjk(p):
            _CJK_PATH = p
            if verbose:
                print('[font]', p, '(%.2fs)' % (time.time() - t0))
            return p
    for _, p in sorted(_scan_font_files()):
        if _font_supports_cjk(p):
            _CJK_PATH = p
            if verbose:
                print('[font]', p, '(%.2fs)' % (time.time() - t0))
            return p
        if time.time() - t0 > 4.0:
            break
    _CJK_PATH = None
    if verbose:
        print('[font] 未找到中文字体，HUD 中文会显示为方块')
    return None


def get_font(size, bold=False):
    key = (size, bold)
    f = _FONT_CACHE.get(key)
    if f is not None:
        return f
    path = find_cjk_font()
    f = None
    blob = _embedded_font_bytes()
    if blob and path == '<embedded>':
        try:
            f = pygame.font.Font(io.BytesIO(blob), int(size))
        except Exception:
            f = None
    if f is None and path and path != '<embedded>':
        try:
            f = pygame.font.Font(path, int(size))
        except Exception:
            f = None
    if f is None:
        for p in _FONT_PATHS:
            if os.path.exists(p):
                try:
                    f = pygame.font.Font(p, int(size))
                    break
                except Exception:
                    f = None
    if f is None:
        try:
            f = pygame.font.SysFont('notosanscjksc', int(size))
        except Exception:
            f = None
    if f is None:
        f = pygame.font.Font(None, max(12, int(size * 1.25)))
    try:
        f.set_bold(bold)
    except Exception:
        pass
    _FONT_CACHE[key] = f
    return f


def _text_surf(text, size, color, bold):
    """渲染结果缓存：HUD 每帧几十次 draw_text，缓存后省掉大量 font.render"""
    key = (text, size, color, bold)
    s = _TEXT_CACHE.get(key)
    if s is None:
        s = get_font(size, bold).render(text, True, color)
        if len(_TEXT_CACHE) > _TEXT_CACHE_MAX:
            _TEXT_CACHE.clear()
        _TEXT_CACHE[key] = s
    return s


def draw_text(surf, text, pos, size=18, color=(255, 255, 255), bold=False,
              center=False, right=False, shadow=True):
    size = int(size)
    img = _text_surf(text, size, tuple(color), bold)
    rect = img.get_rect()
    if center:
        rect.center = (int(pos[0]), int(pos[1]))
    elif right:
        rect.topright = (int(pos[0]), int(pos[1]))
    else:
        rect.topleft = (int(pos[0]), int(pos[1]))
    if shadow:
        surf.blit(_text_surf(text, size, (0, 0, 0), bold), (rect.x + 1, rect.y + 1))
    surf.blit(img, rect)
    return rect


# ==============================================================================
#  8a. 本地存档（最高分 / 最佳战绩）
# ==============================================================================

def _save_path():
    """存档位置：优先游戏同目录，失败则退回 HOME（兼容 Pydroid / Termux）"""
    for base in (os.path.dirname(os.path.abspath(__file__)),
                 os.path.expanduser('~'),
                 os.getcwd()):
        try:
            if os.path.isdir(base) and os.access(base, os.W_OK):
                return os.path.join(base, 'flightsim_save.json')
        except Exception:
            continue
    return os.path.join(os.path.expanduser('~'), 'flightsim_save.json')


SAVE_FILE = _save_path()


def load_save():
    """读取存档，失败返回默认值"""
    d = {'best_score': 0, 'best_wave': 0, 'total_kills': 0, 'runs': 0}
    try:
        with open(SAVE_FILE, 'r', encoding='utf-8') as f:
            raw = json.load(f)
        if isinstance(raw, dict):
            for k in d:
                if k in raw:
                    d[k] = int(raw[k])
    except Exception:
        pass
    return d


def write_save(d):
    """写盘并校验；主路径失败时依次退回备用位置"""
    cands = [SAVE_FILE,
             os.path.join(os.path.expanduser('~'), 'flightsim_save.json'),
             os.path.join(os.getcwd(), 'flightsim_save.json')]
    seen = set()
    for path in cands:
        if path in seen:
            continue
        seen.add(path)
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(d, f, ensure_ascii=False, indent=2)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
            # 写后校验：读回来确认落盘
            with open(path, 'r', encoding='utf-8') as f:
                if json.load(f).get('runs') == d.get('runs'):
                    return True
        except Exception:
            continue
    return False


# ==============================================================================
#  8b. 触屏虚拟控件（安卓 / 手机版）
# ==============================================================================

TOUCH_FIRE = 'fire'
TOUCH_MSL = 'msl'
TOUCH_FLR = 'flr'
TOUCH_BRK = 'brk'
TOUCH_VIEW = 'view'
TOUCH_PAUSE = 'pause'
TOUCH_SET = 'set'


# ==============================================================================
#  画质 / 帧率 / 抗锯齿 设置
# ==============================================================================

# (显示名, 渲染分辨率倍率, 地形环数)
# 地形环数直接决定三角形数量：低画质同时砍像素和几何量，收益叠加。
# 软件光栅化下这是唯二真正有效的杠杆（另一个是少往 X11 传像素）。
QUALITY_LEVELS = (
    ('极速', 0.45, 7),
    ('标清', 0.70, 10),
    ('高清', 1.00, 12),
    ('超清', 1.40, 15),
)
FPS_LEVELS = (30, 60, 90)


class Settings(object):
    """画质 / 帧率 / 抗锯齿，存进 flightsim_save.json，下次启动自动恢复"""

    DEFAULTS = {'quality': 1, 'fps': 1, 'aa': 0, 'fill': 1}

    def __init__(self):
        self.quality = 2          # QUALITY_LEVELS 下标（默认高清）
        self.fps = 1              # FPS_LEVELS 下标
        self.aa = 0               # 抗锯齿开关
        self.fill_mode = 1        # 1=铺满（拉伸不留黑边） 0=适应（保留黑边）
        self.load()

    # ---------- 持久化 ----------
    def load(self):
        try:
            d = load_save()
        except Exception:
            return
        try:
            self.quality = int(clamp(int(d.get('set_quality', 2)), 0, 3))
            self.fps = int(clamp(int(d.get('set_fps', 1)), 0, 2))
            self.aa = 1 if int(d.get('set_aa', 0)) else 0
            self.fill_mode = 1 if int(d.get('set_fill', 1)) else 0
            self.renderer = int(clamp(int(d.get('set_renderer', 0)), 0, 2))
        except Exception:
            pass

    def save(self):
        try:
            d = load_save()
        except Exception:
            d = {}
        d['set_quality'] = self.quality
        d['set_fps'] = self.fps
        d['set_aa'] = self.aa
        d['set_fill'] = self.fill_mode
        d['set_renderer'] = self.renderer
        try:
            write_save(d)
        except Exception:
            pass

    # ---------- 取值 ----------
    def quality_name(self):
        return QUALITY_LEVELS[self.quality][0]

    def quality_scale(self):
        return QUALITY_LEVELS[self.quality][1]

    def quality_rings(self):
        return QUALITY_LEVELS[self.quality][2]

    def fps_target(self):
        return FPS_LEVELS[self.fps]

    def cycle(self, key, step=1):
        if key == 'quality':
            self.quality = (self.quality + step) % len(QUALITY_LEVELS)
        elif key == 'fps':
            self.fps = (self.fps + step) % len(FPS_LEVELS)
        elif key == 'aa':
            self.aa = 1 - self.aa
        elif key == 'fill':
            self.fill_mode = 1 - self.fill_mode
        elif key == 'renderer':
            self.renderer = (self.renderer + step) % 3
        self.save()

    def renderer_name(self):
        return ('自动', 'CPU 软件', 'GPU(OpenGL)')[self.renderer]


def draw_gear(surf, cx, cy, r, col):
    """齿轮图标（用于设置按钮）"""
    if r < 4:
        return
    s = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
    o = r + 2
    lw = max(2, int(r * 0.17))
    pygame.draw.circle(s, col, (o, o), int(r * 0.55))
    pygame.draw.circle(s, col, (o, o), int(r * 0.85), lw)
    for i in range(8):
        a = i * math.pi / 4.0
        x1 = o + math.cos(a) * r * 0.5
        y1 = o + math.sin(a) * r * 0.5
        x2 = o + math.cos(a) * r * 0.95
        y2 = o + math.sin(a) * r * 0.95
        pygame.draw.line(s, col, (int(x1), int(y1)), (int(x2), int(y2)), lw)
    surf.blit(s, (cx - o, cy - o))


class SettingsPanel(object):
    """设置面板：画质 / 帧率 / 抗锯齿。

    绘制时把每行的热区记下来，点击检测直接复用，
    保证「画在哪就能点哪」，不会出现点了没反应的情况。
    """

    def __init__(self, settings):
        self.st = settings
        self.rows = []          # [(key, step, pygame.Rect)]
        self.close_rc = None
        self.rc = None

    ROWS = (
        ('quality', '画质', '标清更适合低端机，超清画面更锐利'),
        ('fps', '帧率', '达不达标会自动微调画质来稳帧'),
        ('aa', '抗锯齿', '边缘更平滑，但会明显更耗性能'),
        ('fill', '画面', '铺满=拉伸不留黑边，适应=保持比例'),
        ('renderer', '渲染器', 'GPU 画 3D / CPU 画界面，切换后自动重启窗口'),
    )

    def layout(self, w, h):
        # 高度要够放所有行，又绝不能高过屏幕（小窗口下会被切掉）
        pw = int(min(w * 0.88, 640))
        need = 56 + len(self.ROWS) * 58 + 58          # 标题 + 各行 + 关闭按钮
        ph = int(min(max(h * 0.92, min(need, max(h - 8, 240))), 430,
                     max(200, h - 8)))
        px = (w - pw) // 2
        py = max(0, (h - ph) // 2)
        return px, py, pw, ph

    @staticmethod
    def _fit(text, size, max_w):
        """小屏上把说明文字截到不溢出（超出部分用 … 结尾）"""
        try:
            f = get_font(size)
        except Exception:
            return text
        if f.size(text)[0] <= max_w:
            return text
        s = text
        while len(s) > 1 and f.size(s + '…')[0] > max_w:
            s = s[:-1]
        return s + '…'

    def draw(self, surf, w, h):
        px, py, pw, ph = self.layout(w, h)
        self.rc = (px, py, pw, ph)
        self.rows = []
        k = clamp(pw / 640.0, 0.72, 1.0)          # 小屏整体缩一点
        # 行高必须能被面板装下：先按可用高度均分，再套 62*k 的上限。
        # 小屏（如极速档 480x270）下均分值会很小，此时省略说明文字。
        avail = ph - 56 - 58                      # 减掉标题栏与关闭按钮
        rowh = int(min(62 * k, max(26, avail // len(self.ROWS))))
        show_hint = rowh >= 46

        # 背板
        bg = pygame.Surface((pw, ph), pygame.SRCALPHA)
        bg.fill((8, 16, 26, 232))
        surf.blit(bg, (px, py))
        pygame.draw.rect(surf, (110, 190, 235), (px, py, pw, ph), 2)
        pygame.draw.rect(surf, (30, 60, 80), (px, py, pw, 40))
        # center=True 时 y 是中心，要往下让够半个字高，否则标题顶出面板外
        draw_text(surf, '设  置', (px + pw // 2, py + 22), int(22 * k),
                  (150, 225, 255), center=True, bold=True)

        st = self.st
        y = py + 56
        for key, label, hint in self.ROWS:
            # 值文本
            if key == 'quality':
                val = st.quality_name()
            elif key == 'fps':
                val = '%d FPS' % st.fps_target()
            elif key == 'fill':
                val = '铺满' if st.fill_mode else '适应'
            elif key == 'renderer':
                val = st.renderer_name()
            else:
                val = '开' if st.aa else '关'
            draw_text(surf, label, (px + 26, y), int(19 * k), (215, 235, 245))
            if show_hint:
                draw_text(surf, self._fit(hint, int(12 * k), int(pw * 0.58)),
                          (px + 26, y + 24), int(12 * k), (125, 150, 165))

            # 左箭头 / 值 / 右箭头
            cx_val = px + int(pw * 0.66)
            r_arr = int(20 * k)
            lx = cx_val - int(pw * 0.20)
            rx2 = cx_val + int(pw * 0.20)
            cyv = y + int(16 * k)
            for cxx, step in ((lx, -1), (rx2, 1)):
                pygame.draw.circle(surf, (40, 70, 92), (cxx, cyv), r_arr)
                pygame.draw.circle(surf, (140, 200, 235), (cxx, cyv), r_arr, 2)
                sx = -3 if step < 0 else 3
                pygame.draw.polygon(surf, (190, 235, 255),
                                    [(cxx + sx, cyv - 7), (cxx + sx, cyv + 7),
                                     (cxx - sx * 2, cyv)])
                self.rows.append((key, step,
                                  pygame.Rect(cxx - r_arr, cyv - r_arr,
                                              r_arr * 2, r_arr * 2)))
            # 值本身也可点（直接往后切一格）
            draw_text(surf, val, (cx_val, cyv), int(19 * k), (255, 214, 120),
                      center=True, bold=True)
            vw = max(72, int(pw * 0.16))
            self.rows.append((key, 1,
                              pygame.Rect(cx_val - vw // 2, cyv - 20, vw, 40)))
            y += rowh

        # 关闭按钮
        bw, bh = int(150 * k), int(40 * k)
        bx = px + (pw - bw) // 2
        by = py + ph - bh - int(14 * k)
        pygame.draw.rect(surf, (45, 95, 70), (bx, by, bw, bh))
        pygame.draw.rect(surf, (120, 255, 170), (bx, by, bw, bh), 2)
        draw_text(surf, '关  闭', (bx + bw // 2, by + int(8 * k)), int(20 * k),
                  (180, 255, 210), center=True, bold=True)
        self.close_rc = pygame.Rect(bx, by, bw, bh)
        return self.rc

    def hit(self, x, y):
        """返回 (key, step)；点在关闭上返回 ('close', 0)；点空返回 None"""
        if self.close_rc is not None and self.close_rc.collidepoint(x, y):
            return ('close', 0)
        for key, step, rc in self.rows:
            if rc.collidepoint(x, y):
                return (key, step)
        return None


class TouchUI(object):
    """虚拟摇杆 + 动作按钮 + 油门滑钮。

    坐标一律使用「渲染分辨率」坐标系，与 HUD 一致。
    所有控件半透明绘制，可与 HUD 叠加而不遮挡关键信息。
    """

    def __init__(self, w, h):
        self.active = False          # 是否处于触屏模式
        self.stick_id = None
        self.knob = (0.0, 0.0)       # -1..1，(x→横滚, y→俯仰)
        self.thr_id = None
        self.throttle = 0.75
        self.btn_ids = {}            # finger_id -> action
        self.held = set()            # 当前按住的动作
        self._events = []            # 本帧触发的一次性动作
        self.set_size(w, h)

    # ---------- 布局 ----------
    def set_size(self, w, h):
        self.w = w
        self.h = h
        s = min(w, h)
        self.stick_c = (int(w * 0.165), int(h * 0.635))
        self.stick_r = int(s * 0.185)
        self.knob_r = int(self.stick_r * 0.42)

        self.btns = {
            TOUCH_FIRE: (int(w * 0.875), int(h * 0.735), int(s * 0.105)),
            TOUCH_MSL: (int(w * 0.735), int(h * 0.815), int(s * 0.072)),
            TOUCH_FLR: (int(w * 0.735), int(h * 0.505), int(s * 0.072)),
            TOUCH_BRK: (int(w * 0.735), int(h * 0.245), int(s * 0.072)),
            TOUCH_SET: (int(w * 0.955), int(h * 0.078), int(s * 0.042)),
            TOUCH_VIEW: (int(w * 0.862), int(h * 0.078), int(s * 0.042)),
            TOUCH_PAUSE: (int(w * 0.045), int(h * 0.078), int(s * 0.042)),
        }
        self.thr_x = int(w * 0.955)
        self.thr_top = int(h * 0.20)
        self.thr_bot = int(h * 0.555)
        self.thr_r = int(s * 0.035)

    def enable(self):
        self.active = True

    # ---------- 事件 ----------
    def down(self, x, y, fid):
        self.active = True
        # 摇杆：中心附近一定范围内都算
        dx = x - self.stick_c[0]
        dy = y - self.stick_c[1]
        if dx * dx + dy * dy < (self.stick_r * 1.85) ** 2:
            self.stick_id = fid
            self._set_knob(x, y)
            return None
        # 油门滑钮：抓取范围放宽到整个右侧竖条，手指粗也能拉动
        grab = max(self.thr_r * 3.2, int(self.w * 0.055))
        if abs(x - self.thr_x) < grab and \
                self.thr_top - self.thr_r * 3 < y < self.thr_bot + self.thr_r * 3:
            self.thr_id = fid
            self._set_thr(y)
            return None
        # 按钮
        for act, (bx, by, br) in self.btns.items():
            if (x - bx) ** 2 + (y - by) ** 2 < (br * 1.35) ** 2:
                self.btn_ids[fid] = act
                self.held.add(act)
                if act in (TOUCH_MSL, TOUCH_FLR, TOUCH_VIEW, TOUCH_PAUSE,
                           TOUCH_SET):
                    self._events.append(act)
                return act
        return None

    def move(self, x, y, fid):
        if fid == self.stick_id:
            self._set_knob(x, y)
        elif fid == self.thr_id:
            self._set_thr(y)

    def up(self, fid):
        if fid == self.stick_id:
            self.stick_id = None
            self.knob = (0.0, 0.0)
        if fid == self.thr_id:
            self.thr_id = None
        act = self.btn_ids.pop(fid, None)
        if act is not None:
            self.held.discard(act)

    def clear(self):
        self.stick_id = None
        self.thr_id = None
        self.btn_ids.clear()
        self.held.clear()
        self.knob = (0.0, 0.0)

    def _set_knob(self, x, y):
        dx = (x - self.stick_c[0]) / float(self.stick_r)
        dy = (y - self.stick_c[1]) / float(self.stick_r)
        m = math.hypot(dx, dy)
        if m > 1.0:
            dx /= m
            dy /= m
        # 死区
        if abs(dx) < 0.10:
            dx = 0.0
        if abs(dy) < 0.10:
            dy = 0.0
        # 屏幕 y 轴向下，故取负：手指向上推 → 抬头爬升（手游直觉式）
        self.knob = (dx, -dy)

    def _set_thr(self, y):
        t = (self.thr_bot - y) / float(self.thr_bot - self.thr_top)
        self.throttle = clamp(t, 0.0, 1.0)

    # ---------- 查询 ----------
    def pop_events(self):
        e = self._events
        self._events = []
        return e

    def axis(self):
        return self.knob

    def is_down(self, act):
        return act in self.held

    # ---------- 绘制 ----------
    def draw(self, surf):
        if not self.active:
            return
        w, h = self.w, self.h
        ghost = pygame.Surface((1, 1), pygame.SRCALPHA)

        def ring(cx, cy, r, width, col):
            pygame.draw.circle(surf, col, (cx, cy), r, width)

        def disc(cx, cy, r, col):
            s = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
            pygame.draw.circle(s, col, (r + 1, r + 1), r)
            surf.blit(s, (cx - r - 1, cy - r - 1))

        # ---- 摇杆 ----
        cx, cy = self.stick_c
        R = self.stick_r
        disc(cx, cy, R, (255, 255, 255, 22))
        ring(cx, cy, R, 2, (200, 230, 255, 120))
        pygame.draw.line(surf, (200, 230, 255, 70),
                         (cx - R, cy), (cx + R, cy), 1)
        pygame.draw.line(surf, (200, 230, 255, 70),
                         (cx, cy - R), (cx, cy + R), 1)
        kx = cx + self.knob[0] * R * 0.78
        ky = cy - self.knob[1] * R * 0.78
        disc(int(kx), int(ky), self.knob_r, (120, 255, 170, 165))
        ring(int(kx), int(ky), self.knob_r, 2, (220, 255, 235, 200))

        # ---- 动作按钮 ----
        styles = {
            TOUCH_FIRE: ((255, 96, 84), '开火'),
            TOUCH_MSL: ((255, 176, 64), '导弹'),
            TOUCH_FLR: ((120, 210, 255), '干扰'),
            TOUCH_BRK: ((210, 210, 210), '减速'),
            TOUCH_VIEW: ((190, 190, 190), '视角'),
            TOUCH_PAUSE: ((190, 190, 190), '暂停'),
            TOUCH_SET: ((150, 200, 235), '设置'),
        }
        for act, (bx, by, br) in self.btns.items():
            col, label = styles[act]
            a = 150 if act in self.held else 78
            disc(bx, by, br, (col[0], col[1], col[2], a))
            c2 = (255, 255, 255, 190) if act in self.held else (col[0], col[1], col[2], 210)
            ring(bx, by, br, 2, c2)
            if act == TOUCH_SET:
                draw_gear(surf, bx, by, int(br * 0.62), (255, 255, 255, 225))
            else:
                fs = max(13, int(br * 0.42))
                draw_text(surf, label, (bx, by), fs, (255, 255, 255),
                          bold=True, center=True, shadow=False)

        # ---- 油门滑钮 ----
        # 标签跟随滑钮并左偏，避免和右上角战绩、右侧高度带撞在一起
        x = self.thr_x
        pygame.draw.line(surf, (200, 230, 255, 110),
                         (x, self.thr_top), (x, self.thr_bot), 6)
        ty = self.thr_bot - (self.thr_bot - self.thr_top) * self.throttle
        pygame.draw.line(surf, (255, 190, 70, 200),
                         (x, self.thr_bot), (x, int(ty)), 6)
        disc(x, int(ty), self.thr_r, (255, 200, 90, 190))
        ring(x, int(ty), self.thr_r, 2, (255, 240, 200, 220))
        lx = x - self.thr_r - 8
        draw_text(surf, '油门 %d%%' % int(self.throttle * 100), (lx, int(ty) - 8),
                  14, (255, 210, 120), right=True)


# ==============================================================================
#  9. HUD
# ==============================================================================

HUD_GREEN = (96, 255, 148)
HUD_AMBER = (255, 196, 64)
HUD_RED = (255, 82, 72)


def hud_pitch_ladder(surf, cam, ac):
    """用真实投影画姿态梯"""
    cx, cy = cam.cx, cam.cy
    clip = pygame.Rect(int(cx - 330), int(cy - 250), 660, 500)
    old = surf.get_clip()
    surf.set_clip(clip)
    pd = ac.pitch_deg()
    for a in range(-80, 81, 10):
        if abs(a - pd) > 47:
            continue
        dirv = rot_axis(ac.fwd, ac.right, math.radians(a))
        neg = a < 0
        half = math.radians(3.6)
        d1 = rot_axis(dirv, ac.up, -half)
        d2 = rot_axis(dirv, ac.up, half)
        p0 = cam.project_dir(vmul(dirv, 8000.0))
        pa = cam.project_dir(vmul(d1, 8000.0))
        pb = cam.project_dir(vmul(d2, 8000.0))
        if p0 is None or pa is None or pb is None:
            continue
        col = HUD_GREEN if not neg else (HUD_GREEN[0] // 2 + 60, HUD_GREEN[1] // 2 + 90, HUD_GREEN[2] // 2 + 60)
        if a == 0:
            pygame.draw.line(surf, col, (int(pa[0]), int(pa[1])), (int(pb[0]), int(pb[1])), 2)
        else:
            # 虚线横杆
            n = 8
            for i in range(0, n, 2):
                t0 = i / float(n)
                t1 = (i + 1) / float(n)
                x0 = lerp(pa[0], pb[0], t0)
                y0 = lerp(pa[1], pb[1], t0)
                x1 = lerp(pa[0], pb[0], t1)
                y1 = lerp(pa[1], pb[1], t1)
                pygame.draw.line(surf, col, (int(x0), int(y0)), (int(x1), int(y1)), 2)
            lx = lerp(pa[0], pb[0], 0.5)
            ly = lerp(pa[1], pb[1], 0.5)
            draw_text(surf, str(abs(a)), (int(lx + 16), int(ly - 8)), 13, col, shadow=False)
    surf.set_clip(old)


def hud_fpm(surf, cam, ac):
    """飞行路径标记（速度矢量）"""
    if vlen(ac.vel) < 12:
        return
    p = cam.project_dir(vmul(vnorm(ac.vel), 8000.0))
    if p is None:
        return
    x, y = int(p[0]), int(p[1])
    pygame.draw.circle(surf, HUD_GREEN, (x, y), 5, 1)
    pygame.draw.line(surf, HUD_GREEN, (x - 20, y), (x - 11, y), 2)
    pygame.draw.line(surf, HUD_GREEN, (x + 11, y), (x + 20, y), 2)
    pygame.draw.line(surf, HUD_GREEN, (x, y - 11), (x, y - 16), 2)


def hud_reticle(surf, cam):
    cx, cy = int(cam.cx), int(cam.cy)
    pygame.draw.circle(surf, HUD_GREEN, (cx, cy), 3, 1)
    pygame.draw.line(surf, HUD_GREEN, (cx - 34, cy), (cx - 10, cy), 1)
    pygame.draw.line(surf, HUD_GREEN, (cx + 10, cy), (cx + 34, cy), 1)
    pygame.draw.line(surf, HUD_GREEN, (cx, cy - 26), (cx, cy - 10), 1)
    for i in range(1, 5):
        pygame.draw.line(surf, (60, 150, 90), (cx, cy + 8 + i * 7), (cx, cy + 11 + i * 7), 1)


def hud_layout(w, h, touch):
    """HUD 各模块的位置参数。

    桌面按 1280×720 设计；手机横屏只有 ~960×443，而且四角被触屏
    控件占着，竖向空间更是不到桌面的一半，必须重新排布，
    否则速度带 / 高度带 / 雷达会和摇杆、按钮叠在一起。
    """
    L = {}
    if touch:
        # 顶部要让给帧率/机体状态，底部要让给航向带，取中间一段
        L['bar_top'] = int(h * 0.48)
        L['bar_bot'] = int(h * 0.78)
        L['spd_x'] = 52            # 摇杆左侧（摇杆占 x 77~239）
        L['alt_x'] = w - 340       # 按钮左侧（按钮占 x 674~931）
        L['vs_x'] = w - 320
        L['radar_c'] = (int(w * 0.52), int(h * 0.74))
        L['radar_r'] = 48
        # 左下角被摇杆、底部被航向带占着；触屏时油门已由右侧滑钮显示，
        # 这里只在帧率旁边显示一个 G 值，不再画整条油门条
        L['gt_c'] = (132, 58)
    else:
        L['bar_top'] = int(h * 0.26)
        L['bar_bot'] = int(h * 0.72)
        L['spd_x'] = 74
        L['alt_x'] = w - 74
        L['vs_x'] = w - 26
        L['radar_c'] = (w - 112, h - 108)
        L['radar_r'] = 82
        L['gt_c'] = (40, h - 120)
    return L


def hud_bars(surf, cam, ac, touch=False):
    w, h = cam.w, cam.h
    L = hud_layout(w, h, touch)
    top, bot = L['bar_top'], L['bar_bot']
    # ---- 空速（左）----
    x = L['spd_x']
    spd = ac.speed
    t = clamp((spd - 40) / 400.0, 0.0, 1.0)
    y = bot - (bot - top) * t
    pygame.draw.line(surf, HUD_GREEN, (x, top), (x, bot), 2)
    pygame.draw.line(surf, HUD_GREEN, (x, int(y)), (x + 20, int(y)), 3)
    for v in range(0, 450, 50):
        tt = clamp((v - 40) / 400.0, 0.0, 1.0)
        yy = int(bot - (bot - top) * tt)
        ln = 12 if v % 100 == 0 else 7
        pygame.draw.line(surf, HUD_GREEN, (x - ln, yy), (x, yy), 1)
        if v % 100 == 0:
            draw_text(surf, str(v), (x - 36, yy - 7), 13, HUD_GREEN, shadow=False)
    draw_text(surf, '空速 KTS', (x - 30, top - 26), 15, HUD_GREEN)
    draw_text(surf, '%3d' % int(spd * 1.944), (x - 32, bot + 10), 22, HUD_GREEN, bold=True)

    # ---- 高度（右）----
    x = L['alt_x']
    alt = ac.alt()
    t = clamp(alt / 8000.0, 0.0, 1.0)
    y = bot - (bot - top) * t
    pygame.draw.line(surf, HUD_GREEN, (x, top), (x, bot), 2)
    pygame.draw.line(surf, HUD_GREEN, (x, int(y)), (x - 20, int(y)), 3)
    for v in range(0, 8001, 1000):
        tt = clamp(v / 8000.0, 0.0, 1.0)
        yy = int(bot - (bot - top) * tt)
        pygame.draw.line(surf, HUD_GREEN, (x, yy), (x + 12, yy), 1)
        draw_text(surf, str(v), (x + 18, yy - 7), 13, HUD_GREEN, shadow=False)
    draw_text(surf, '高度 FT', (x - 34, top - 26), 15, HUD_GREEN)
    draw_text(surf, '%5d' % int(alt * 3.281), (x - 46, bot + 10), 22, HUD_GREEN, bold=True)

    # ---- 升降率（右侧细条）----
    vs = ac.vel[1]
    x2 = L['vs_x']
    mid = (top + bot) // 2
    yy = mid - clamp(vs * 3.0, -110, 110)
    pygame.draw.line(surf, HUD_GREEN, (x2, top + 40), (x2, bot - 40), 1)
    pygame.draw.line(surf, HUD_AMBER, (x2, mid), (x2 + 8, mid), 1)
    pygame.draw.line(surf, HUD_AMBER, (x2 - 5, int(yy)), (x2 + 5, int(yy)), 2)

    # ---- 航向带（底）----
    bw = 520
    bx = (w - bw) // 2
    by = h - 52
    hd = ac.heading_deg()
    pygame.draw.rect(surf, (10, 30, 20, 160), (bx, by - 6, bw, 30))
    for i in range(-6, 7):
        deg = (int(hd // 10) * 10 + i * 10) % 360
        off = ((deg - hd + 180) % 360) - 180
        sx = bx + bw / 2 + off * 4.4
        if sx < bx or sx > bx + bw:
            continue
        big = deg % 30 == 0
        pygame.draw.line(surf, HUD_GREEN, (int(sx), by + 18), (int(sx), by + (0 if big else 10)), 1)
        if big:
            lbl = {0: 'N', 90: 'E', 180: 'S', 270: 'W'}.get(deg, str(deg // 10))
            draw_text(surf, lbl, (int(sx), by - 26), 15, HUD_GREEN, center=True, shadow=False)
    pygame.draw.line(surf, HUD_AMBER, (bx + bw // 2, by - 10), (bx + bw // 2, by + 20), 2)

    # ---- 过载 / 油门 ----
    tx, ty = L['gt_c']
    if touch:
        # 触屏：油门由右侧滑钮显示，这里只留 G 值
        draw_text(surf, 'G %.1f' % ac.g_force, (tx, ty), 17, HUD_GREEN, bold=True)
    else:
        pygame.draw.rect(surf, (0, 0, 0), (tx, ty, 150, 14))
        pygame.draw.rect(surf, HUD_AMBER, (tx, ty, int(150 * ac.throttle), 14))
        pygame.draw.rect(surf, HUD_GREEN, (tx, ty, 150, 14), 1)
        draw_text(surf, '油门 %d%%' % int(ac.throttle * 100), (tx, ty - 22), 15, HUD_AMBER)
        draw_text(surf, 'G  %.1f' % ac.g_force, (tx + 165, ty - 4), 17, HUD_GREEN, bold=True)


def hud_radar(surf, cam, ac, enemies, lock_target, w, h, touch=False):
    cx, cy = hud_layout(w, h, touch)['radar_c']
    R = hud_layout(w, h, touch)['radar_r']
    pygame.draw.circle(surf, (8, 26, 16), (cx, cy), R)
    pygame.draw.circle(surf, HUD_GREEN, (cx, cy), R, 1)
    for r in (R * 0.33, R * 0.66):
        pygame.draw.circle(surf, (40, 110, 66), (cx, cy), int(r), 1)
    pygame.draw.line(surf, (40, 110, 66), (cx - R, cy), (cx + R, cy), 1)
    pygame.draw.line(surf, (40, 110, 66), (cx, cy - R), (cx, cy + R), 1)
    # 视野扇形（机体前方 60°）
    hd = math.radians(ac.heading_deg())
    pts = [(cx, cy)]
    for a in range(-30, 31, 10):
        aa = hd + math.radians(a)
        pts.append((cx + math.sin(aa) * R, cy - math.cos(aa) * R))
    pygame.draw.polygon(surf, (30, 80, 50), pts)
    scale = R / 5000.0
    for e in enemies:
        if e.dead:
            continue
        dx = e.pos[0] - ac.pos[0]
        dz = e.pos[2] - ac.pos[2]
        rr = math.hypot(dx, dz) * scale
        if rr > R:
            rr = R
        aa = math.atan2(dx, -dz)
        sx = cx + math.sin(aa - hd) * rr
        sy = cy - math.cos(aa - hd) * rr
        c = HUD_RED if e is lock_target else (255, 140, 60)
        pygame.draw.circle(surf, c, (int(sx), int(sy)), 4)
    pygame.draw.circle(surf, HUD_GREEN, (cx, cy), 3)
    draw_text(surf, '雷达 5km', (cx, cy + R + 6), 13, HUD_GREEN, center=True)


def hud_lock(surf, cam, target, lock_t, locked):
    p = cam.project(target.pos)
    if p is None:
        return
    x, y = int(p[0]), int(p[1])
    if locked:
        col = HUD_RED
        s = 26
        pygame.draw.line(surf, col, (x - s, y - s), (x - s + 9, y - s), 2)
        pygame.draw.line(surf, col, (x - s, y - s), (x - s, y - s + 9), 2)
        pygame.draw.line(surf, col, (x + s, y - s), (x + s - 9, y - s), 2)
        pygame.draw.line(surf, col, (x + s, y - s), (x + s, y - s + 9), 2)
        pygame.draw.line(surf, col, (x - s, y + s), (x - s + 9, y + s), 2)
        pygame.draw.line(surf, col, (x - s, y + s), (x - s, y + s - 9), 2)
        pygame.draw.line(surf, col, (x + s, y + s), (x + s - 9, y + s), 2)
        pygame.draw.line(surf, col, (x + s, y + s), (x + s, y + s - 9), 2)
        d = vlen(vsub(target.pos, cam.pos))
        draw_text(surf, 'LOCK  %dm' % int(d), (x + s + 8, y - 8), 16, HUD_RED, bold=True)
    else:
        col = HUD_GREEN
        s = 30
        r = int(s * (1.0 - lock_t))
        for dx, dy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
            pygame.draw.line(surf, col, (x + dx * s, y + dy * s),
                             (x + dx * (s - 11), y + dy * s), 2)
            pygame.draw.line(surf, col, (x + dx * s, y + dy * s),
                             (x + dx * s, y + dy * (s - 11)), 2)
        if r > 0 and lock_t > 0.01:
            pygame.draw.arc(surf, HUD_AMBER, (x - s, y - s, s * 2, s * 2),
                            -math.pi / 2, -math.pi / 2 + math.pi * 2 * lock_t, 2)


def enemy_threat_info(game):
    """评估最近的敌机在干什么、是否咬住了你。

    返回 (描述, 颜色, 是否咬尾)。玩家看不到 AI 内部状态，
    这个函数把它翻译成一句人话显示在 HUD 上。
    """
    p = game.player
    if p.dead:
        return None
    best = None
    best_d = 1e18
    for e in game.enemies:
        if e.dead:
            continue
        d = vlen(vsub(e.pos, p.pos))
        if d < best_d:
            best_d = d
            best = e
    if best is None or best_d > 3200.0:
        return None

    to_p = vnorm(vsub(p.pos, best.pos))
    # 敌机机头是否指向你（点积接近 1 = 正对着你）
    facing = vdot(best.fwd, to_p)
    # 你是否在敌机尾部锥形范围内
    tailing = facing > 0.86 and best_d < 1800.0

    if tailing:
        desc, col = '咬住你了', HUD_RED
    else:
        desc, col = ENEMY_STATE_INFO.get(best.state, DEFAULT_STATE_INFO)
        if best_d < 600.0:
            desc = '近距缠斗'
    return (desc, col, tailing, best_d)


def fail_detail(game):
    """坠毁时回溯：到底违反了哪一条失败条件（把死因讲清楚）"""
    reason = game.end_reason or ''
    p = game.player
    if '击毁' in reason:
        return '失败条件：血量归零 —— 被敌机机炮或导弹连续命中'
    if '撞地' not in reason:
        return ''
    # 撞地：逐条比对着陆判据，指出是哪一项超标
    bad = []
    if p.speed > 200.0:
        bad.append('着陆速度 %.0f m/s（上限 200）' % p.speed)
    if abs(p.bank_deg()) >= 22.0:
        bad.append('坡度 %.0f°（上限 22°）' % abs(p.bank_deg()))
    if abs(p.pitch_deg()) >= 16.0:
        bad.append('俯仰 %.0f°（上限 16°）' % abs(p.pitch_deg()))
    if -p.vel[1] >= 13.0:
        bad.append('下降率 %.1f m/s（上限 13）' % -p.vel[1])
    if not bad:
        return '失败条件：触地姿态/速度超限 —— 需下降率<13、坡度<22°、俯仰<16°、速度<200'
    return '失败条件：' + '、'.join(bad)


def danger_states(game):
    """当前处于哪些致命状态（还没死，但再不改就要死）"""
    p = game.player
    out = []
    if p.dead or not p.airborne:
        return out
    if p.speed < 105.0:
        out.append(('失速  空速不足，压低机头换速度', HUD_RED))
    if p.alt() > MAX_ALT - 400.0:
        out.append(('接近升限  再高会失速下坠', HUD_AMBER))
    if p.agl() < 90.0:
        out.append(('低空警告  PULL UP', HUD_RED))
    if game.missile_alert > 0:
        out.append(('导弹来袭  立即释放干扰弹', HUD_RED))
    return out


def hud_mission(surf, game, w, h):
    """顶部任务进度条：当前波次还剩几架、打到第几波"""
    alive = sum(1 for e in game.enemies if not e.dead)
    total = game.wave_total or max(alive, 1)
    done = total - alive
    txt = '任务：第 %d 波   击落 %d / %d' % (game.wave, done, total)
    col = HUD_GREEN if alive else HUD_AMBER
    draw_text(surf, txt, (w // 2, 14), 17, col, center=True, bold=True)

    # 进度条
    bw, bh = 210, 6
    bx, by = w // 2 - bw // 2, 36
    pygame.draw.rect(surf, (0, 0, 0), (bx, by, bw, bh))
    pygame.draw.rect(surf, (70, 95, 90), (bx, by, bw, bh), 1)
    if total > 0:
        fw = int(bw * clamp(done / float(total), 0.0, 1.0))
        if fw > 0:
            pygame.draw.rect(surf, HUD_GREEN, (bx, by, fw, bh))


def hud_enemy_state(surf, game, w, h):
    """中上方：最近敌机在干什么 —— 让 AI 行为对玩家可见"""
    info = enemy_threat_info(game)
    if info is None:
        return
    desc, col, tailing, dist = info
    label = '敌机：%s   %dm' % (desc, int(dist))
    if tailing:
        # 咬尾时闪烁，逼玩家做动作
        if int(game.time * 6) % 2 == 0:
            draw_text(surf, '⚠ ' + label + '   立即机动规避', (w // 2, 58),
                      18, col, center=True, bold=True)
    else:
        draw_text(surf, label, (w // 2, 58), 16, col, center=True)


def hud_fps(surf, game):
    """左上角实时帧率（含最低帧率记忆，便于观察卡顿点）

    触屏模式下左上角被「暂停」按钮占着，整体下移让开。
    """
    fps = game.fps
    col = HUD_GREEN if fps >= 48 else (HUD_AMBER if fps >= 30 else HUD_RED)
    y0 = 58 if game.touch.active else 16
    draw_text(surf, 'FPS %2d' % int(fps + 0.5), (28, y0), 19, col, bold=True)
    draw_text(surf, '最低 %2d' % int(game.fps_min + 0.5), (28, y0 + 24), 13,
              (150, 170, 190))
    # GPU 模式额外显示渲染后端与三角形数，方便对比两种模式谁更快
    if game.use_gl and game.gl.ok:
        draw_text(surf, 'GPU %d 面' % game.gl.tris, (28, y0 + 44), 13,
                  (120, 220, 255))


def hud_status(surf, ac, game, w, h):
    # 左上：机体状态（触屏时避开左上角暂停按钮）
    x = 28
    y = 100 if game.touch.active else 64
    draw_text(surf, '机体', (x, y), 15, HUD_GREEN)
    pygame.draw.rect(surf, (0, 0, 0), (x + 44, y + 2, 180, 14))
    hp = clamp(ac.hp / ac.max_hp, 0, 1)
    c = HUD_GREEN if hp > 0.55 else (HUD_AMBER if hp > 0.25 else HUD_RED)
    pygame.draw.rect(surf, c, (x + 44, y + 2, int(180 * hp), 14))
    pygame.draw.rect(surf, (200, 220, 200), (x + 44, y + 2, 180, 14), 1)
    draw_text(surf, '%d%%' % int(hp * 100), (x + 232, y), 14, c)

    draw_text(surf, '导弹 AAM ×%d' % ac.missiles, (x, y + 30), 16,
              HUD_GREEN if ac.missiles else (120, 120, 120))
    draw_text(surf, '干扰弹 ×%d' % ac.flares, (x, y + 52), 16,
              HUD_GREEN if ac.flares else (120, 120, 120))
    draw_text(surf, '机炮 ∞', (x, y + 74), 16, HUD_GREEN)

    # 右上：战绩（触屏时右上角是「视角」按钮，整体下移让开）
    ty = 58 if game.touch.active else 24
    draw_text(surf, '得分  %d' % game.score, (w - 28, ty), 20, HUD_AMBER,
              right=True, bold=True)
    draw_text(surf, '击落  %d' % game.kills, (w - 28, ty + 28), 16, HUD_GREEN,
              right=True)
    draw_text(surf, '波次  第 %d 波' % game.wave, (w - 28, ty + 50), 16, HUD_GREEN,
              right=True)
    left = sum(1 for e in game.enemies if not e.dead)
    draw_text(surf, '本波剩余敌机 %d' % left, (w - 28, ty + 72), 15, HUD_RED,
              right=True)
    best = int(game.save.get('best_score', 0))
    if best:
        col = HUD_AMBER if game.score > best else (140, 160, 150)
        draw_text(surf, '最高分 %d' % best, (w - 28, ty + 94), 14, col, right=True)

    # 中央下：警告
    # 失败条件预警：把"再不改就要死"的状态摆到屏幕中央
    msgs = danger_states(game)
    if not msgs:
        return
    y0 = int(h * 0.30)
    for i, (m, c) in enumerate(msgs):
        # 红色（真正致命）常亮闪烁，黄色（提醒）稳定显示
        show = True if c is not HUD_RED else (int(game.time * 6) % 2 == 0)
        if show:
            draw_text(surf, m, (w // 2, y0 + i * 26), 19, c,
                      center=True, bold=True)


def hud_damage_flash(surf, game, w, h):
    if game.hit_flash > 0:
        a = clamp(game.hit_flash * 130, 0, 150)
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        s.fill((255, 40, 30, int(a)))
        surf.blit(s, (0, 0))
    # 黑视（高 G）
    g = game.player.g_force
    if g > 5.2:
        t = clamp((g - 5.2) / 3.0, 0, 1) * 0.55
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        s.fill((0, 0, 0, int(210 * t)))
        # 中心留一个圆
        pygame.draw.circle(s, (0, 0, 0, 0), (w // 2, h // 2), int(200 - 130 * t))
        surf.blit(s, (0, 0))


def draw_cockpit(surf, cam):
    """座舱视角的框架"""
    w, h = cam.w, cam.h
    dark = (26, 30, 34)
    # 仪表台
    pygame.draw.polygon(surf, dark, [(0, h), (0, h - 92),
                                     (int(w * 0.22), h - 128),
                                     (int(w * 0.78), h - 128),
                                     (w, h - 92), (w, h)])
    pygame.draw.line(surf, (70, 78, 86), (0, h - 92), (int(w * 0.22), h - 128), 2)
    pygame.draw.line(surf, (70, 78, 86), (w, h - 92), (int(w * 0.78), h - 128), 2)
    # 座舱盖支柱
    pygame.draw.line(surf, (58, 64, 70), (int(w * 0.5), 0), (int(w * 0.5), int(h * 0.10)), 12)
    pygame.draw.line(surf, (58, 64, 70), (0, int(h * 0.30)), (int(w * 0.30), int(h * 0.06)), 14)
    pygame.draw.line(surf, (58, 64, 70), (w, int(h * 0.30)), (int(w * 0.70), int(h * 0.06)), 14)
    pygame.draw.line(surf, (58, 64, 70), (0, h), (0, int(h * 0.42)), 16)
    pygame.draw.line(surf, (58, 64, 70), (w, h), (w, int(h * 0.42)), 16)


# ==============================================================================
#  10. 游戏主体
# ==============================================================================

STATE_MENU = 0
STATE_PLAY = 1
STATE_PAUSE = 2
STATE_OVER = 3


class Game(object):
    def __init__(self, screen, sfx):
        self.screen = screen
        self.sfx = sfx
        self.rw = screen.get_width()
        self.rh = screen.get_height()
        self.rbuf = pygame.Surface((self.rw, self.rh))
        self.cam = Camera(self.rw, self.rh)
        self.touch = TouchUI(self.rw, self.rh)
        self.state = STATE_MENU
        self.terrain_rings = TERRAIN_RINGS
        self.frame_avg = 16.0
        self.fps = 60.0
        self.fps_min = 60.0
        self._scaled = None
        self.qmul = 1.0
        self.view = (0, 0, 1.0, 1.0)
        self.save = load_save()
        self.new_record = False      # 本局是否刷新纪录
        self.settings = Settings()
        self.setpanel = SettingsPanel(self.settings)
        self.settings_open = False
        self.gl = GLRenderer()       # 未 setup 前 ok=False，走 CPU 后端
        self.use_gl = False
        self._last_sun = None        # 上一帧太阳屏幕位置（判断天空是否需重传）
        self.reset()

    def set_render_size(self, rw, rh):
        """设置内部渲染分辨率（可低于物理屏幕，大幅提升填充率）

        GPU 模式下 GL 直接按 1:1 渲染到窗口（GPU 填充率不是瓶颈，
        降分辨率只会让画面变糊），但仍同步相机与触控布局坐标。
        """
        rw = max(480, int(rw))
        rh = max(270, int(rh))
        if rw < rh:                      # 渲染缓冲始终保持横屏
            rw, rh = rh, rw
        self.rw = rw
        self.rh = rh
        if self.use_gl and self.gl.ok:
            # GL 模式：3D 按物理窗口全分辨率画（GPU 填充率不是瓶颈），
            # 但 HUD 叠加层仍按画质档位缩放——它每帧要上传纹理，
            # 全分辨率上传会白白吃掉 GPU 省下来的时间。
            sw, sh = self.screen.get_size()
            self.gl.vw, self.gl.vh = max(320, sw), max(240, sh)
        self.rbuf = pygame.Surface((rw, rh))
        self.cam.set_surface(rw, rh)
        self.touch.set_size(rw, rh)
        self._scaled = None
        if self.use_gl and self.gl.ok:
            self.gl.resize(rw, rh)

    def present(self):
        """把渲染缓冲输出到物理屏幕。

        缓冲宽高比与窗口一致，所以正常情况下直接整屏铺满、零黑边。
        只有竖屏（窗口比例和缓冲差太多）时才可能出现黑边，
        那种情况按设置决定：铺满=拉伸填满，适应=保留黑边。
        """
        sw, sh = self.screen.get_size()
        rw, rh = self.rw, self.rh
        if self.use_gl and self.gl.ok:
            # GL 已直接画进窗口；HUD 是按 rw/rh 布局后拉伸到视口的，
            # 所以点击要按 视口/叠加层 的比值反算回 HUD 坐标系。
            self.view = (0, 0, sw / float(rw), sh / float(rh))
            return
        if (sw, sh) == (rw, rh):
            self.view = (0, 0, 1.0, 1.0)
            self.screen.blit(self.rbuf, (0, 0))
            return

        stretch = bool(self.settings.fill_mode)
        sx = sw / float(rw)
        sy = sh / float(rh)
        if stretch:
            fx, fy = sx, sy               # 非等比：一定铺满
        else:
            f = min(sx, sy)
            fx = fy = f
        dw, dh = max(1, int(rw * fx)), max(1, int(rh * fy))
        ox, oy = (sw - dw) // 2, (sh - dh) // 2
        if ox > 0:
            self.screen.fill((0, 0, 0), (0, 0, ox, sh))
            self.screen.fill((0, 0, 0), (sw - ox, 0, ox, sh))
        if oy > 0:
            self.screen.fill((0, 0, 0), (0, 0, sw, oy))
            self.screen.fill((0, 0, 0), (0, sh - oy, sw, oy))
        if (dw, dh) == (rw, rh):
            self.screen.blit(self.rbuf, (ox, oy))
        else:
            buf = self._scaled
            if buf is None or buf.get_size() != (dw, dh):
                buf = pygame.Surface((dw, dh))
                self._scaled = buf
            pygame.transform.scale(self.rbuf, (dw, dh), buf)
            self.screen.blit(buf, (ox, oy))
        self.view = (ox, oy, fx, fy)

    def screen_to_render(self, mx, my):
        """物理屏幕坐标 → 渲染缓冲坐标。

        Termux X11 / Pydroid 把触摸上报成鼠标事件，给的坐标是物理屏幕的，
        而所有控件都按渲染缓冲布局，所以必须做这个反变换，
        否则点了位置和判定位置对不上，表现就是「点击没反应」。
        """
        v = getattr(self, 'view', (0, 0, 1.0, 1.0))
        ox, oy, fx, fy = v
        if fx <= 0:
            fx = 1.0
        if fy <= 0:
            fy = 1.0
        return (int((mx - ox) / fx), int((my - oy) / fy))

    # ------------------------------------------------------------------
    def reset(self):
        self.time = 0.0
        self.score = 0
        self.kills = 0
        self.wave = 1
        self.new_record = False
        self.shots = 0
        self.hits = 0
        self.hit_flash = 0.0
        self.missile_alert = 0.0
        self.shake = 0.0
        self.message = ('', 0.0)
        self.end_reason = ''

        self.particles = []
        self.bullets = []
        self.missiles = []
        self.flares = []
        self.clouds = []

        # 玩家：停放在跑道南端，机头朝 -Z（跑道方向）
        gh = terrain_h(0.0, RUNWAY_HALF_L - 150.0)
        self.player = Aircraft((0.0, gh + 2.2, RUNWAY_HALF_L - 150.0),
                               (0.0, 0.0, -1.0), is_player=True, model=MODEL_PLAYER)
        self.player.name = '玩家'

        self.enemies = []
        self.spawn_wave()

        self.lock_target = None
        self.lock_t = 0.0
        self.locked = False
        self.lock_beep = 0.0
        self.cam_fwd = self.player.fwd
        self.cam_up = self.player.up
        self.cam_pos = self.player.pos
        self.view_mode = 0          # 0=第三人称 1=座舱
        self.acc = 0.0
        self.hit_mark = 0.0

        # 云
        random.seed(12345)
        for i in range(CLOUD_COUNT):
            self.clouds.append(self._new_cloud(near=True))

    def _new_cloud(self, near=False):
        if near:
            a = random.uniform(0, math.pi * 2)
            r = random.uniform(300, 6500)
        else:
            a = random.uniform(0, math.pi * 2)
            r = random.uniform(5500, 7800)
        px = self.player.pos[0] + math.cos(a) * r
        pz = self.player.pos[2] + math.sin(a) * r
        return [px, random.uniform(1300, 2600), pz,
                random.uniform(240, 720), random.uniform(0.65, 1.0),
                random.uniform(0.42, 0.62)]

    # ------------------------------------------------------------------
    def spawn_wave(self):
        n = min(2 + self.wave, 7)
        self.wave_total = n            # 本波敌机总数，用于任务进度条
        diff = clamp(0.35 + self.wave * 0.09, 0.35, 0.95)
        for i in range(n):
            a = random.uniform(0, math.pi * 2)
            r = random.uniform(2200, 4200)
            alt = clamp(self.player.alt() + random.uniform(-500, 900), 500, 4500)
            px = self.player.pos[0] + math.cos(a) * r
            pz = self.player.pos[2] + math.sin(a) * r
            gh = terrain_h(px, pz)
            alt = max(alt, gh + 320)
            e = Aircraft((px, alt, pz), vnorm(vsub(self.player.pos, (px, alt, pz))),
                         is_player=False,
                         model=MODEL_ACE if (self.wave % 3 == 0 and i == 0) else MODEL_ENEMY)
            e.hp = e.max_hp = 45 + self.wave * 6
            e.throttle = 0.8
            e.airborne = True
            e.speed = 210
            e.vel = vmul(e.fwd, 210)
            e.skill = diff
            e.name = '敌机-%d' % (i + 1)
            e.missiles = 2 if self.wave >= 3 else 0
            self.enemies.append(e)

    # ------------------------------------------------------------------
    #  粒子 / 特效
    # ------------------------------------------------------------------
    def spawn_smoke(self, pos, r, col, life, grow=1.0):
        if len(self.particles) > PARTICLE_MAX:
            return
        self.particles.append(Particle(
            pos, (random.uniform(-4, 4), random.uniform(1, 7), random.uniform(-4, 4)),
            life * random.uniform(0.7, 1.25), r, r * 5.0 * grow, col))

    def spawn_explosion(self, pos, big=1.0):
        n = int(26 * big)
        for i in range(n):
            if len(self.particles) > PARTICLE_MAX + 60:
                break
            sp = random.uniform(18, 105) * big
            d = (random.uniform(-1, 1), random.uniform(-0.5, 1.1), random.uniform(-1, 1))
            self.particles.append(Particle(
                pos, vmul(vnorm(d), sp),
                random.uniform(0.5, 1.5) * big,
                random.uniform(1.6, 5.2) * big,
                random.uniform(6, 20) * big,
                (255, random.randint(150, 235), random.randint(40, 110))))
        for i in range(int(9 * big)):
            self.spawn_smoke(pos, 4.5 * big, (86, 82, 80), 2.2 * big)
        self.sfx.play('boom')
        d = vlen(vsub(pos, self.cam.pos))
        self.shake = max(self.shake, clamp(26.0 / max(1.0, d * 0.02), 0, 22) * big)

    def msg(self, text, dur=2.0):
        self.message = (text, dur)

    # ------------------------------------------------------------------
    #  更新
    # ------------------------------------------------------------------
    def update(self, dt, keys, frame_ms=16.0):
        # 自适应地形网格半径：掉帧时缩小视野，流畅时放宽
        # 上下限由画质档位决定（极速档允许砍到很低的环数）
        self.frame_avg = self.frame_avg * 0.92 + frame_ms * 0.08
        rmin = getattr(self, 'terrain_rings_min', 7)
        rmax = getattr(self, 'terrain_rings_max', TERRAIN_RINGS)
        if self.frame_avg > 26.0 and self.terrain_rings > rmin:
            self.terrain_rings -= 1
            self.frame_avg = 20.0
        elif self.frame_avg < 13.0 and self.terrain_rings < rmax:
            self.terrain_rings += 1
            self.frame_avg = 16.0

        self.time += dt
        self.hit_flash = max(0.0, self.hit_flash - dt * 2.2)
        self.hit_mark = max(0.0, self.hit_mark - dt)
        self.missile_alert = max(0.0, self.missile_alert - dt)
        self.shake *= math.exp(-4.0 * dt)
        if self.message[1] > 0:
            self.message = (self.message[0], self.message[1] - dt)

        p = self.player

        # ---------- 玩家输入（键盘 + 触屏）----------
        ctl = {'pitch': 0.0, 'roll': 0.0, 'yaw': 0.0,
               'throttle': 0.0, 'brake': False}
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            ctl['pitch'] += 1.0
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            ctl['pitch'] -= 1.0
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            ctl['roll'] -= 1.0
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            ctl['roll'] += 1.0
        if keys[pygame.K_q]:
            ctl['yaw'] -= 1.0
        if keys[pygame.K_e]:
            ctl['yaw'] += 1.0
        if keys[pygame.K_z]:
            ctl['brake'] = True

        t = self.touch
        if t.active:
            kx, ky = t.axis()
            if kx:
                ctl['roll'] = clamp(ctl['roll'] + kx, -1.0, 1.0)
            if ky:
                ctl['pitch'] = clamp(ctl['pitch'] + ky, -1.0, 1.0)
            if t.is_down(TOUCH_BRK):
                ctl['brake'] = True
            # 油门滑钮：拖动时直接接管，键盘调整会同步回滑钮
            if t.thr_id is not None:
                p.throttle = t.throttle
                ctl['throttle'] = 0.0
                self._thr_lock = True
            elif getattr(self, '_thr_lock', False):
                self._thr_lock = False
                t.throttle = p.throttle

        if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]:
            ctl['throttle'] += 1.0
        if keys[pygame.K_LCTRL] or keys[pygame.K_RCTRL]:
            ctl['throttle'] -= 1.0

        if p.update(dt, ctl, self):
            self.crash('撞地坠毁')

        if t.active and t.thr_id is None:
            t.throttle = p.throttle

        # ---------- 开火 ----------
        p.gun_cd -= dt
        p.flare_cd = max(0.0, p.flare_cd - dt)
        if (keys[pygame.K_SPACE] or (t.active and t.is_down(TOUCH_FIRE))) \
                and p.gun_cd <= 0 and not p.dead:
            self.fire_gun(p)

        # ---------- 锁定逻辑 ----------
        self.update_lock(dt)

        # ---------- 敌机 AI ----------
        for e in self.enemies:
            if e.dead:
                continue
            self.ai_update(e, dt)

        # ---------- 子弹 ----------
        for b in self.bullets[:]:
            b.update(dt)
            hits = False
            if b.owner == 'p':
                for e in self.enemies:
                    if e.dead:
                        continue
                    if seg_sphere(b.prev, b.pos, e.pos, e.radius + 4):
                        self.damage_enemy(e, b.dmg, b.pos)
                        hits = True
                        break
            else:
                if not p.dead and seg_sphere(b.prev, b.pos, p.pos, p.radius + 3):
                    self.damage_player(b.dmg, b.pos)
                    hits = True
            if not hits and b.pos[1] < terrain_h(b.pos[0], b.pos[2]):
                self.spawn_smoke(b.pos, 1.4, (150, 145, 130), 0.8)
                hits = True
            if hits or b.life <= 0:
                self.bullets.remove(b)

        # ---------- 导弹 ----------
        for m in self.missiles[:]:
            alive = m.update(dt, self)
            boom = False
            tgt = m.target
            if m.armed <= 0 and tgt is not None and not getattr(tgt, 'dead', True):
                if vlen(vsub(tgt.pos, m.pos)) < 26:
                    boom = True
                    if m.owner == 'p':
                        self.damage_enemy(tgt, MISSILE_DAMAGE, m.pos, missile=True)
                    else:
                        self.damage_player(MISSILE_DAMAGE, m.pos, missile=True)
            # 干扰弹诱骗：概率与停留时间、热源强度相关，被诱骗后飞向热源
            if not boom and m.decoy is None:
                for fl in self.flares:
                    if fl[3] <= 0:
                        continue
                    if vlen(vsub((fl[0], fl[1], fl[2]), m.pos)) < 145:
                        strength = clamp(fl[3] / 4.5, 0.0, 1.0)
                        if random.random() < dt * 2.6 * strength:
                            m.decoy = (fl[0], fl[1], fl[2])
                            m.target = None
                        break
            if not boom and m.decoy is not None and vlen(vsub(m.decoy, m.pos)) < 22:
                boom = True
            if not boom and m.pos[1] < terrain_h(m.pos[0], m.pos[2]):
                boom = True
            if boom:
                self.spawn_explosion(m.pos, 1.25)
            if boom or not alive:
                if m in self.missiles:
                    self.missiles.remove(m)

        # ---------- 干扰弹 ----------
        for fl in self.flares[:]:
            fl[0] += fl[5] * dt
            fl[1] += fl[6] * dt
            fl[2] += fl[7] * dt
            drag = math.exp(-1.7 * dt)
            fl[5] *= drag
            fl[7] *= drag
            fl[6] -= 32.0 * dt
            fl[3] -= dt
            fl[4] -= dt
            if fl[4] <= 0:
                fl[4] = 0.03
                self.spawn_smoke((fl[0], fl[1], fl[2]), 1.8, (255, 190, 90), 0.9)
            if fl[3] <= 0:
                self.flares.remove(fl)

        # ---------- 粒子 ----------
        for pt in self.particles[:]:
            if not pt.update(dt):
                self.particles.remove(pt)

        # ---------- 受损敌机拖烟 ----------
        for e in self.enemies:
            if e.dead:
                continue
            if e.hp < e.max_hp * 0.45:
                e.smoke_t -= dt
                if e.smoke_t <= 0:
                    e.smoke_t = 0.09
                    self.spawn_smoke(e.pos, 1.8, (70, 68, 66), 1.5)
        if p.hp < p.max_hp * 0.4 and p.airborne:
            p.smoke_t -= dt
            if p.smoke_t <= 0:
                p.smoke_t = 0.09
                self.spawn_smoke(p.pos, 1.6, (70, 68, 66), 1.4)

        # ---------- 波次推进 ----------
        alive = [e for e in self.enemies if not e.dead]
        if not alive:
            self.wave += 1
            self.score += 250 * self.wave
            self.enemies = []
            self.spawn_wave()
            ace = '  ·  含王牌机！' if self.wave % 3 == 0 else ''
            self.msg('第 %d 波：拦截 %d 架敌机%s'
                     % (self.wave, self.wave_total, ace), 3.0)

        # ---------- 云回收 ----------
        for c in self.clouds:
            dx = c[0] - p.pos[0]
            dz = c[2] - p.pos[2]
            if dx * dx + dz * dz > 8100 * 8100:
                nc = self._new_cloud()
                c[:] = nc

        # ---------- 相机 ----------
        self.update_camera(dt)

        # ---------- 被锁定警报 ----------
        alert = False
        for m in self.missiles:
            if m.owner == 'e' and m.target is self.player:
                alert = True
        if alert:
            self.missile_alert = 1.0
            if random.random() < dt * 2.2:
                self.sfx.play('alert')

    # ------------------------------------------------------------------
    def update_lock(self, dt):
        p = self.player
        best = None
        best_ang = 1e9
        for e in self.enemies:
            if e.dead:
                continue
            d = vsub(e.pos, p.pos)
            dist = vlen(d)
            if dist > LOCK_RANGE or dist < 30:
                continue
            ang = math.degrees(math.acos(clamp(vdot(vnorm(d), p.fwd), -1, 1)))
            if ang < LOCK_ANGLE and ang < best_ang:
                best_ang = ang
                best = e
        if best is not self.lock_target:
            self.lock_target = best
            self.lock_t = 0.0
            self.locked = False
        if best is not None:
            self.lock_t = clamp(self.lock_t + dt / LOCK_TIME, 0.0, 1.0)
            if self.lock_t >= 1.0 and not self.locked:
                self.locked = True
                self.sfx.play('lock')
        else:
            self.lock_t = 0.0
            self.locked = False

    # ------------------------------------------------------------------
    def fire_gun(self, ac):
        ac.gun_cd = GUN_ROF
        spread = 0.0022 if ac.is_player else 0.011
        d = (random.uniform(-spread, spread), random.uniform(-spread, spread), 1.0)
        dirv = vnorm(vadd(vadd(vmul(ac.right, d[0]), vmul(ac.up, d[1])), vmul(ac.fwd, d[2])))
        muzzle = vadd(ac.pos, vmul(ac.fwd, 11.0))
        vel = vadd(vmul(dirv, GUN_SPEED), ac.vel)
        self.bullets.append(Bullet(muzzle, vel, 'p' if ac.is_player else 'e'))
        self.particles.append(Particle(
            vadd(muzzle, vmul(ac.up, 0.2)), vmul(ac.right, random.uniform(-3, 3)),
            0.08, 1.4, 3.4, (255, 226, 150)))
        if ac.is_player:
            self.shots += 1
            self.sfx.play('gun')
            self.shake = max(self.shake, 1.6)

    def launch_missile(self, ac, target):
        if ac.missiles <= 0:
            return False
        ac.missiles -= 1
        m = Missile(vadd(ac.pos, vmul(ac.fwd, 8.0)), ac.fwd,
                    'p' if ac.is_player else 'e', target,
                    max(ac.speed, 200.0))
        self.missiles.append(m)
        self.sfx.play('missile')
        return True

    def drop_flare(self, ac):
        if ac.flares <= 0 or ac.flare_cd > 0:
            return
        ac.flares -= 1
        ac.flare_cd = 0.6
        back = vadd(vadd(ac.pos, vmul(ac.fwd, -16.0)), vmul(ac.up, -1.5))
        # 继承部分载机速度 + 侧向抛射，使其快速与载机分离
        vel = vadd(vmul(ac.vel, 0.5),
                   (random.uniform(-28, 28), random.uniform(-4, 16), random.uniform(-28, 28)))
        self.flares.append([back[0], back[1], back[2], 4.5, 0.0,
                            vel[0], vel[1], vel[2]])
        for i in range(6):
            self.spawn_smoke(back, 1.6, (255, 200, 110), 1.0)

    # ------------------------------------------------------------------
    def damage_enemy(self, e, dmg, pos, missile=False):
        if e.dead:
            return
        e.hp -= dmg
        self.spawn_smoke(pos, 1.2, (240, 200, 120), 0.5)
        if missile:
            self.spawn_explosion(pos, 0.9)
        if e.hp <= 0:
            e.dead = True
            self.kills += 1
            base = 120 if e.model is MODEL_ENEMY else 220
            self.score += base
            self.spawn_explosion(e.pos, 2.0)
            self.msg('击落 %s  +%d' % (e.name, base), 2.0)
            # 残骸
            for i in range(6):
                d = (random.uniform(-1, 1), random.uniform(-0.4, 0.6), random.uniform(-1, 1))
                self.particles.append(Particle(
                    e.pos, vmul(vnorm(d), random.uniform(25, 70)), 3.2,
                    1.6, 2.6, (60, 58, 56)))
        else:
            if not missile:
                self.sfx.play('hit')
                self.hit_mark = 0.22
                self.hits += 1

    def damage_player(self, dmg, pos, missile=False):
        p = self.player
        if p.dead:
            return
        p.hp -= dmg
        self.hit_flash = 1.0
        self.shake = max(self.shake, 9.0)
        self.sfx.play('hit')
        if p.hp <= 0:
            self.spawn_explosion(p.pos, 2.4)
            self.crash('机体被击毁')

    def crash(self, reason):
        p = self.player
        if p.dead:
            return
        p.dead = True
        self.spawn_explosion(p.pos, 2.6)
        self.end_reason = reason
        self.state = STATE_OVER
        self.commit_save()

    # ------------------------------------------------------------------
    def commit_save(self):
        """结算并写盘：刷新最高分 / 最远波次 / 累计击落"""
        s = self.save
        s['runs'] = int(s.get('runs', 0)) + 1
        s['total_kills'] = int(s.get('total_kills', 0)) + self.kills
        beat_score = self.score > int(s.get('best_score', 0))
        beat_wave = self.wave > int(s.get('best_wave', 0))
        if beat_score:
            s['best_score'] = int(self.score)
        if beat_wave:
            s['best_wave'] = int(self.wave)
        self.new_record = beat_score or beat_wave
        write_save(s)

    # ------------------------------------------------------------------
    #  敌机 AI
    # ------------------------------------------------------------------
    def ai_update(self, e, dt):
        p = self.player
        e.gun_cd -= dt
        e.flare_cd = max(0.0, e.flare_cd - dt)
        e.ai_timer -= dt
        to_p = vsub(p.pos, e.pos)
        dist = vlen(to_p)

        # 被导弹追击 → 规避
        threat = None
        for m in self.missiles:
            if m.owner == 'p' and m.target is e:
                threat = m
                break
        if threat is not None:
            e.state = 'evade'
            e.evade_t = 1.4
            if e.flares > 0 and e.flare_cd <= 0 and random.random() < dt * 1.6:
                self.drop_flare(e)
        elif e.evade_t > 0:
            e.evade_t -= dt
        elif dist < 260:
            e.state = 'break'
        else:
            e.state = 'pursue'

        # 期望方向
        lead_t = clamp(dist / 900.0, 0.0, 1.3)
        aim_point = vadd(p.pos, vmul(p.vel, lead_t))
        if not p.airborne and e.state == 'pursue':
            # 玩家还在地面：敌机在上方盘旋等待，不做俯冲扫射
            side = vnorm(vcross(vsub(e.pos, p.pos), WORLD_UP))
            tgt_alt = p.alt() + 900.0
            aim_point = (e.pos[0] + side[0] * 1200.0, tgt_alt,
                         e.pos[2] + side[2] * 1200.0)
        if e.state == 'evade':
            side = vnorm(vcross(vsub(e.pos, p.pos), WORLD_UP))
            aim_point = vadd(e.pos, vmul(side, 900.0))
            aim_point = vadd(aim_point, vmul(WORLD_UP, 260.0))
        elif e.state == 'break':
            side = vnorm(vcross(e.fwd, WORLD_UP))
            aim_point = vadd(vadd(e.pos, vmul(side, 700.0)), vmul(WORLD_UP, 340.0))

        desired = vnorm(vsub(aim_point, e.pos))

        # 高度保护：太低则强制拉起
        agl = e.agl()
        if agl < 220:
            desired = vnorm(vadd(desired, vmul(WORLD_UP, 1.9)))
        elif e.alt() > MAX_ALT - 300:
            desired = vnorm(vadd(desired, vmul(WORLD_UP, -1.2)))

        max_rate = lerp(0.55, 1.5, e.skill)
        e.fwd = rotate_towards(e.fwd, desired, max_rate * dt)

        # 姿态：up 尽量朝上，并按转向方向压坡度（视觉效果）
        turn_side = vdot(vcross(e.fwd, desired), WORLD_UP)
        bank = clamp(-turn_side * 5.0, -1.0, 1.0) * 1.05
        e.bank_vis = lerp(e.bank_vis, bank, 1.0 - math.exp(-3.0 * dt))
        ref_up = vadd(WORLD_UP, vmul(e.right, e.bank_vis))
        e.fwd, e.up, e.right = orthonormalize(e.fwd, ref_up)

        # 油门
        if e.state == 'evade' or e.state == 'break':
            e.throttle = 1.0
        else:
            e.throttle = clamp(0.62 + (dist - 500) / 3000.0, 0.5, 1.0)

        ctl = {'pitch': 0.0, 'roll': 0.0, 'yaw': 0.0, 'throttle': 0.0}
        if e.update(dt, ctl, self):
            e.dead = True
            self.spawn_explosion(e.pos, 1.6)
            return

        # 开火
        ang = math.degrees(math.acos(clamp(vdot(vnorm(vsub(p.pos, e.pos)), e.fwd), -1, 1)))
        can_hit = (dist < 1500 and ang < lerp(3.0, 9.0, e.skill) * 1.6 and not p.dead)
        if can_hit:
            e.fire_t -= dt
            if e.fire_t <= 0 and e.gun_cd <= 0:
                e.fire_t = 0.5
                self.fire_gun(e)
            elif e.gun_cd <= 0:
                if random.random() < lerp(0.02, 0.14, e.skill):
                    self.fire_gun(e)
        else:
            e.fire_t = 0.35

        # 敌机发射导弹
        if (e.missiles > 0 and dist < 2600 and dist > 420 and ang < 16
                and random.random() < dt * 0.22 * e.skill):
            self.launch_missile(e, p)
            self.msg('敌机发射导弹！', 1.6)

    # ------------------------------------------------------------------
    def update_camera(self, dt):
        p = self.player
        if self.view_mode == 0:
            want_fwd = p.fwd
            want_up = p.up
            k = 1.0 - math.exp(-9.0 * dt)
            self.cam_fwd = vnorm(vlerp(self.cam_fwd, want_fwd, k))
            self.cam_up = vnorm(vlerp(self.cam_up, want_up, k))
            f, u, r = orthonormalize(self.cam_fwd, self.cam_up)
            self.cam_fwd, self.cam_up = f, u
            dist = 46.0 + clamp(p.speed * 0.055, 0, 16)
            back = vadd(p.pos, vmul(f, -dist))
            pos = vadd(back, vmul(u, 13.0))
            self.cam_pos = vlerp(self.cam_pos, pos, 1.0 - math.exp(-16.0 * dt))
            # 防止相机穿地
            gh = terrain_h(self.cam_pos[0], self.cam_pos[2]) + 4.0
            if self.cam_pos[1] < gh:
                self.cam_pos = (self.cam_pos[0], gh, self.cam_pos[2])
            self.cam.set_basis(self.cam_pos, f, u)
        else:
            self.cam.set_basis(vadd(p.pos, vmul(p.up, 1.6)), p.fwd, p.up)

        if self.shake > 0.15:
            s = self.shake
            self.cam.pos = vadd(self.cam.pos,
                                (random.uniform(-s, s) * 0.35,
                                 random.uniform(-s, s) * 0.35,
                                 random.uniform(-s, s) * 0.35))

    # ------------------------------------------------------------------
    #  渲染
    # ------------------------------------------------------------------
    def _build_scene(self, cam):
        """收集本帧所有绘制项（CPU / GPU 两条后端共用同一份数据）

        GPU 模式下地形由 _terrain_numpy 单独向量化处理，这里必须跳过，
        否则同一片网格会被算两遍（实测占 GPU 路径 CPU 开销的三分之一）。
        """
        p = self.player
        dlist = []
        skip_terrain = self.use_gl and self.gl.ok and HAVE_NUMPY

        # ---------- 地形（带视锥剔除 + 自适应网格半径）----------
        cx = int(math.floor(p.pos[0] / TERRAIN_CELL))
        cz = int(math.floor(p.pos[2] / TERRAIN_CELL))
        R = self.terrain_rings
        cell = TERRAIN_CELL
        tanx = 1.05          # 半视场角（水平）正切，留余量
        tany = 0.60          # 垂直
        rows = []
        for iz in range(cz - R, cz + R + 1):
            row = []
            z0 = iz * cell
            for ix in range(cx - R, cx + R + 1):
                x0 = ix * cell
                row.append(terrain_h(x0, z0))
            rows.append(row)
        for i in range(len(rows) - 1) if not skip_terrain else ():
            z0 = (cz - R + i) * cell
            z1 = z0 + cell
            r0 = rows[i]
            r1 = rows[i + 1]
            for j in range(len(r0) - 1):
                h00 = r0[j]
                h10 = r0[j + 1]
                h01 = r1[j]
                h11 = r1[j + 1]
                x0 = (cx - R + j) * cell
                x1 = x0 + cell
                mx = x0 + cell * 0.5
                mz = z0 + cell * 0.5
                hm = (h00 + h10 + h01 + h11) * 0.25
                # 相机空间粗剔除
                cc = cam.to_cam((mx, hm, mz))
                czc = cc[2]
                lim = cell * 1.8
                if czc < -lim:
                    continue
                if czc > FAR:
                    continue
                if abs(cc[0]) > czc * tanx + lim:
                    continue
                if abs(cc[1]) > czc * tany + lim:
                    continue
                d = math.sqrt(cc[0] * cc[0] + cc[1] * cc[1] + czc * czc)
                if d > FAR:
                    continue
                slope = (max(h00, h10, h01, h11) - min(h00, h10, h01, h11)) / (cell * 1.5)
                chk = 0.05 if ((j + i) & 1) else 0.0
                col = terrain_color(hm, slope, 0.94 + chk)
                col = apply_fog(col, d)
                dlist.append((d, 0, (x0, h00, z0), (x1, h10, z0),
                              (x1, h11, z1), (x0, h01, z1), col))

        # ---------- 机场跑道 ----------
        self.collect_runway(cam, dlist)

        # ---------- 云 ----------
        for c in self.clouds:
            dx = c[0] - cam.pos[0]
            dy = c[1] - cam.pos[1]
            dz = c[2] - cam.pos[2]
            d = math.sqrt(dx * dx + dy * dy + dz * dz)
            if d > FAR:
                continue
            if d < c[3] * 1.25:
                continue                       # 已在云中：不画，避免糊住整个屏幕
            tier = int(clamp(d / FAR, 0.0, 1.0) * (CLOUD_TIERS - 1) + 0.5)
            dlist.append((d, 1, (c[0], c[1], c[2]), c[3], None, tier))

        # ---------- 实体 ----------
        for e in self.enemies:
            e.collect(cam, dlist)
        if not p.dead:
            p.collect(cam, dlist)

        for b in self.bullets:
            d = vlen(vsub(b.pos, cam.pos))
            if d > FAR:
                continue
            dlist.append((d, 4, b.prev, b.pos, 2, (255, 232, 140)))
        for m in self.missiles:
            d = vlen(vsub(m.pos, cam.pos))
            if d > FAR:
                continue
            dlist.append((d, 4, m.prev, m.pos, 3, (255, 200, 120)))
        for pt in self.particles:
            d = vlen(vsub(pt.pos, cam.pos))
            if d > FAR or d < 1.0:
                continue
            t = 1.0 - pt.life / pt.max_life
            r = lerp(pt.r0, pt.r1, t)
            col = pt.col if pt.life > pt.max_life * 0.35 else col_lerp(pt.col, (110, 106, 102), 0.5)
            col = apply_fog(col, d)
            dlist.append((d, 3, pt.pos, r, col))
        for fl in self.flares:
            d = vlen(vsub((fl[0], fl[1], fl[2]), cam.pos))
            dlist.append((d, 3, (fl[0], fl[1], fl[2]), 5.5, (255, 214, 130)))
        return dlist

    # ------------------------------------------------------------------
    #  GPU 后端：3D 场景走 OpenGL
    # ------------------------------------------------------------------
    def _terrain_numpy(self, cam):
        """地形三角形向量化打包（GPU 后端专用）。

        地形是规则网格，非常适合向量化：几百个四边形若走 Python 循环，
        光 list.append 就要上万次（约 2ms），而 numpy 只需十来次数组运算。
        高度计算仍调用 terrain_h（与 CPU 路径完全一致，不会导致地形跳变）。
        """
        if not HAVE_NUMPY:
            return None
        p = self.player
        R = int(self.terrain_rings)
        cell = float(TERRAIN_CELL)
        cx = int(math.floor(p.pos[0] / TERRAIN_CELL))
        cz = int(math.floor(p.pos[2] / TERRAIN_CELL))
        n = 2 * R + 1

        H = np.empty((n, n), dtype=np.float32)
        for i in range(n):
            z0 = (cz - R + i) * cell
            for j in range(n):
                H[i, j] = terrain_h((cx - R + j) * cell, z0)

        h00 = H[:-1, :-1]
        h10 = H[:-1, 1:]
        h01 = H[1:, :-1]
        h11 = H[1:, 1:]
        hm = (h00 + h10 + h01 + h11) * 0.25
        slope = ((np.maximum(np.maximum(h00, h10), np.maximum(h01, h11))
                  - np.minimum(np.minimum(h00, h10), np.minimum(h01, h11)))
                 / (cell * 1.5))

        X = (cx - R + np.arange(n - 1, dtype=np.float32)) * cell
        Z = (cz - R + np.arange(n - 1, dtype=np.float32)) * cell
        MX = (X + cell * 0.5).reshape(1, -1)          # (1, n-1)
        MZ = (Z + cell * 0.5).reshape(-1, 1)          # (n-1, 1)
        mx = np.broadcast_to(MX, (n - 1, n - 1))
        mz = np.broadcast_to(MZ, (n - 1, n - 1))

        # ---- 相机空间 / 视锥剔除（向量化）----
        px, py, pz = cam.pos
        rx, ry, rz = cam.right
        ux, uy, uz = cam.up
        fx, fy, fz = cam.fwd
        dx = mx - px
        dy = hm - py
        dz = mz - pz
        ccx = dx * rx + dy * ry + dz * rz
        ccy = dx * ux + dy * uy + dz * uz
        ccz = dx * fx + dy * fy + dz * fz
        dist = np.sqrt(ccx * ccx + ccy * ccy + ccz * ccz)
        lim = cell * 1.8
        keep = ((ccz >= -lim) & (ccz <= FAR) & (dist <= FAR)
                & (np.abs(ccx) <= ccz * 1.05 + lim)
                & (np.abs(ccy) <= ccz * 0.60 + lim))
        if not keep.any():
            return None

        # ---- 颜色（向量化的 terrain_color + fog）----
        # 棋盘格明暗：与 CPU 路径一致（(i+j) 奇偶），少了它地形会平一截
        ri = np.arange(n - 1, dtype=np.int32).reshape(-1, 1)
        cj = np.arange(n - 1, dtype=np.int32).reshape(1, -1)
        chk = (((ri + cj) & 1) * 0.05).astype(np.float32)
        chk = np.broadcast_to(chk, (n - 1, n - 1))[keep].reshape(-1, 1)
        col = np_terrain_color(hm[keep], slope[keep], 0.94 + chk)
        col = np_apply_fog(col, dist[keep])

        # ---- 组装三角形 ----
        x0 = np.broadcast_to(X.reshape(1, -1), (n - 1, n - 1))[keep]
        z0 = np.broadcast_to(Z.reshape(-1, 1), (n - 1, n - 1))[keep]
        x1 = x0 + cell
        z1 = z0 + cell
        a00 = h00[keep]
        a10 = h10[keep]
        a01 = h01[keep]
        a11 = h11[keep]

        # 两个三角形共 6 个顶点
        vx = np.empty((6, x0.size), dtype=np.float32)
        vy = np.empty((6, x0.size), dtype=np.float32)
        vz = np.empty((6, x0.size), dtype=np.float32)
        vx[0] = x0; vy[0] = a00; vz[0] = z0
        vx[1] = x1; vy[1] = a10; vz[1] = z0
        vx[2] = x1; vy[2] = a11; vz[2] = z1
        vx[3] = x0; vy[3] = a00; vz[3] = z0
        vx[4] = x1; vy[4] = a11; vz[4] = z1
        vx[5] = x0; vy[5] = a01; vz[5] = z1

        m = x0.size
        verts = np.empty((m * 6, 3), dtype=np.float32)
        verts[:, 0] = vx.T.reshape(-1)
        verts[:, 1] = vy.T.reshape(-1)
        verts[:, 2] = vz.T.reshape(-1)
        cols = np.repeat(col, 6, axis=0)
        # 交错 pos3 + col3
        out = np.empty((m * 6, 6), dtype=np.float32)
        out[:, 0:3] = verts
        out[:, 3:6] = cols
        return out

    def _draw_gl(self, cam, dlist):
        gl = self.gl
        gl.begin(cam)

        op = gl.opaque
        bl = gl.blend
        F255 = 1.0 / 255.0
        clouds = []          # 半透明需要按距离排序

        # 地形走向量化通道（一次数组上传），其余仍逐项处理
        if HAVE_NUMPY:
            tarr = self._terrain_numpy(cam)
            if tarr is not None and len(tarr):
                gl.upload_interleaved(tarr)

        for item in dlist:
            kind = item[1]
            if kind == 0:
                if HAVE_NUMPY:
                    continue       # 已由向量化通道提交
            if kind == 0:
                # 地形四边形：直接拆两个三角形，近裁剪交给 GPU
                c = item[6]
                r, g, b = c[0] * F255, c[1] * F255, c[2] * F255
                op.quad(item[2], item[3], item[4], item[5], (r, g, b))
            elif kind == 2:
                # 机体面（CPU 已完成背面剔除与光照/雾色）
                c = item[3]
                r, g, b = c[0] * F255, c[1] * F255, c[2] * F255
                op.poly(item[2], (r, g, b))
            elif kind == 4:
                # 弹道线段：GPU 自动裁剪近平面
                c = item[5]
                r, g, b = c[0] * F255, c[1] * F255, c[2] * F255
                gl.lines.line(item[2], item[3], (r, g, b))
            elif kind == 1:
                clouds.append(item)
            elif kind == 3:
                clouds.append(item)

        gl.flush_opaque()

        # 半透明：远 → 近
        clouds.sort(key=itemgetter(0), reverse=True)
        glEnable(GL_TEXTURE_2D)
        glEnable(GL_BLEND)
        for item in clouds:
            if item[1] == 1:
                tier = item[5]
                tex = gl.cloud_tex(tier)
                if tex is None:
                    continue
                quad = gl._bill(cam, item[2], item[3])
                # 云用纹理绘制（单独一批，带纹理坐标）
                s = 1.0
                glBindTexture(GL_TEXTURE_2D, tex)
                glColor4f(1, 1, 1, 1)
                glBegin(GL_QUADS)
                glTexCoord2f(0, 0); glVertex3f(*quad[0])
                glTexCoord2f(1, 0); glVertex3f(*quad[1])
                glTexCoord2f(1, 1); glVertex3f(*quad[2])
                glTexCoord2f(0, 1); glVertex3f(*quad[3])
                glEnd()
            else:
                c = item[4]
                r, g, b = c[0] * F255, c[1] * F255, c[2] * F255
                quad = gl._bill(cam, item[2], item[3])
                bl.quad(quad[0], quad[1], quad[2], quad[3], (r, g, b))

        if bl.ntri():
            # 粒子用圆形软边贴图：每个 billboard = 2 三角形 = 6 顶点 = 36 float
            glDepthMask(GL_FALSE)
            glBindTexture(GL_TEXTURE_2D, gl._dot_tex)
            glDisable(GL_COLOR_ARRAY)          # 改用 glColor4f 逐粒子着色
            v = bl.v
            TEX = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0),
                   (0.0, 0.0), (1.0, 1.0), (0.0, 1.0))
            glBegin(GL_QUADS)
            for i in range(0, len(v) - 35, 36):
                # 同一 quad 内六顶点同色，取第一个即可
                glColor4f(v[i + 3], v[i + 4], v[i + 5], 1.0)
                for k in range(6):
                    b = i + k * 6
                    glTexCoord2f(TEX[k][0], TEX[k][1])
                    glVertex3f(v[b], v[b + 1], v[b + 2])
            glEnd()
            glEnable(GL_COLOR_ARRAY)
            glDepthMask(GL_TRUE)
        glDisable(GL_TEXTURE_2D)
        bl.clear()

    # ------------------------------------------------------------------
    #  CPU 后端：全部走 pygame 软件光栅化
    # ------------------------------------------------------------------
    def _draw_cpu(self, cam, dlist, surf):
        draw_sky(surf, cam)
        draw_sun(surf, cam)
        dlist.sort(key=itemgetter(0), reverse=True)   # itemgetter 比 lambda 快不少
        for item in dlist:
            kind = item[1]
            if kind == 0:
                draw_quad(cam, surf, item[2], item[3], item[4], item[5], item[6])
            elif kind == 1:
                sp = cam.project(item[2])
                if sp:
                    r = int(item[3] * cam.f / sp[2])
                    if 4 < r < 1600:
                        # 直接用预渲染 + 缓存好的贴图，每朵云只一次 blit
                        tex = cloud_sprite(r, item[5])
                        half = tex.get_width() // 2
                        surf.blit(tex, (int(sp[0]) - half, int(sp[1]) - half))
            elif kind == 2:
                poly = [cam.to_cam(v) for v in item[2]]
                sp = project_poly(cam, poly)
                if sp:
                    pygame.draw.polygon(surf, item[3], sp)
                    if AA_ON:
                        # 抗锯齿：沿轮廓补一圈平滑边，机身边缘的"锯齿"最显眼
                        try:
                            pygame.draw.aalines(surf, item[3], True, sp, 1)
                        except Exception:
                            pass
            elif kind == 3:
                sp = cam.project(item[2])
                if sp:
                    r = int(item[3] * cam.f / sp[2])
                    if 0 < r < 2000:
                        pygame.draw.circle(surf, item[4], (int(sp[0]), int(sp[1])), r)
            elif kind == 4:
                a = cam.to_cam(item[2])
                b = cam.to_cam(item[3])
                if a[2] < NEAR and b[2] < NEAR:
                    continue
                cl = clip_near([a, b])
                if len(cl) < 2:
                    continue
                pa = cam.project_cam(cl[0])
                pb = cam.project_cam(cl[1])
                pygame.draw.line(surf, item[5], pa, pb, item[4])

    # ------------------------------------------------------------------
    def render(self):
        """渲染一帧：先决定用哪个后端，HUD 一律由 CPU 画在 2D 层"""
        cam = self.cam
        gl_on = self.use_gl and self.gl.ok
        dlist = self._build_scene(cam)

        if gl_on:
            # GPU：3D 场景交给 OpenGL，天空用低分辨率纹理
            # 天空缓存没命中（或太阳位置变了）才重新上传纹理，
            # 飞行中绝大多数帧可以省掉这次上传。
            sc = 1.0 / self.gl.sky_div
            repaint = draw_sky(self.gl.sky, cam, sc)
            sun = _sun_screen_pos(cam)
            draw_sun(self.gl.sky, cam, sc)
            if repaint or sun != self._last_sun:
                self._last_sun = sun
                self.gl.upload_sky()
            try:
                self._draw_gl(cam, dlist)
            except Exception:
                # GL 中途出错就永久退回 CPU 后端，别让游戏卡死
                self.gl.ok = False
                self.use_gl = False
                self.settings.renderer = 1
                self.settings.save()
                self._draw_cpu(cam, dlist, self.rbuf)
                surf = self.rbuf
            else:
                surf = self.gl.overlay
                if surf is not None:
                    surf.fill((0, 0, 0, 0))
        else:
            surf = self.rbuf
            self._draw_cpu(cam, dlist, surf)

        self._draw_hud(surf, cam)

        if gl_on and self.gl.ok:
            self.gl.draw_overlay()

    def _draw_hud(self, surf, cam):
        """HUD / 提示 / 触屏控件（CPU 绘制，两个后端共用）"""
        p = self.player
        w, h = cam.w, cam.h

        # ---------- HUD ----------
        if self.view_mode == 1 and not p.dead:
            draw_cockpit(surf, cam)
        if not p.dead:
            hud_pitch_ladder(surf, cam, p)
            hud_fpm(surf, cam, p)
            hud_reticle(surf, cam)
            if self.lock_target is not None and not self.lock_target.dead:
                hud_lock(surf, cam, self.lock_target, self.lock_t, self.locked)
            hud_bars(surf, cam, p, self.touch.active)
            hud_radar(surf, cam, p, self.enemies, self.lock_target, w, h,
                      self.touch.active)
            hud_status(surf, p, self, w, h)
            hud_fps(surf, self)
            hud_mission(surf, self, w, h)
            hud_enemy_state(surf, self, w, h)
            hud_damage_flash(surf, self, w, h)
            if self.hit_mark > 0:
                c = (255, 90, 70)
                x, y = int(cam.cx), int(cam.cy)
                s = 18
                pygame.draw.line(surf, c, (x - s, y - s), (x - s + 8, y - s + 8), 2)
                pygame.draw.line(surf, c, (x + s, y - s), (x + s - 8, y - s + 8), 2)
                pygame.draw.line(surf, c, (x - s, y + s), (x - s + 8, y + s - 8), 2)
                pygame.draw.line(surf, c, (x + s, y + s), (x + s - 8, y + s - 8), 2)
            # 屏幕外敌机指示箭头
            self.draw_offscreen_arrows(surf, cam)

        # 提示消息
        if self.message[1] > 0:
            a = clamp(self.message[1], 0, 1)
            draw_text(surf, self.message[0], (w // 2, h // 2 + 120), 24,
                      HUD_AMBER, center=True, bold=True)

        # 起飞提示
        if not p.airborne and not p.dead:
            if self.touch.active:
                if p.speed < 78:
                    draw_text(surf, '把右侧「油门」滑钮推到顶，速度超过 78 后摇杆向上推起飞',
                              (w // 2, h - 150), 20, HUD_GREEN, center=True)
                else:
                    draw_text(surf, '速度足够！摇杆向上推即可起飞', (w // 2, h - 150), 22,
                              HUD_AMBER, center=True, bold=True)
            else:
                if p.speed < 78:
                    draw_text(surf, '按住 [左Shift] 加满油门滑跑，速度超过 78 m/s 后按 [W] 拉起',
                              (w // 2, h - 150), 20, HUD_GREEN, center=True)
                else:
                    draw_text(surf, '速度足够！按 [W] 拉升起飞', (w // 2, h - 150), 22,
                              HUD_AMBER, center=True, bold=True)

        # 触屏虚拟控件（画在最上层）
        self.touch.draw(surf)

        # 设置面板（最顶层，两个后端都由 CPU 画）
        if self.settings_open:
            self.setpanel.draw(surf, cam.w, cam.h)

    def collect_runway(self, cam, dlist):
        if vlen2(vsub((0, 0, 0), cam.pos)) > 9000 * 9000:
            return
        gh = 0.0
        z0, z1 = -RUNWAY_HALF_L, RUNWAY_HALF_L
        hw = RUNWAY_HALF_W
        segs = 14
        step = (z1 - z0) / segs
        for i in range(segs):
            a = z0 + i * step
            b = a + step
            mx, mz = 0.0, (a + b) * 0.5
            d = vlen(vsub((mx, gh, mz), cam.pos))
            if d > FAR:
                continue
            col = apply_fog((58, 58, 62), d)
            dlist.append((d + 0.5, 0, (-hw, gh + 0.4, a), (hw, gh + 0.4, a),
                          (hw, gh + 0.4, b), (-hw, gh + 0.4, b), col))
            # 中线
            if i % 2 == 0:
                col2 = apply_fog((216, 214, 200), d)
                dlist.append((d, 0, (-2.2, gh + 0.5, a + step * 0.18),
                              (2.2, gh + 0.5, a + step * 0.18),
                              (2.2, gh + 0.5, b - step * 0.18),
                              (-2.2, gh + 0.5, b - step * 0.18), col2))
        # 边线
        for sx in (-hw, hw - 3.0):
            d = vlen(vsub((sx, gh, 0), cam.pos))
            if d > FAR:
                continue
            col = apply_fog((220, 216, 200), d)
            dlist.append((d, 0, (sx, gh + 0.5, z0), (sx + 3.0, gh + 0.5, z0),
                          (sx + 3.0, gh + 0.5, z1), (sx, gh + 0.5, z1), col))

    def draw_offscreen_arrows(self, surf, cam):
        p = self.player
        for e in self.enemies:
            if e.dead:
                continue
            sp = cam.project(e.pos)
            if sp is not None and 0 < sp[0] < cam.w and 0 < sp[1] < cam.h:
                continue
            d = vsub(e.pos, p.pos)
            local = (vdot(d, p.right), vdot(d, p.up), vdot(d, p.fwd))
            if local[2] > 0:
                continue
            ang = math.atan2(local[0], -local[2])
            cx, cy = cam.cx, cam.cy
            R = 200.0
            x = cx + math.sin(ang) * R
            y = cy - math.cos(ang) * R
            x = clamp(x, 40, cam.w - 40)
            y = clamp(y, 40, cam.h - 120)
            a = (0.5 + 0.5 * math.sin(self.time * 6)) * 0.5 + 0.5
            col = (int(255 * a), int(90 * a), int(70 * a))
            pygame.draw.circle(surf, col, (int(x), int(y)), 6, 1)
            draw_text(surf, '%dm' % int(vlen(d)), (int(x) + 10, int(y) - 8),
                      13, col, shadow=False)


def seg_sphere(p0, p1, c, r):
    """线段与球体相交检测"""
    d = vsub(p1, p0)
    f = vsub(p0, c)
    a = vdot(d, d)
    if a < 1e-9:
        return vlen2(f) <= r * r
    t = -vdot(f, d) / a
    t = clamp(t, 0.0, 1.0)
    closest = vadd(p0, vmul(d, t))
    return vlen2(vsub(closest, c)) <= r * r


# ==============================================================================
#  11. 主程序
# ==============================================================================

def draw_menu(screen, game, t):
    w, h = screen.get_size()
    screen.fill((10, 16, 26))
    # 装饰：滚动地平线
    for i in range(0, h // 2, 4):
        c = col_lerp((12, 20, 34), (34, 62, 104), i / float(h / 2))
        pygame.draw.rect(screen, c, (0, i, w, 4))
    pygame.draw.rect(screen, (16, 22, 20), (0, h // 2, w, h // 2))
    for i in range(0, 40):
        x = (i * 137 + int(t * 40) % 137) % (w + 200) - 100
        pygame.draw.line(screen, (30, 60, 46), (x, h // 2), (x - 60, h), 1)

    touch = game.touch.active

    # 手机上竖着排不开，改成「左半：任务简报 | 右半：操作」两栏
    two_col = touch and w >= 900

    if touch:
        title_y = int(h * 0.06)
        fs_title = 34
    else:
        title_y = h // 2 - 220
        fs_title = 56
    draw_text(screen, '空 战 飞 行 模 拟 器', (w // 2, title_y), fs_title,
              (120, 255, 170), center=True, bold=True)
    draw_text(screen, 'AIR  COMBAT  FLIGHT  SIMULATOR', (w // 2, title_y + 40), 15,
              (110, 170, 210), center=True)

    if touch:
        brief = [
            ('任 务 简 报', HUD_AMBER, True),
            ('拦截一波又一波敌机，清空即进入下一波', (205, 228, 215), False),
            ('活得越久、击落越多，得分越高', (205, 228, 215), False),
            ('击落 +120    王牌机 +220    清空一波 +250×波次', (205, 228, 215), False),
            ('', (0, 0, 0), False),
            ('触屏操作', (255, 210, 110), True),
            ('左下摇杆   上推抬头，左右横滚', (200, 230, 210), False),
            ('右侧滑钮   油门        右侧圆钮   开火/导弹/干扰/减速', (200, 230, 210), False),
            ('准星套住敌机约 1 秒锁定后点「导弹」', (200, 230, 210), False),
        ]
        fs, gap = 15, 21
    else:
        brief = [(t, c, t.startswith(('任', '计'))) for t, c in MISSION_BRIEF]
        ops = [
            ('操 作', (255, 210, 110), True),
            ('W / ↑  拉升        S / ↓  俯冲', (200, 230, 210), False),
            ('A / ←  左横滚      D / →  右横滚', (200, 230, 210), False),
            ('Q / E  偏航        Z  减速板', (200, 230, 210), False),
            ('左Shift 加大油门    左Ctrl 减小油门', (200, 230, 210), False),
            ('', (0, 0, 0), False),
            ('空格  机炮（按住扫射）', (200, 230, 210), False),
            ('M  发射导弹（需先锁定）', (200, 230, 210), False),
            ('C  释放热焰干扰弹', (200, 230, 210), False),
            ('', (0, 0, 0), False),
            ('V  切视角    P / ESC  暂停', (200, 230, 210), False),
            ('R  重新开始    F11  全屏', (200, 230, 210), False),
        ]
        fs, gap = 17, 24

    if two_col and touch:
        # 左栏：任务简报
        lx = int(w * 0.27)
        ly = title_y + 74
        for txt, col, bold in brief:
            if txt:
                draw_text(screen, txt, (lx, ly), fs, col, center=True, bold=bold)
            ly += gap
        # 右栏：失败条件 + 敌机行为
        rx = int(w * 0.73)
        ry = title_y + 74
        draw_text(screen, '失 败 条 件', (rx, ry), fs + 2, HUD_RED,
                  center=True, bold=True)
        ry += gap + 4
        for cond, why in FAIL_RULES:
            draw_text(screen, '· %s' % cond, (rx, ry), fs - 1, (225, 200, 195),
                      center=True)
            ry += gap - 3
            draw_text(screen, '  %s' % why, (rx, ry), fs - 2, (165, 185, 180),
                      center=True)
            ry += gap - 2
        ry += 8
        draw_text(screen, '敌 机 行 为', (rx, ry), fs + 2, HUD_AMBER,
                  center=True, bold=True)
        ry += gap + 4
        for st, (desc, col) in ENEMY_STATE_INFO.items():
            note = {'pursue': '正在追赶并准备开火',
                    'break': '距离过近，侧滑拉开',
                    'evade': '被你锁定时急转逃跑'}[st]
            draw_text(screen, '· %s —— %s' % (desc, note), (rx, ry), fs - 1,
                      col, center=True)
            ry += gap - 2
    elif not touch:
        # 桌面：左栏任务简报 / 右栏操作
        y = title_y + 78
        draw_text(screen, brief[0][0], (int(w * 0.28), y), 20, brief[0][1],
                  center=True, bold=True)
        y += 28
        for txt, col, bold in brief[1:]:
            if txt:
                draw_text(screen, txt, (int(w * 0.28), y), 16, col, center=True)
            y += 22
        y = title_y + 78
        for txt, col, bold in ops:
            if txt:
                draw_text(screen, txt, (int(w * 0.72), y), 17, col,
                          center=True, bold=bold)
            y += 24
    else:
        y = title_y + 74
        for txt, col, bold in brief:
            if txt:
                draw_text(screen, txt, (w // 2, y), fs, col, center=True, bold=bold)
            y += gap

    if int(t * 2) % 2 == 0:
        lbl = '点击屏幕任意处开始' if touch else '按  空格 / 回车  起飞'
        draw_text(screen, lbl, (w // 2, h - 62), 26 if touch else 30,
                  (120, 255, 170), center=True, bold=True)
    if touch:
        draw_text(screen, '提示：起步停在跑道上，把右侧「油门」滑钮推到顶，速度到 78 后摇杆向上推即可升空',
                  (w // 2, h - 40), 15, (150, 180, 200), center=True)
    else:
        draw_text(screen, '提示：起步停在跑道上，先加满油门滑跑，速度到 78 m/s 后拉起即可升空',
                  (w // 2, h - 38), 16, (150, 180, 200), center=True)


def draw_pause(screen, game):
    w, h = screen.get_size()
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    s.fill((0, 10, 20, 165))
    screen.blit(s, (0, 0))

    touch = game.touch.active
    top = int(h * 0.10)
    draw_text(screen, '已 暂 停', (w // 2, top), 40 if touch else 48,
              (120, 255, 170), center=True, bold=True)

    # 上半：生存要诀（失败条件的操作版）
    draw_text(screen, SURVIVE_TIPS[0], (w // 2, top + 52), 19, HUD_AMBER,
              center=True, bold=True)
    fs = 14 if touch else 16
    y = top + 78
    for tip in SURVIVE_TIPS[1:]:
        draw_text(screen, '· ' + tip, (w // 2, y), fs, (200, 220, 210), center=True)
        y += 21 if not touch else 19

    # 下半：硬性失败条件
    y += 12
    draw_text(screen, '失 败 条 件（满足任一即坠毁）', (w // 2, y), 17,
              HUD_RED, center=True, bold=True)
    y += 26
    for cond, why in FAIL_RULES:
        draw_text(screen, '%s —— %s' % (cond, why), (w // 2, y), fs,
                  (225, 200, 195), center=True)
        y += 21 if not touch else 19

    if touch:
        draw_text(screen, '点击屏幕继续', (w // 2, h - 34), 19,
                  (200, 230, 210), center=True)
    else:
        draw_text(screen, '按 P 或 ESC 继续    ·    按 R 重新开始', (w // 2, h - 34),
                  20, (200, 230, 210), center=True)


def draw_over(screen, game, t):
    w, h = screen.get_size()
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    s.fill((30, 8, 8, 165))
    screen.blit(s, (0, 0))
    touch = game.touch.active
    top = int(h * 0.06) if touch else h // 2 - 150
    draw_text(screen, '任 务 结 束', (w // 2, top), 38 if touch else 54, (255, 96, 84),
              center=True, bold=True)
    draw_text(screen, game.end_reason, (w // 2, top + 44), 22 if touch else 24,
              (255, 180, 150), center=True)

    # 说清到底触犯了哪一条失败条件，而不是只丢一句"撞地坠毁"
    detail = fail_detail(game)
    if detail:
        draw_text(screen, detail, (w // 2, top + 74), 15 if touch else 17,
                  (235, 175, 160), center=True)

    acc = 0
    if game.shots:
        acc = game.hits * 100.0 / game.shots
    stats = [
        ('最终得分', '%d' % game.score),
        ('击落数', '%d' % game.kills),
        ('到达波次', '第 %d 波' % game.wave),
        ('机炮命中率', '%.1f%%' % acc),
        ('飞行时长', '%d 分 %02d 秒' % (int(game.time // 60), int(game.time % 60))),
    ]
    y = top + (104 if touch else 122)
    fs = 17 if touch else 22
    step = 27 if touch else 34
    for k, v in stats:
        draw_text(screen, k, (w // 2 - 30, y), fs, (190, 210, 200), right=True)
        draw_text(screen, v, (w // 2 + 30, y), fs, (255, 220, 120), bold=True)
        y += step

    # 历史纪录
    s = game.save
    rec = '历史最高 %d 分  ·  最远第 %d 波  ·  累计击落 %d  ·  出击 %d 次' % (
        int(s.get('best_score', 0)), int(s.get('best_wave', 0)),
        int(s.get('total_kills', 0)), int(s.get('runs', 0)))
    draw_text(screen, rec, (w // 2, y + 12), 15, (150, 175, 190), center=True)
    if game.new_record:
        draw_text(screen, '★ 刷新纪录！', (w // 2, y + 38), 22,
                  (255, 215, 90), center=True, bold=True)

    if int(t * 2) % 2 == 0:
        lbl = '点击屏幕重新出击' if game.touch.active else '按 R 重新出击'
        draw_text(screen, lbl, (w // 2, h - 70), 26,
                  (120, 255, 170), center=True, bold=True)


def detect_mobile():
    """判断是否运行在安卓 / 触屏设备上（可用 --touch / --notouch 强制）

    返回 (is_mobile, env_name)
      env_name ∈ 'pydroid' | 'android' | 'termux' | 'pc'
    """
    force = None
    if '--touch' in sys.argv:
        force = True
    if '--notouch' in sys.argv:
        force = False

    env = os.environ
    # Pydroid 3：内置 SDL2，set_mode 直接出画面，无需 X server
    pydroid_hint = False
    for key, val in env.items():
        if 'pydroid' in str(val).lower() or 'pydroid' in key.lower():
            pydroid_hint = True
            break
    if not pydroid_hint:
        for p in ('/data/data/ru.iiec.pydroid3',
                  '/data/data/ru.iiec.pydroid3/files'):
            if os.path.isdir(p):
                pydroid_hint = True
                break
    if not pydroid_hint:
        try:
            if 'ru.iiec.pydroid3' in os.readlink('/proc/self/cwd'):
                pydroid_hint = True
        except Exception:
            pass

    # 其它安卓环境（p4a / Termux）
    android_env = False
    for k in ('ANDROID_ARGUMENT', 'ANDROID_PRIVATE', 'ANDROID_BOOTLOGO',
              'P4A_BOOTSTRAP', 'ANDROID_DATA', 'ANDROID_ROOT'):
        if env.get(k):
            android_env = True
            break

    if pydroid_hint:
        name = 'pydroid'
    elif android_env:
        name = 'termux' if env.get('TERMUX_VERSION') or \
            os.path.isdir('/data/data/com.termux') else 'android'
    else:
        name = 'pc'

    is_mobile = pydroid_hint or android_env or bool(env.get('TERMUX_VERSION'))
    if os.path.isdir('/data/data/com.termux'):
        is_mobile = True
    if force is not None:
        is_mobile = force
    return is_mobile, name


# 安卓应用生命周期事件（老版本 pygame 没有这些常量）
APP_WILLENTERBACKGROUND = getattr(pygame, 'APP_WILLENTERBACKGROUND', 259)
APP_DIDENTERFOREGROUND = getattr(pygame, 'APP_DIDENTERFOREGROUND', 260)


# ==============================================================================
#  9. OpenGL 渲染后端（可选；装了 PyOpenGL 且能建 context 才生效）
#
#  分工：GPU 画 3D（地形/机体/云/粒子/弹道），CPU 画 2D（HUD/文字/菜单/控件）。
#  二者各干各擅长的：GPU 擅长并行光栅化成千上万个三角形，
#  而中文文字和矢量 HUD 走 GPU 反而更慢，交给 CPU 画完当纹理贴上去。
# ==============================================================================

try:
    from OpenGL.GL import *
    from OpenGL.GLU import *
    HAVE_PYOPENGL = True
except Exception:
    HAVE_PYOPENGL = False


class _Batch(object):
    """三角形收集器：交错 pos3 + col3，攒够了一次性丢给 GPU。

    GPU 每帧只接收一整个大数组，而不是几千次 glVertex 调用——
    后者在 Python 里光函数调用开销就足以吃掉全部收益。
    """
    __slots__ = ('v',)

    def __init__(self):
        self.v = []

    def clear(self):
        del self.v[:]

    def tri(self, a, b, c, col):
        v = self.v
        r, g, bl = col
        v.append(a[0]); v.append(a[1]); v.append(a[2])
        v.append(r); v.append(g); v.append(bl)
        v.append(b[0]); v.append(b[1]); v.append(b[2])
        v.append(r); v.append(g); v.append(bl)
        v.append(c[0]); v.append(c[1]); v.append(c[2])
        v.append(r); v.append(g); v.append(bl)

    def quad(self, a, b, c, d, col):
        self.tri(a, b, c, col)
        self.tri(a, c, d, col)

    def poly(self, pts, col):
        """扇形三角化（凸多边形）"""
        p0 = pts[0]
        for i in range(1, len(pts) - 1):
            self.tri(p0, pts[i], pts[i + 1], col)

    def ntri(self):
        return len(self.v) // 18


class _LineBatch(object):
    """线段收集器：pos3 + col3，每线两个端点"""
    __slots__ = ('v',)

    def __init__(self):
        self.v = []

    def clear(self):
        del self.v[:]

    def line(self, a, b, col):
        v = self.v
        r, g, bl = col
        v.append(a[0]); v.append(a[1]); v.append(a[2])
        v.append(r); v.append(g); v.append(bl)
        v.append(b[0]); v.append(b[1]); v.append(b[2])
        v.append(r); v.append(g); v.append(bl)

    def nvert(self):
        return len(self.v) // 6


class GLRenderer(object):
    """把 3D 场景交给 GPU，2D 叠加层仍由 CPU 绘制。

    设计要点：
      * 不透明几何（地形/机体/弹道）依赖深度缓冲，因此**完全不做 CPU 排序**
        —— 这一项在 CPU 后端里是要花时间的。
      * 半透明（云/粒子/爆炸）仍需从远到近排序，且关闭深度写入。
      * 近平面裁剪交给 GPU，省掉 CPU 端的 clip_near。
      * 雾色 CPU 已经算进顶点色了，GL 里无需再算。
    """

    STRIDE = 24          # 6 float × 4 字节

    def __init__(self):
        self.ok = False
        self.w = 0                 # 叠加层尺寸（受画质档位控制，决定上传量）
        self.h = 0
        self.vw = 0                # 视口尺寸 = 物理窗口（3D 按全分辨率画）
        self.vh = 0
        self.overlay = None        # CPU 画 2D 的透明画布
        self.sky = None            # 低分辨率天空画布
        self.sky_div = 3
        self.opaque = _Batch()
        self.blend = _Batch()
        self.lines = _LineBatch()
        self._vbo = None
        self._lbo = None
        self._sky_tex = None
        self._hud_tex = None
        self._dot_tex = None
        self._cloud_tex = {}
        self.renderer_name = ''
        self.tris = 0              # 上一帧三角形数（HUD 显示用）

    # ---------- 初始化 ----------
    def setup(self, w, h, vw=None, vh=None):
        """创建 GL 资源。任何一步失败都返回 False（调用方回退 CPU 后端）

        w,h = 叠加层尺寸（HUD 画布，决定每帧纹理上传量）
        vw,vh = 视口尺寸（默认同 w,h），3D 场景按它全分辨率渲染
        """
        self.vw, self.vh = (w, h) if vw is None else (vw, vh)
        try:
            glEnable(GL_DEPTH_TEST)
            glDepthFunc(GL_LEQUAL)
            glDisable(GL_CULL_FACE)      # CPU 侧已做背面剔除，绕序不保证
            glShadeModel(GL_SMOOTH)
            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
            glEnableClientState(GL_VERTEX_ARRAY)
            glEnableClientState(GL_COLOR_ARRAY)
            self._vbo = glGenBuffers(1)
            self._lbo = glGenBuffers(1)
            self._sky_tex = glGenTextures(1)
            self._hud_tex = glGenTextures(1)
            self._dot_tex = self._make_dot_texture()
            self.resize(w, h)
            glClearColor(0.0, 0.0, 0.0, 1.0)
            self.renderer_name = self._query_renderer()
            self.ok = True
            return True
        except Exception:
            self.ok = False
            return False

    def _query_renderer(self):
        try:
            v = glGetString(GL_RENDERER)
            return v.decode('utf-8', 'ignore') if isinstance(v, bytes) else str(v)
        except Exception:
            return ''

    def _make_dot_texture(self, n=64):
        """粒子用的圆形软边贴图（程序生成，无外部资源）"""
        tex = glGenTextures(1)
        s = pygame.Surface((n, n), pygame.SRCALPHA)
        c = n / 2.0
        for i in range(n):
            for j in range(n):
                d = math.hypot(i - c + 0.5, j - c + 0.5) / c
                a = 255 if d < 0.55 else int(255 * max(0.0, 1.0 - (d - 0.55) / 0.45))
                s.set_at((i, j), (255, 255, 255, a))
        self._upload_rgba(tex, s)
        return tex

    @staticmethod
    def _upload_rgba(tex, surf):
        w, h = surf.get_size()
        data = pygame.image.tostring(surf, 'RGBA', True)
        glBindTexture(GL_TEXTURE_2D, tex)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                     GL_UNSIGNED_BYTE, data)

    @staticmethod
    def _upload_rgb(tex, surf):
        w, h = surf.get_size()
        data = pygame.image.tostring(surf, 'RGB', True)
        glBindTexture(GL_TEXTURE_2D, tex)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB,
                     GL_UNSIGNED_BYTE, data)

    def resize(self, w, h):
        try:
            self.w, self.h = w, h
            if not self.vw:
                self.vw, self.vh = w, h
            self.overlay = pygame.Surface((w, h), pygame.SRCALPHA)
            sw, sh = max(8, w // self.sky_div), max(8, h // self.sky_div)
            self.sky = pygame.Surface((sw, sh))
            glBindTexture(GL_TEXTURE_2D, self._hud_tex)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                         GL_UNSIGNED_BYTE, None)
            self._upload_rgb(self._sky_tex, self.sky)
            for t in list(self._cloud_tex):
                glDeleteTextures([self._cloud_tex.pop(t)])
            return True
        except Exception:
            self.ok = False
            return False

    # ---------- 每帧 ----------
    def begin(self, cam):
        """清屏 + 贴天空 + 切到 3D 透视矩阵"""
        glViewport(0, 0, self.vw, self.vh)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        self.opaque.clear()
        self.blend.clear()
        self.lines.clear()

        # --- 天空：正交全屏贴图，关深度 ---
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(0, self.vw, self.vh, 0, -1.0, 1.0)   # y 向下，与 pygame 一致
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        glDisable(GL_DEPTH_TEST)
        glEnable(GL_TEXTURE_2D)
        self._fullquad(self._sky_tex)
        glDisable(GL_TEXTURE_2D)
        glEnable(GL_DEPTH_TEST)

        # --- 3D 透视 ---
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        hw = (cam.w * 0.5) / cam.f
        hh = (cam.h * 0.5) / cam.f
        glFrustum(-hw * NEAR, hw * NEAR, -hh * NEAR, hh * NEAR, NEAR, FAR)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        # 视图矩阵：世界 → 眼空间。GL 看向 -Z，故第三行取 -fwd。
        r, u, f = cam.right, cam.up, cam.fwd
        p = cam.pos
        m = (r[0], u[0], -f[0], 0.0,
             r[1], u[1], -f[1], 0.0,
             r[2], u[2], -f[2], 0.0,
             -vdot(r, p), -vdot(u, p), vdot(f, p), 1.0)
        # 直接用 ctypes：GLfloat 未必被 from ... import * 带进来，
        # 依赖它会在部分 PyOpenGL 版本上直接 NameError。
        glLoadMatrixf((ctypes.c_float * 16)(*m))

    def _fullquad(self, tex):
        w, h = float(self.vw), float(self.vh)
        glBindTexture(GL_TEXTURE_2D, tex)
        glColor4f(1, 1, 1, 1)
        glBegin(GL_QUADS)
        glTexCoord2f(0.0, 0.0); glVertex2f(0.0, 0.0)
        glTexCoord2f(1.0, 0.0); glVertex2f(w, 0.0)
        glTexCoord2f(1.0, 1.0); glVertex2f(w, h)
        glTexCoord2f(0.0, 1.0); glVertex2f(0.0, h)
        glEnd()

    def upload_sky(self):
        """把 CPU 画好的低分辨率天空传上 GPU"""
        try:
            self._upload_rgb(self._sky_tex, self.sky)
        except Exception:
            pass

    def cloud_tex(self, tier):
        """按 tier 缓存云贴图（不做半径缩放，缩放交给 quad 顶点）"""
        t = self._cloud_tex.get(tier)
        if t is None:
            try:
                t = glGenTextures(1)
                self._upload_rgba(t, _cloud_base(tier))
                self._cloud_tex[tier] = t
            except Exception:
                return None
        return t

    @staticmethod
    def _bill(cam, pos, r):
        """世界坐标处一个面向相机的方形，返回 4 个世界坐标角点"""
        rx, ry, rz = cam.right
        ux, uy, uz = cam.up
        return [(pos[0] - rx * r - ux * r, pos[1] - ry * r - uy * r, pos[2] - rz * r - uz * r),
                (pos[0] + rx * r - ux * r, pos[1] + ry * r - uy * r, pos[2] + rz * r - uz * r),
                (pos[0] + rx * r + ux * r, pos[1] + ry * r + uy * r, pos[2] + rz * r + uz * r),
                (pos[0] - rx * r + ux * r, pos[1] - ry * r + uy * r, pos[2] - rz * r + uz * r)]

    def draw_cloud(self, cam, pos, r, tier):
        quad = self._bill(cam, pos, r)
        self.blend.quad(quad[0], quad[1], quad[2], quad[3], (1.0, 1.0, 1.0))
        return quad

    def upload_interleaved(self, arr):
        """直接上传一个 (N,6) 的交错数组（pos3 + col3），用于向量化地形"""
        if arr is None or not len(arr):
            return
        self._draw_array(self._vbo, arr.ravel(), GL_TRIANGLES, len(arr))
        self.tris += len(arr) // 3

    def flush_opaque(self):
        """提交不透明三角形 + 线段（深度写入开启）"""
        n = self.opaque.ntri()
        if n:
            self._draw_array(self._vbo, self.opaque.v, GL_TRIANGLES, n * 3)
        ln = self.lines.nvert()
        if ln:
            self._draw_array(self._lbo, self.lines.v, GL_LINES, ln)
        self.tris = n

    def flush_blend(self):
        """提交半透明几何（深度测试开、深度写入关）"""
        if self.blend.ntri():
            glDepthMask(GL_FALSE)
            self._draw_array(self._vbo, self.blend.v, GL_TRIANGLES,
                             self.blend.ntri() * 3)
            glDepthMask(GL_TRUE)

    @staticmethod
    def _draw_array(buf, data, mode, count):
        # numpy 数组走 frombuffer 零拷贝；列表才需要逐个装箱
        if HAVE_NUMPY and isinstance(data, np.ndarray):
            a = np.ascontiguousarray(data, dtype=np.float32)
            arr = np.ctypeslib.as_ctypes(a)
            nbytes = a.nbytes
        else:
            arr = (ctypes.c_float * len(data))(*data)
            nbytes = ctypes.sizeof(arr)
        glBindBuffer(GL_ARRAY_BUFFER, buf)
        glBufferData(GL_ARRAY_BUFFER, nbytes, arr, GL_DYNAMIC_DRAW)
        glVertexPointer(3, GL_FLOAT, 24, ctypes.c_void_p(0))
        glColorPointer(3, GL_FLOAT, 24, ctypes.c_void_p(12))
        glDrawArrays(mode, 0, count)

    def draw_overlay(self):
        """把 CPU 画好的 2D 叠加层贴到最上层"""
        if self.overlay is None:
            return
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(0, self.vw, self.vh, 0, -1.0, 1.0)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        glDisable(GL_DEPTH_TEST)
        glEnable(GL_TEXTURE_2D)
        glEnable(GL_BLEND)
        try:
            w, h = self.overlay.get_size()
            data = pygame.image.tostring(self.overlay, 'RGBA', True)
            glBindTexture(GL_TEXTURE_2D, self._hud_tex)
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, GL_RGBA,
                            GL_UNSIGNED_BYTE, data)
            self._fullquad(self._hud_tex)
        except Exception:
            pass
        glDisable(GL_TEXTURE_2D)
        glEnable(GL_DEPTH_TEST)


def error_hint(tb):
    """根据报错内容给出人话建议，别让用户对着 traceback 发呆"""
    low = (tb or '').lower()
    if 'no available video device' in low or 'videodriver' in low:
        return ['没有可用的显示设备',
                'Termux 用户请先启动 X11 / VNC，或直接改用 Pydroid 3 运行']
    if 'couldn\'t open' in low or 'no such file' in low or 'not found' in low:
        return ['找不到需要的文件',
                '确认 flight_sim.py 所在目录可写，或删除同目录 flightsim_save.json 后重试']
    if 'out of memory' in low or 'memoryerror' in low:
        return ['内存不足：把画质降到「标清」、关闭抗锯齿后重试']
    if 'numpy' in low:
        return ['缺少 numpy（只影响音效，游戏本身可正常玩）',
                '如需音效请执行： pip install numpy']
    if 'font' in low:
        return ['字体加载异常：删除同目录 flightsim_save.json 后重启']
    if 'display surface' in low or 'set_mode' in low:
        return ['窗口创建失败：分辨率可能不被支持']
    return ['可尝试：把画质降到「标清」、关闭抗锯齿后重试']


def crash_dialog(screen, title, tb, count=1):
    """红色报错弹窗。

    左半屏/退出按钮 = 结束程序，右半屏/继续按钮 = 忽略并回到菜单继续跑。
    """
    try:
        lines = [l.rstrip() for l in (tb or '').splitlines() if l.strip()]
    except Exception:
        lines = []
    if not lines:
        lines = ['（没有可用的错误详情）']
    summary = lines[-1][:90]
    frames = [l.strip() for l in lines if l.strip().startswith('File ')][-3:]
    hint = error_hint(tb)

    clock = pygame.time.Clock()
    sw, sh = screen.get_size()
    small = min(sw, sh) < 480
    fs = 15 if small else 18
    bh = 46 if small else 54
    bw = int(min(sw * 0.40, 300))

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_ESCAPE, pygame.K_q):
                    return False
                if ev.key in (pygame.K_RETURN, pygame.K_SPACE,
                              pygame.K_r, pygame.K_c):
                    return True
            if ev.type == pygame.FINGERDOWN:
                return (ev.x * sw) >= sw * 0.5
            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                return ev.pos[0] >= sw * 0.5

        screen.fill((26, 6, 8))
        pygame.draw.rect(screen, (190, 35, 35), (0, 0, sw, sh), 6)

        y = 22 if small else 30
        draw_text(screen, '!  程 序 出 错  !', (sw // 2, y),
                  20 if small else 27, (255, 110, 100), center=True, bold=True)
        y += 40 if small else 48
        draw_text(screen, title, (sw // 2, y), fs + 1, (255, 190, 170),
                  center=True)
        y += 30 if small else 34

        # 关键错误信息
        draw_text(screen, summary, (sw // 2, y), fs, (255, 225, 190), center=True)
        y += 22 if small else 26

        # 出错位置
        for ln in frames:
            short = ln.split(',')[0]
            if len(short) > 88:
                short = '...' + short[-85:]
            draw_text(screen, short, (sw // 2, y), max(11, fs - 4),
                      (185, 155, 155), center=True)
            y += 17 if small else 20

        y += 8
        for hl in hint:
            draw_text(screen, hl, (sw // 2, y), fs, (255, 235, 150), center=True)
            y += 21 if small else 24

        draw_text(screen, '第 %d 次出错（连续 6 次将自动退出）' % count,
                  (sw // 2, y + 6), max(11, fs - 3), (165, 145, 145), center=True)

        by = sh - bh - 24
        lx = sw // 2 - bw - 12
        rx = sw // 2 + 12
        pygame.draw.rect(screen, (120, 38, 38), (lx, by, bw, bh))
        pygame.draw.rect(screen, (255, 120, 110), (lx, by, bw, bh), 2)
        draw_text(screen, '退出程序', (lx + bw // 2, by + bh // 2 - 10),
                  fs + 3, (255, 215, 205), center=True, bold=True)
        pygame.draw.rect(screen, (38, 100, 70), (rx, by, bw, bh))
        pygame.draw.rect(screen, (120, 255, 170), (rx, by, bw, bh), 2)
        draw_text(screen, '继续运行', (rx + bw // 2, by + bh // 2 - 10),
                  fs + 3, (200, 255, 220), center=True, bold=True)

        pygame.display.flip()
        clock.tick(30)


def main():
    global FAR

    pygame.init()
    try:
        pygame.font.init()
    except Exception:
        pass
    # 尽量阻止安卓在游玩时息屏
    for hint in ('SDL_ANDROID_BLOCK_ON_PAUSE', 'SDL_ANDROID_TRAP_BACK_BUTTON',
                 'SDL_HINT_ANDROID_BLOCK_ON_PAUSE', 'SDL_HINT_ANDROID_TRAP_BACK_BUTTON'):
        try:
            os.environ[hint] = '1'
        except Exception:
            pass

    mobile, env_name = detect_mobile()

    # ---------- 解析 --res 宽x高 ----------
    # 在 X11 下，每帧 display.flip() 要把整块窗口像素经 socket 交给 X server，
    # 数据量 = 宽 × 高 × 4 字节。2340x1080 约 9.6 MB/帧，60fps 就是 576 MB/s，
    # 这在手机上往往是比游戏本身更大的瓶颈。把窗口分辨率调低（配合
    # Termux:X11 的 scaled 拉伸模式）能线性降低这份开销。
    REQ_RES = None
    for a in sys.argv:
        if a.startswith('--res='):
            try:
                w_, h_ = a[6:].lower().split('x')
                REQ_RES = (int(w_), int(h_))
            except Exception:
                REQ_RES = None

    # ---------- 建立窗口（尽量真全屏，不留边框 / 不留黑边）----------
    def make_flags(want_gl):
        """全屏标志组合；want_gl 时额外加 OPENGL|DOUBLEBUF

        注意 SCALED 与 OPENGL 不能同时用（SCALED 走 SDL_Renderer 纹理路径，
        和 GL 上下文冲突），所以 GL 模式下要把 SCALED 拿掉。
        """
        if want_gl:
            return (pygame.OPENGL | pygame.DOUBLEBUF | pygame.FULLSCREEN
                    | pygame.NOFRAME,
                    pygame.OPENGL | pygame.DOUBLEBUF | pygame.FULLSCREEN,
                    pygame.OPENGL | pygame.DOUBLEBUF)
        return (pygame.FULLSCREEN | pygame.SCALED | pygame.NOFRAME,
                pygame.FULLSCREEN | pygame.SCALED,
                pygame.FULLSCREEN | pygame.NOFRAME,
                pygame.FULLSCREEN,
                pygame.NOFRAME,
                0)

    def want_gpu():
        r = Settings.RENDER_AUTO
        try:
            r = load_save().get('set_renderer', 0)
        except Exception:
            pass
        if '--cpu' in sys.argv:
            return False
        if '--gl' in sys.argv:
            return True
        return HAVE_PYOPENGL and int(r) != Settings.RENDER_CPU

    def try_make_screen(want_gl, sizes):
        for size in sizes:
            for flags in make_flags(want_gl):
                try:
                    if want_gl:
                        try:
                            pygame.display.gl_set_attribute(
                                pygame.GL_DEPTH_SIZE, 24)
                            pygame.display.gl_set_attribute(
                                pygame.GL_DOUBLEBUFFER, 1)
                        except Exception:
                            pass
                    return pygame.display.set_mode(size, flags)
                except Exception:
                    pass
        return None

    screen = None
    gl_mode = False
    if env_name == 'pydroid':
        sizes = [(SCREEN_W, SCREEN_H)]
    elif mobile:
        # Termux + X11 / VNC：默认 (0,0) 吃下整个 X 屏幕分辨率；
        # 若用户用 --res 指定了尺寸，就用它（省 X11 传输带宽）
        sizes = [REQ_RES] if REQ_RES else []
        sizes.append((0, 0))
    else:
        sizes = [REQ_RES or (SCREEN_W, SCREEN_H)]

    if want_gpu():
        screen = try_make_screen(True, sizes)
        gl_mode = screen is not None
    if screen is None:
        screen = try_make_screen(False, sizes)
        gl_mode = False
    if screen is None:
        try:
            screen = pygame.display.set_mode(REQ_RES or (SCREEN_W, SCREEN_H))
        except Exception:
            screen = pygame.display.set_mode((640, 480))
        gl_mode = False

    pygame.display.set_caption('空战飞行模拟器  Air Combat Flight Simulator')
    try:
        icon = pygame.Surface((32, 32))
        pygame.draw.polygon(icon, (40, 60, 90), [(16, 2), (30, 26), (16, 20), (2, 26)])
        pygame.display.set_icon(icon)
    except Exception:
        pass

    SW, SH = screen.get_size()
    # X11 下 SDL 有时只给一个默认小窗口（如 800x600），
    # 这里用 display.Info() 拿到 X 屏幕的真实分辨率再重建一次，确保铺满。
    # 但用户显式指定了 --res 时不要覆盖，那正是为了省 X11 传输带宽。
    try:
        if REQ_RES:
            raise Exception('user specified --res, skip auto-upscale')
        info = pygame.display.Info()
        iw, ih = int(info.current_w), int(info.current_h)
        if iw > 0 and ih > 0 and (iw > SW + 8 or ih > SH + 8):
            for flags in FULLSCREEN_FLAGS:
                try:
                    screen = pygame.display.set_mode((iw, ih), flags)
                    break
                except Exception:
                    pass
            SW, SH = screen.get_size()
    except Exception:
        pass

    clock = pygame.time.Clock()
    sfx = Sfx()
    game = Game(screen, sfx)

    # ---------- 决定是否启用 GPU 后端 ----------
    def boot_gl():
        if not gl_mode:
            return False
        if not HAVE_PYOPENGL:
            return False
        try:
            if game.gl.setup(*screen.get_size(), *screen.get_size()):
                game.use_gl = True
                return True
        except Exception:
            pass
        return False

    gl_ready = boot_gl()
    force_cpu = ('--cpu' in sys.argv or
                 int(getattr(game.settings, 'renderer', 0)) == Settings.RENDER_CPU)
    if force_cpu:
        gl_ready = False
        game.use_gl = False
    if gl_ready:
        print('[渲染] GPU 后端已启用  GL_RENDERER = %s'
              % (game.gl.renderer_name or '未知'))
        print('       分工：GPU 画 3D 场景，CPU 画 HUD / 文字 / 界面')
    else:
        game.use_gl = False
        if HAVE_PYOPENGL:
            print('[渲染] CPU 软件渲染（未启用 GPU）')
        else:
            print('[渲染] CPU 软件渲染（未安装 PyOpenGL，GPU 后端不可用）')

    # ---------- 中文字体探测（只在启动时做一次）----------
    try:
        find_cjk_font(verbose=True)
    except Exception:
        pass

    # ---------- 移动端：降渲染分辨率 + 降地形精度 ----------
    if mobile:
        globals()['FAR'] = 9000.0
        globals()['SKY_STRIPS'] = 9
        globals()['CLOUD_COUNT'] = 18
        globals()['PARTICLE_MAX'] = 130
        game.terrain_rings = 12
        game.touch.enable()
        game.clouds = [game._new_cloud(near=True) for _ in range(CLOUD_COUNT)]

    fullscreen = mobile
    running = True
    frame_ms = 16.0
    frame_no = 0
    last_frame = 0.0

    def apply_size(sw, sh):
        """按物理窗口重算内部渲染分辨率。

        关键：缓冲的**宽高比严格跟随窗口**，这样铺满时永远不会出现黑边。
        （旧版固定用 960×443 的 2.17:1，遇到 16:9 的 X11 窗口就会左右留黑边，
          更糟的是触摸坐标按整屏归一化，和画面错位，右侧按钮就点不动了。）
        """
        q = game.settings.quality_scale() * game.qmul
        if mobile:
            long_side = float(max(sw, sh))
            sc = min(1.0, RENDER_LONG_MOBILE * q / long_side)
        else:
            sc = clamp(q, 0.55, 1.0)
        if sh > sw:
            # 窗口还是竖的：缓冲仍按横屏留着，等系统旋转过来就自然铺满
            rw, rh = int(max(sw, sh) * sc), int(min(sw, sh) * sc)
        else:
            rw, rh = int(sw * sc), int(sh * sc)
        game.set_render_size(max(320, rw), max(240, rh))
        # 画质档位同时决定地形三角形数量的上下限
        rings = game.settings.quality_rings()
        game.terrain_rings_max = rings
        game.terrain_rings_min = max(5, rings - 4)
        game.terrain_rings = clamp(game.terrain_rings,
                                   game.terrain_rings_min,
                                   game.terrain_rings_max)

    apply_size(SW, SH)

    def auto_quality():
        """按「用户设定的目标帧率」自动升降渲染分辨率。

        定 60 却跑不到 → 逐步降画质把帧率稳上去；
        跑得比目标高、还有余量 → 再一点点升回来（尽量往上走）。
        """
        if not mobile and game.settings.quality_scale() >= 1.4:
            return                      # 桌面 + 超清：不自动降级，由用户说了算
        f = game.fps
        target = float(game.settings.fps_target())
        old = game.qmul
        if f < target * 0.88 and game.qmul > QUAL_MIN:
            game.qmul = max(QUAL_MIN, game.qmul - 0.12)
        elif f > target * 0.99 and game.qmul < QUAL_MAX:
            game.qmul = min(QUAL_MAX, game.qmul + 0.08)
        if abs(game.qmul - old) > 1e-6:
            apply_size(*screen.get_size())
            game.fps_min = game.fps
            print('[qual] FPS %.0f / 目标 %d → 缩放 %.2f (%dx%d)'
                  % (f, game.settings.fps_target(), game.qmul, game.rw, game.rh))

    def settings_changed(renderer_changed=False):
        """设置被改动后：立即应用画质/抗锯齿，并重置自适应倍率"""
        globals()['AA_ON'] = bool(game.settings.aa)
        game.qmul = 1.0
        if renderer_changed:
            rebuild_window()
        else:
            apply_size(*screen.get_size())
        game.fps_min = game.fps

    def rebuild_window():
        """切换渲染器必须重建窗口。

        OPENGL 标志只能在 set_mode() 时指定，而 GL context 也无法在运行中
        增删——所以只能整个 display 模块重来一次。失败则退回原模式。
        """
        nonlocal screen, SW, SH, gl_mode
        cur = screen.get_size()
        want_gl = (game.settings.renderer == Settings.RENDER_GPU or
                   (game.settings.renderer == Settings.RENDER_AUTO
                    and HAVE_PYOPENGL))
        try:
            pygame.display.quit()
            pygame.display.init()
        except Exception:
            pass
        game.use_gl = False
        game.gl.ok = False
        gl_mode = False
        new = None
        if want_gl:
            try:
                new = try_make_screen(True, [cur])
            except Exception:
                new = None
            if new is not None:
                gl_mode = True
        if new is None:
            try:
                new = try_make_screen(False, [cur])
            except Exception:
                new = None
        if new is None:
            try:
                new = pygame.display.set_mode(cur)
            except Exception:
                new = pygame.display.set_mode((640, 480))
        screen = new
        game.screen = screen
        SW, SH = screen.get_size()
        apply_size(SW, SH)
        if gl_mode and HAVE_PYOPENGL:
            try:
                if game.gl.setup(SW, SH):
                    game.use_gl = True
                else:
                    game.use_gl = False
                    gl_mode = False
            except Exception:
                game.use_gl = False
                gl_mode = False
        print('[渲染] 切换为 %s'
              % ('GPU (OpenGL)' if game.use_gl else 'CPU 软件渲染'))

    def set_btn_rect():
        """右上角设置齿轮的位置（触屏与桌面各一套）"""
        w, h = game.rw, game.rh
        if game.touch.active:
            return (int(w * 0.955), int(h * 0.078), int(min(w, h) * 0.042))
        return (int(w * 0.955), int(h * 0.055), 22)

    def open_settings():
        if game.settings_open:
            return
        game.settings_open = True
        # 调设置时把游戏冻住，别让人在面板后面被击落
        game._pre_set_state = game.state
        if game.state == STATE_PLAY:
            game.state = STATE_PAUSE
        game.touch.clear()
        # 先布局一次，让热区立即生效（否则首帧点击会落空）
        try:
            game.setpanel.draw(game.rbuf, game.rw, game.rh)
        except Exception:
            pass

    def close_settings():
        game.settings_open = False
        pre = getattr(game, '_pre_set_state', STATE_PLAY)
        if game.state == STATE_PAUSE and pre == STATE_PLAY:
            game.state = STATE_PLAY
        game.touch.clear()

    def on_point_down(rx, ry, fid=0):
        """统一的按下处理：设置面板 > 设置齿轮 > 界面/触屏"""
        if game.settings_open:
            hit = game.setpanel.hit(rx, ry)
            rc = game.setpanel.rc
            if hit is None and rc is not None:
                # 点面板外面 → 关闭（点面板内空白则不动，防误关）
                pxx, pyy, pww, phh = rc
                if not (pxx <= rx <= pxx + pww and pyy <= ry <= pyy + phh):
                    close_settings()
                    return
            if hit is not None:
                key, step = hit
                if key == 'close':
                    close_settings()
                else:
                    game.settings.cycle(key, step)
                    settings_changed(key == 'renderer')
                    game.msg('%s' % (
                        game.settings.quality_name() if key == 'quality'
                        else ('%d FPS' % game.settings.fps_target()
                              if key == 'fps'
                              else ('抗锯齿 开' if game.settings.aa
                                    else '抗锯齿 关'))), 1.2)
            return
        sbx, sby, sbr = set_btn_rect()
        if (rx - sbx) ** 2 + (ry - sby) ** 2 < (sbr * 1.6) ** 2:
            open_settings()
            return
        if game.state in (STATE_MENU, STATE_OVER, STATE_PAUSE):
            if game.state == STATE_OVER:
                game.reset()
            game.state = STATE_PLAY
            if mobile:
                game.touch.enable()      # 桌面用鼠标点一下别把虚拟摇杆喊出来
            game.touch.clear()
        elif game.touch.active:
            game.touch.down(rx, ry, fid)
            # 桌面模式未启用触屏：忽略，避免控件凭空出现

    # ---------- 应用上次保存的画质 / 帧率 / 抗锯齿 ----------
    globals()['AA_ON'] = bool(game.settings.aa)
    apply_size(SW, SH)
    print('[设置] 画质=%s  目标帧率=%d  抗锯齿=%s  渲染=%dx%d  地形环数=%d'
          % (game.settings.quality_name(), game.settings.fps_target(),
             '开' if game.settings.aa else '关', game.rw, game.rh,
             game.terrain_rings))
    # X11 下每帧要经 socket 把整块窗口像素交给 X server，这是手机上的隐形大头
    if mobile:
        _mb = SW * SH * 4 / 1048576.0
        print('[显示] 窗口 %dx%d  每帧上传 %.1f MB  → 60fps 约 %.0f MB/s'
              % (SW, SH, _mb, _mb * 60))
        print('       卡顿时可用 --res=1280x720 降低窗口分辨率（配合 X11 拉伸）')

    err_count = 0

    while running:
        target_fps = int(game.settings.fps_target())
        raw = clock.tick(target_fps) / 1000.0
        # dt 上限随目标帧率走：偶发掉帧时物理不会一下跳很远，手感更稳
        dt = min(raw, 1.0 / max(20.0, target_fps * 0.6))
        try:
            keys = pygame.key.get_pressed()
            t = pygame.time.get_ticks() / 1000.0

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.VIDEORESIZE:
                    SW, SH = max(320, event.w), max(240, event.h)
                    try:
                        screen = pygame.display.set_mode((SW, SH),
                                                         pygame.RESIZABLE)
                        game.screen = screen
                    except Exception:
                        pass
                    apply_size(SW, SH)

                elif event.type == APP_WILLENTERBACKGROUND:
                    # 切后台：自动暂停并清空触摸，回来时摇杆不会卡住
                    if game.state == STATE_PLAY:
                        game.state = STATE_PAUSE
                    game.touch.clear()

                elif event.type == APP_DIDENTERFOREGROUND:
                    game.touch.clear()

                elif event.type == pygame.FINGERDOWN:
                    # 手指坐标是「整屏归一化」，必须先还原成屏幕像素，
                    # 再走 screen_to_render，否则一有黑边就整体错位
                    sw_, sh_ = screen.get_size()
                    rx, ry = game.screen_to_render(event.x * sw_, event.y * sh_)
                    on_point_down(rx, ry, getattr(event, 'finger_id', 0))

                elif event.type == pygame.FINGERMOTION:
                    if game.settings_open:
                        continue
                    sw_, sh_ = screen.get_size()
                    rx, ry = game.screen_to_render(event.x * sw_, event.y * sh_)
                    game.touch.move(rx, ry, getattr(event, 'finger_id', 0))

                elif event.type == pygame.FINGERUP:
                    game.touch.up(getattr(event, 'finger_id', 0))

                # ---- 鼠标事件 ----
                # Termux X11 / Pydroid 把触摸上报成鼠标事件。只监听 FINGER*
                # 的话，手机上点了会完全没反应，所以这一路必须接上。
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    rx, ry = game.screen_to_render(*event.pos)
                    on_point_down(rx, ry, 'mouse')

                elif event.type == pygame.MOUSEMOTION and event.buttons[0]:
                    if game.settings_open:
                        continue
                    rx, ry = game.screen_to_render(*event.pos)
                    game.touch.move(rx, ry, 'mouse')

                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    game.touch.up('mouse')

                elif event.type == pygame.KEYDOWN:
                    if game.settings_open:
                        # 设置面板打开时只认这几个键，别误操作到飞机上
                        if event.key in (pygame.K_ESCAPE, pygame.K_s,
                                         pygame.K_RETURN):
                            close_settings()
                        continue
                    if event.key == pygame.K_F11:
                        fullscreen = not fullscreen
                        if fullscreen:
                            screen = pygame.display.set_mode(
                                (0, 0), pygame.FULLSCREEN)
                        else:
                            screen = pygame.display.set_mode(
                                (SCREEN_W, SCREEN_H))
                        game.screen = screen
                        SW, SH = screen.get_size()
                        apply_size(SW, SH)
                    elif event.key == pygame.K_s:
                        open_settings()
                    elif game.state == STATE_MENU:
                        if event.key in (pygame.K_SPACE, pygame.K_RETURN,
                                         pygame.K_KP_ENTER):
                            game.state = STATE_PLAY
                    elif game.state == STATE_PLAY:
                        if event.key in (pygame.K_p, pygame.K_ESCAPE):
                            game.state = STATE_PAUSE
                        elif event.key == pygame.K_v:
                            game.view_mode = 1 - game.view_mode
                            game.msg('座舱视角' if game.view_mode
                                     else '第三人称视角', 1.2)
                        elif event.key == pygame.K_m:
                            if game.locked and game.lock_target is not None:
                                if game.launch_missile(game.player,
                                                       game.lock_target):
                                    game.msg('导弹发射！', 1.4)
                            else:
                                game.msg('未锁定目标', 1.0)
                        elif event.key == pygame.K_c:
                            game.drop_flare(game.player)
                    elif game.state == STATE_PAUSE:
                        if event.key in (pygame.K_p, pygame.K_ESCAPE):
                            game.state = STATE_PLAY
                        elif event.key == pygame.K_r:
                            game.reset()
                            game.state = STATE_PLAY
                    elif game.state == STATE_OVER:
                        if event.key == pygame.K_r:
                            game.reset()
                            game.state = STATE_PLAY

            # ---------- 触屏一次性动作 ----------
            for act in game.touch.pop_events():
                if act == TOUCH_SET:
                    open_settings()
                elif act == TOUCH_PAUSE:
                    if game.state == STATE_PLAY:
                        game.state = STATE_PAUSE
                        game.touch.clear()
                elif game.state == STATE_PLAY:
                    if act == TOUCH_MSL:
                        if game.locked and game.lock_target is not None:
                            if game.launch_missile(game.player,
                                                   game.lock_target):
                                game.msg('导弹发射！', 1.4)
                        else:
                            game.msg('未锁定目标', 1.0)
                    elif act == TOUCH_FLR:
                        game.drop_flare(game.player)
                    elif act == TOUCH_VIEW:
                        game.view_mode = 1 - game.view_mode
                        game.msg('座舱视角' if game.view_mode
                                 else '第三人称视角', 1.2)

            # ---------- 绘制 ----------
            t0 = time.time()
            if game.state == STATE_PLAY:
                game.update(dt, keys, frame_ms)
                game.render()
            elif game.state == STATE_MENU:
                draw_menu(game.rbuf, game, t)
            elif game.state == STATE_PAUSE:
                game.render()
                if not game.settings_open:
                    draw_pause(game.rbuf, game)
            elif game.state == STATE_OVER:
                game.render()
                draw_over(game.rbuf, game, t)
            frame_ms = (time.time() - t0) * 1000.0

            # ---------- 帧率统计（真实帧间隔，不受 tick 上限影响）----------
            real = time.time()
            if last_frame > 0.0:
                inst = 1.0 / max(1e-4, real - last_frame)
                game.fps = game.fps * 0.88 + inst * 0.12
                if inst < game.fps_min:
                    game.fps_min = inst
            last_frame = real
            frame_no += 1
            if frame_no % 150 == 0:
                auto_quality()
                game.fps_min = game.fps      # 每 150 帧重置一次最低值记忆

            sw, sh = screen.get_size()
            if sh > sw:
                draw_text(game.rbuf, '请将手机横过来',
                          (game.rw // 2, game.rh // 2 - 60),
                          26, HUD_AMBER, center=True, bold=True)
                draw_text(game.rbuf, '横屏后画面会自动铺满全屏',
                          (game.rw // 2, game.rh // 2 - 28), 17,
                          (200, 215, 230), center=True)

            # ---------- 设置面板 / 桌面齿轮（画在最上层）----------
            if game.settings_open:
                game.setpanel.draw(game.rbuf, game.rw, game.rh)
            elif not game.touch.active:
                sbx, sby, sbr = set_btn_rect()
                pygame.draw.circle(game.rbuf, (28, 52, 70), (sbx, sby), sbr)
                pygame.draw.circle(game.rbuf, (140, 200, 235), (sbx, sby), sbr, 2)
                draw_gear(game.rbuf, sbx, sby, int(sbr * 0.60),
                          (215, 240, 255, 235))

            game.present()
            err_count = 0

        except SystemExit:
            raise
        except Exception:
            err_count += 1
            import traceback as _tbm
            tb = _tbm.format_exc()
            try:
                sys.stderr.write(tb + '\n')
                sys.stderr.flush()
            except Exception:
                pass
            if err_count >= 6:
                print('连续出错 6 次，程序已停止。')
                break
            try:
                if not crash_dialog(screen, '游戏运行出错', tb, err_count):
                    break
            except Exception:
                break
            # 尽量恢复到一个干净状态继续跑
            try:
                game.state = STATE_MENU
                game.settings_open = False
                game.touch.clear()
                game.bullets = []
                game.missiles = []
                game.particles = []
                game.fps_min = game.fps
                last_frame = 0.0
            except Exception:
                pass

        pygame.display.flip()
    pygame.quit()
    sys.exit(0)


if __name__ == '__main__':
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        import traceback as _tb2
        _t = _tb2.format_exc()
        try:
            sys.stderr.write(_t + '\n')
            sys.stderr.flush()
        except Exception:
            pass
        # 尽量弹个红窗说明情况；pygame 都起不来的话只能打印
        shown = False
        try:
            pygame.init()
            scr = pygame.display.set_mode((640, 420))
            crash_dialog(scr, '启动失败', _t, 1)
            shown = True
        except Exception:
            pass
        if not shown:
            print('')
            print('===== 启动失败 =====')
            for _l in error_hint(_t):
                print('  ' + _l)
            print('  详细信息：')
            print(_t)
        sys.exit(1)
