#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  Termux + X11 一键安装并运行 空战飞行模拟器
#  用法：把本文件和 flight_sim.zip 都放进 ~/downloads/
#        然后执行： bash setup.sh
# ============================================================

set -e
GREEN='\033[1;32m'; YELLOW='\033[1;33m'; RED='\033[1;31m'; NC='\033[0m'
say() { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[!!]${NC} $1"; }
err() { echo -e "${RED}[ERR]${NC} $1"; }

echo "============================================"
echo "  空战飞行模拟器 · Termux 一键安装"
echo "============================================"

# ---------- 1. 找 zip ----------
ZIP=""
for f in ~/downloads/flight_sim.zip ~/storage/downloads/flight_sim.zip \
         ~/downloads/空战飞行模拟器.zip ./flight_sim.zip; do
    [ -f "$f" ] && ZIP="$f" && break
done
if [ -z "$ZIP" ]; then
    err "没找到 flight_sim.zip"
    echo "   请把它放进 ~/downloads/ 目录后重试。"
    exit 1
fi
say "找到压缩包: $ZIP"

WORK=~/flightsim
mkdir -p "$WORK"
cd "$WORK"
unzip -o "$ZIP" >/dev/null 2>&1
if [ ! -f flight_sim.py ]; then
    err "解压失败，文件里没有 flight_sim.py"
    exit 1
fi
say "已解压到 $WORK"
ls -la

# ---------- 2. 系统依赖 ----------
echo
say "安装系统依赖 (x11-repo / python / SDL)..."
pkg update -y >/dev/null 2>&1 || warn "pkg update 失败，继续尝试"
pkg install -y x11-repo >/dev/null 2>&1 || true
pkg install -y python python-pip >/dev/null 2>&1 || true
# X11：优先装 Termux:X11（需同时在手机上安装 Termux:X11 这个 App）
pkg install -y termux-x11-nightly >/dev/null 2>&1 || warn "termux-x11-nightly 未装上，稍后手动装"
# VNC 方案作为备选
pkg install -y tigervnc xorg-xhost >/dev/null 2>&1 || true
pkg install -y python-numpy >/dev/null 2>&1 || true
say "系统依赖就绪"

# ---------- 3. Python 依赖 ----------
echo
say "安装 pygame ..."
pip install --upgrade pip >/dev/null 2>&1 || true
if pip install pygame numpy 2>&1 | tail -3; then
    say "pygame / numpy 安装完成"
else
    warn "pip 安装失败，尝试系统包"
    pkg install -y python-pygame >/dev/null 2>&1 || {
        err "pygame 安装失败，请手动执行: pip install pygame"
        exit 1
    }
fi

# PyOpenGL 可选：装上才能启用 GPU 后端（3D 交给显卡）
echo
say "安装 PyOpenGL（可选，用于 GPU 后端）..."
if pip install PyOpenGL 2>&1 | tail -2; then
    python3 -c "import OpenGL; print('   PyOpenGL', OpenGL.__version__)" \
        && say "GPU 后端可用：游戏里把「渲染器」设为 GPU 即可" \
        || warn "PyOpenGL 装了但导入失败，将使用 CPU 后端"
else
    warn "PyOpenGL 安装失败，将使用 CPU 软件渲染（游戏功能不受影响）"
fi

python3 -c "import pygame; print('pygame', pygame.__version__)" || {
    err "pygame 仍不可用"; exit 1; }

# ---------- 4. 生成启动脚本 ----------
cat > "$WORK/start.sh" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
# 启动 X11 服务并运行游戏
export DISPLAY=:0
export XDG_RUNTIME_DIR=${TMPDIR}
export PULSE_SERVER=127.0.0.1

# 若 X server 未运行则启动（先试 termux-x11，再退回 VNC）
if ! pgrep -f "termux-x11|Xvfb|Xvnc" >/dev/null; then
    if command -v termux-x11 >/dev/null 2>&1; then
        echo "启动 termux-x11 :0 ..."
        termux-x11 :0 -xstartup "" >/dev/null 2>&1 &
    else
        echo "启动 VNC server :1 (1280x720) ..."
        vncserver :1 -geometry 1280x720 >/dev/null 2>&1
        export DISPLAY=:1
    fi
    sleep 3
fi
cd ~/flightsim
echo "DISPLAY=$DISPLAY 启动游戏..."
python3 flight_sim.py
EOF
chmod +x "$WORK/start.sh"
say "已生成启动脚本 $WORK/start.sh"

echo
echo "============================================"
echo -e "${GREEN}安装完成！${NC}"
echo
echo "  运行游戏："
echo -e "    ${YELLOW}bash ~/flightsim/start.sh${NC}"
echo
echo "  或者手动三步："
echo "    1. 打开 Termux:X11 app"
echo "    2. termux-x11 :0 &"
echo "    3. DISPLAY=:0 python3 ~/flightsim/flight_sim.py"
echo
echo "  省 X11 带宽（手机上很关键）："
echo -e "    ${YELLOW}DISPLAY=:0 python3 ~/flightsim/flight_sim.py --res=1280x720${NC}"
echo
echo "  切换渲染后端（对比哪个快，看左上角 FPS）："
echo "    --gl   3D 交给 GPU（需 PyOpenGL）"
echo "    --cpu  纯 CPU 软件渲染"
echo "============================================"
